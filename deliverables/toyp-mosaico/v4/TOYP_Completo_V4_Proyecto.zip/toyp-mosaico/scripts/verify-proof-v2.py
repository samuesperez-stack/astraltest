"""Check the actual proof export and create review frames, without touching V1."""
from pathlib import Path
import json
import re
import subprocess
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/v2'
VIDEO = OUT / 'TOYP_Mosaico_Prueba_V2.mp4'

def command(args):
    return subprocess.check_output(args)

info = json.loads(command(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(VIDEO)]))
v = next(s for s in info['streams'] if s['codec_type'] == 'video')
a = next(s for s in info['streams'] if s['codec_type'] == 'audio')
assert (v['width'], v['height'], v['r_frame_rate'], int(v['nb_frames'])) == (1080, 1920, '60/1', 390)
assert abs(float(v['duration']) - 6.5) < .001
assert v['codec_name'] == 'h264' and a['codec_name'] == 'aac'
subprocess.run(['ffmpeg', '-v', 'error', '-i', str(VIDEO), '-f', 'null', '-'], check=True)

def pcm(path):
    return np.frombuffer(command(['ffmpeg', '-v', 'error', '-i', str(path), '-vn', '-ac', '1', '-ar', '8000', '-f', 'f32le', '-']), dtype='<f4')

x = pcm(ROOT / 'public/audio/proof-v2.wav')
y = pcm(VIDEO)
n = min(len(x), len(y))
corr = float(np.corrcoef(x[:n], y[:n])[0, 1])
assert corr > .99
measure = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(VIDEO), '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True, check=True).stderr
peak = float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS', measure).group(1))
assert peak < 0
raw = command(['ffmpeg', '-v', 'error', '-i', str(VIDEO), '-an', '-vf', 'scale=108:192', '-pix_fmt', 'gray', '-f', 'rawvideo', '-'])
frames = np.frombuffer(raw, dtype=np.uint8).reshape((-1, 192, 108))
assert len(frames) == 390
black = int((frames.mean(axis=(1, 2)) < 1).sum())
assert black == 0

times = [.1, 1.45, 2.82, 3.25, 3.9, 4.85, 5.65, 389/60]
sheet = Image.new('RGB', (1440, 1330), '#071422')
for i, t in enumerate(times):
    p = OUT / f'review-{i}.png'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t), '-i', str(VIDEO), '-frames:v', '1', str(p)], check=True)
    im = Image.open(p)
    im.thumbnail((360, 640))
    xx, yy = i % 4 * 360, i // 4 * 665
    sheet.paste(im, (xx, yy + 25))
    ImageDraw.Draw(sheet).text((xx + 10, yy + 7), f'{t:.2f} s', fill='white')
sheet.save(OUT / 'TOYP_Prueba_V2_Encuadres.jpg', quality=95)

result = {'composition': 'ToypMosaicProofV2', 'scope': 'Opening and selection proof only; not the completed 18-second film', 'width': 1080, 'height': 1920, 'fps': 60, 'frames': 390, 'video_duration_seconds': float(v['duration']), 'container_duration_seconds': float(info['format']['duration']), 'video_codec': v['codec_name'], 'audio_codec': a['codec_name'], 'full_decode': 'passed', 'black_frames': black, 'source_audio_zero_lag_correlation': corr, 'true_peak_dbfs': peak, 'review_frames_seconds': times}
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
