const {openBrowser, selectComposition, renderStill} = require('@remotion/renderer');
const fs = require('fs');
const path = require('path');

(async () => {
  const serveUrl = path.resolve(__dirname, '../build');
  const out = path.resolve(__dirname, '../out/v3');
  fs.mkdirSync(out, {recursive: true});
  const browser = await openBrowser('chrome', {browserExecutable: '/usr/bin/chromium'});
  try {
    const composition = await selectComposition({serveUrl, id: 'ToypFullV3', puppeteerInstance: browser});
    const times = [.5, 1.1, 1.49, 2.9, 4.3, 5.4, 6.4, 7.8, 8.3, 8.7, 9.5, 10.5, 11.5, 12.5, 13.3, 14.3, 16.5, 18.5];
    for (let i = 0; i < times.length; i++) {
      await renderStill({composition, serveUrl, puppeteerInstance: browser, frame: Math.round(times[i] * 60), output: path.join(out, `still-${i}.png`), imageFormat: 'png'});
    }
    fs.writeFileSync(path.join(out, 'still-times.json'), JSON.stringify(times));
    console.log(`Rendered ${times.length} review frames.`);
  } finally { await browser.close({silent: true}); }
})().catch(e => {console.error(e); process.exit(1);});
