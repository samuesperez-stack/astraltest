from pathlib import Path
import numpy as np,subprocess,wave
root=Path(__file__).resolve().parents[1];sr=48000;n=sr*18
raw=subprocess.check_output(['ffmpeg','-v','error','-ss','60','-i',str(root/'public/audio/Inspired-original.mp3'),'-t','18','-ac','2','-ar',str(sr),'-f','f32le','-'])
a=np.frombuffer(raw,dtype='<f4').reshape((-1,2)).astype(float);assert len(a)>=n
a=a[:n];a*=.26/max(np.max(abs(a)),.001)
t=np.arange(n)/sr;env=np.interp(t,[0,.4,3,6.5,11.2,11.5,14.5,17.1,18],[0,.7,.75,.9,.72,1,1,.8,0]);a*=env[:,None]
rng=np.random.default_rng(2026)
def put(start,sound):
 i=int(start*sr);end=min(n,i+len(sound));a[i:end]+=sound[:end-i,None]
for start in [0,3,6.5,11.5,14.5]:
 x=np.arange(int(.8*sr))/sr;hit=np.sin(2*np.pi*(44*x+30*(1-np.exp(-x*22))/22))*np.exp(-x*8)*(.11 if start==11.5 else .06);put(start,hit)
for start in np.arange(.25,2.8,.5):
 x=np.arange(int(.045*sr))/sr;put(start,rng.normal(0,1,len(x))*np.exp(-x*120)*.022)
for i in range(10):
 x=np.arange(int(.4*sr))/sr;put(6.5+i*.065,np.sin(2*np.pi*(880+i*55)*x)*np.exp(-x*15)*.012)
for start in [3,5,11.35,14.35]:
 x=np.arange(int(.3*sr))/sr;s=rng.normal(0,1,len(x));s=np.convolve(s,np.ones(12)/12,mode='same');put(start,s*np.sin(np.pi*x/.3)**2*.045)
tmp=root/'out/premix.wav'
with wave.open(str(tmp),'wb') as f:
 f.setparams((2,2,sr,0,'NONE','not compressed'));f.writeframes((np.clip(a,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(tmp),'-af','loudnorm=I=-16:TP=-1.4:LRA=8','-ar',str(sr),str(root/'public/audio/final.wav')],check=True)
print('18-second licensed score + original sound design ready')
