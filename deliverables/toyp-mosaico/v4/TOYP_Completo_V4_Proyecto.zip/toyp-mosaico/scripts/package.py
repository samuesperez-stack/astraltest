from pathlib import Path
import zipfile,json,hashlib
root=Path(__file__).resolve().parents[1];archive=root.parent/'TOYP_Mosaico_Proyecto.zip'
files=[]
for f in sorted(root.rglob('*')):
 rel=f.relative_to(root)
 if not f.is_file() or any(x in rel.parts for x in ['node_modules','build','out','originals','__pycache__']):continue
 if f.name=='MANIFEST.json':continue
 files.append(f)
manifest=[{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
p=root/'MANIFEST.json';p.write_text(json.dumps(manifest,indent=2)+'\n');files.append(p)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,Path('toyp-mosaico')/f.relative_to(root))
 for name in ['verification.json','TOYP_Mosaico_Encuadres.jpg']:z.write(root/'out'/name,Path('toyp-mosaico/out')/name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert not any('/originals/' in n or 'contact-input' in n for n in z.namelist())
 assert len([n for n in z.namelist() if '/public/photos/' in n and n.endswith('.jpg')])==41
 assert z.read('toyp-mosaico/src/root.tsx')==(root/'src/root.tsx').read_bytes()
print(archive,archive.stat().st_size)
