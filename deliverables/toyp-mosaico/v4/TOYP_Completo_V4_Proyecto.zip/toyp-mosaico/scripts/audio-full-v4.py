"""Reproducible 20-second TOYP V4 original sound effects only.

Only writes public/audio/full-v4.wav and out/v4/audio-info.json.
No music source is used in this version.
"""
from pathlib import Path
import json
import re
import subprocess

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SR = 48000
DURATION = 20.0
SAMPLES = round(SR * DURATION)
RNG = np.random.default_rng(2026102903)
OUT = ROOT / 'public/audio/full-v4.wav'
REPORT = ROOT / 'out/v4/audio-info.json'


def run(args, **kwargs):
    return subprocess.run(args, check=True, capture_output=True, **kwargs)


time = np.arange(SAMPLES) / SR
mix = np.zeros((SAMPLES, 2), dtype=np.float64)


def add(start, sound, pan=0.0):
    index = round(start * SR)
    length = min(len(sound), SAMPLES - index)
    angle = (pan + 1) * np.pi / 4
    mix[index:index + length, 0] += sound[:length] * np.cos(angle)
    mix[index:index + length, 1] += sound[:length] * np.sin(angle)


def noise(length, smoothing=8):
    values = RNG.normal(0, 1, length)
    return np.convolve(values, np.ones(smoothing) / smoothing, mode='same')


def sweep(start, duration, amplitude, smoothing=20, pan=0.0):
    x = np.arange(round(duration * SR)) / SR
    sound = noise(len(x), smoothing) * np.sin(np.pi * x / duration) ** 2
    add(start, sound * amplitude, pan)


def impact(start, strength=.055, duration=.5):
    x = np.arange(round(duration * SR)) / SR
    phase = 2 * np.pi * (49 * x + 23 * (1 - np.exp(-x * 25)) / 25)
    body = np.sin(phase) * np.exp(-x * 13) * np.minimum(x / .004, 1)
    add(start, body * strength)
    tap_time = np.arange(round(.045 * SR)) / SR
    add(start, noise(len(tap_time), 3) * np.exp(-tap_time * 180) * strength * .38)


def chime(start, frequency, amplitude=.012, duration=.28, pan=0.0):
    x = np.arange(round(duration * SR)) / SR
    tone = np.sin(2 * np.pi * frequency * x) * np.exp(-x * 23)
    tone += .16 * np.sin(2 * np.pi * frequency * 2.01 * x) * np.exp(-x * 39)
    tone *= np.minimum(x / .003, 1)
    add(start, tone * amplitude, pan)


# Brief, soft logo shimmer. The music carries the melodic identity.
x = np.arange(round(1.2 * SR)) / SR
logo = np.sin(2 * np.pi * 659.255 * x) * .003
logo += np.sin(2 * np.pi * 783.991 * x) * .002
logo *= np.sin(np.pi * x / 1.2) ** 2
add(.05, logo)
sweep(1.15, .42, .026, smoothing=24)

shutters = [1.7, 2.2, 2.7, 3.2, 3.7]
for index, start in enumerate(shutters):
    x = np.arange(round(.07 * SR)) / SR
    tap = noise(len(x), 4) * np.exp(-x * 115)
    second = np.maximum(x - .018, 0)
    tap += .5 * noise(len(x), 5) * np.exp(-second * 150) * (x >= .018)
    add(start, tap * .025, -.2 if index % 2 == 0 else .2)

sweep(4.08, .587, .028)
impact(4.5)

x = np.arange(round(2.3 * SR)) / SR
scanner = noise(len(x), 32) * .006
scanner += np.sin(2 * np.pi * (740 * x + 25 * x * x)) * .0018
scanner *= np.minimum(x / .12, 1) * np.minimum((2.3 - x) / .15, 1)
add(4.85, scanner)

selection_times = [5.01, 5.01, 5.34, 5.67, 5.67, 6.0, 6.32, 6.32, 6.65, 6.98]
row_times = sorted(set(selection_times))
for index, start in enumerate(row_times):
    # Simultaneous selections share one quiet row lock, avoiding stacked clicks.
    frequency = [784, 880, 988, 1175, 988, 1175, 1319][index]
    chime(start, frequency, pan=(index / 6 - .5) * .32)

# Separation from the wall and physical movement through the card sequence.
impact(8.0, .038)
sweep(8.0, .8, .032, smoothing=24)
chime(8.35, 1174.66, .009, .35, -.12)
chime(8.56, 1318.51, .008, .35, .12)
for index, start in enumerate([9.0, 10.0, 11.0, 12.0]):
    sweep(start - .08, .26, .018, smoothing=15, pan=-.14 if index % 2 == 0 else .14)
    chime(start, [784, 988, 1175, 1319][index], .006, .23)

# The visual cut at 13 s receives a clean transient, without a noisy explosion.
sweep(12.8, .2, .023, smoothing=16)
impact(13.0, .09, .82)
x = np.arange(round(.9 * SR)) / SR
sub = np.sin(2 * np.pi * 49 * x) * np.exp(-x * 5.5)
sub *= np.minimum(x / .025, 1)
add(13.0, sub * .025)

# Warm closing resonance (C/E/G matches the local pitch-class emphasis of music).
sweep(15.82, .38, .018, smoothing=24)
x = np.arange(round(1.45 * SR)) / SR
resonance = sum(np.sin(2 * np.pi * frequency * x) * level for frequency, level in
                [(130.813, .0038), (195.998, .0028), (329.628, .0020)])
resonance *= np.exp(-x * 3.2) * np.minimum(x / .018, 1)
add(16.0, resonance)
chime(16.0, 1046.50, .006, .45)

# Equal-power end fade applies to all material, so no effect outlives the film.
fade = np.clip((DURATION - time) / .8, 0, 1)
mix *= np.where(time >= 19.2, .5 - .5 * np.cos(np.pi * fade), 1)[:, None]
pcm = mix.astype('<f4').tobytes()
input_args = ['ffmpeg', '-hide_banner', '-nostats', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', 'pipe:0']
measure = run(input_args + ['-af', 'loudnorm=I=-16:TP=-1.6:LRA=7:print_format=json', '-f', 'null', '-'], input=pcm).stderr.decode()
stats = json.loads(re.search(r'\{\s*"input_i".*?\}', measure, re.S).group())
normalizer = (
    'loudnorm=I=-16:TP=-1.6:LRA=7:linear=true:'
    f'measured_I={stats["input_i"]}:measured_TP={stats["input_tp"]}:'
    f'measured_LRA={stats["input_lra"]}:measured_thresh={stats["input_thresh"]}:'
    f'offset={stats["target_offset"]}'
)
OUT.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
run(input_args + ['-af', 'volume=2,alimiter=limit=0.78:level=false:latency=true', '-t', str(DURATION), '-ar', str(SR), '-c:a', 'pcm_s24le', '-y', str(OUT)], input=pcm)

probe = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(OUT)]).stdout)
stream = probe['streams'][0]
assert stream['sample_rate'] == str(SR) and stream['channels'] == 2
assert float(probe['format']['duration']) == DURATION
assert int(stream['duration_ts']) == SAMPLES
run(['ffmpeg', '-v', 'error', '-i', str(OUT), '-f', 'null', '-'])
meter = run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(OUT), '-af', 'ebur128=peak=true', '-f', 'null', '-']).stderr.decode()
true_peak = float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS', meter).group(1))
integrated = float(re.findall(r'I:\s+(-?[0-9.]+) LUFS', meter)[-1])
assert true_peak <= -1.4
assert integrated < -14
decoded = np.frombuffer(run(['ffmpeg', '-v', 'error', '-i', str(OUT), '-f', 'f32le', '-']).stdout, dtype='<f4').reshape((-1, 2))
assert len(decoded) == SAMPLES
tail_peak = float(np.max(np.abs(decoded[-round(.01 * SR):])))
assert tail_peak < .001
report = {
    'file': str(OUT.relative_to(ROOT)), 'duration_seconds': DURATION,
    'sample_rate': SR, 'channels': 2, 'samples_per_channel': SAMPLES,
    'codec': stream['codec_name'], 'integrated_lufs': integrated,
    'true_peak_dbfs': true_peak, 'last_10ms_peak_linear': tail_peak,
    'decode': 'passed', 'voice': False,
    'music': 'None; original sound effects only',
    'source_excerpt_seconds': None,
    'intro_seconds': [0, 1.5], 'logo_transition_seconds': 1.15,
    'shutter_seconds': shutters, 'anonymity_flip_seconds': [4.08, 4.667],
    'camera_stop_seconds': 4.5, 'scan_seconds': [4.85, 7.15],
    'selection_times_seconds': selection_times, 'audible_row_locks_seconds': row_times,
    'cards_leave_wall_seconds': [8, 8.8], 'carousel_accents_seconds': [9, 10, 11, 12],
    'solo_10_cut_seconds': 13, 'institutional_close_seconds': [16, 20],
    'end_fade_seconds': [19.2, 20],
    'note': 'Technical verification only. No voice. Prior source tracks and mixes preserved.'
}
REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(report, indent=2, ensure_ascii=False))
