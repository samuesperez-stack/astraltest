"""Deterministic 6.5 s proof score; licensed music plus restrained original SFX.

Only writes public/audio/proof-v2.wav and out/v2/prueba-audio-info.json.
The production score and the source track remain untouched.
"""
from pathlib import Path
import json
import re
import subprocess

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SR = 48000
DURATION = 6.5
SAMPLES = round(SR * DURATION)
RNG = np.random.default_rng(20261029)
OUT = ROOT / 'public/audio/proof-v2.wav'
REPORT = ROOT / 'out/v2/prueba-audio-info.json'


def run(args, **kwargs):
    return subprocess.run(args, check=True, capture_output=True, **kwargs)


raw = run([
    'ffmpeg', '-v', 'error', '-ss', '60', '-i',
    str(ROOT / 'public/audio/Inspired-original.mp3'), '-t', str(DURATION),
    '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-',
]).stdout
music = np.frombuffer(raw, dtype='<f4').reshape((-1, 2)).astype(np.float64)
assert len(music) == SAMPLES
music *= 0.23 / max(float(np.max(np.abs(music))), 0.001)
time = np.arange(SAMPLES) / SR
# A gentle dip exposes the stop and scan without dropping the musical bed.
envelope = np.interp(time, [0, .15, 2.6, 2.95, 3.15, 5.6, 6.35, 6.5],
                     [0, .86, .95, .72, .82, .94, .94, 0])
mix = music * envelope[:, None]


def add(start, sound, pan=0.0):
    index = round(start * SR)
    length = min(len(sound), SAMPLES - index)
    # Constant-power panning keeps the selection gestures subtle in stereo.
    angle = (pan + 1) * np.pi / 4
    mix[index:index + length, 0] += sound[:length] * np.cos(angle)
    mix[index:index + length, 1] += sound[:length] * np.sin(angle)


def noise(length, smooth=8):
    values = RNG.normal(0, 1, length)
    return np.convolve(values, np.ones(smooth) / smooth, mode='same')


shutters = [.2, .7, 1.2, 1.7, 2.2]
for index, start in enumerate(shutters):
    x = np.arange(round(.07 * SR)) / SR
    # Two restrained mechanical taps, not a white-noise blast.
    tap = noise(len(x), 4) * np.exp(-x * 115)
    second = np.maximum(x - .018, 0)
    tap += .5 * noise(len(x), 5) * np.exp(-second * 150) * (x >= .018)
    add(start, tap * .025, -.2 if index % 2 == 0 else .2)

# One broad, quiet sweep accompanies the uniform anonymity flip.
x = np.arange(round(.55 * SR)) / SR
add(2.6, noise(len(x), 20) * np.sin(np.pi * x / .55) ** 2 * .028)

# Dry body and extremely short contact tick for the camera stop.
x = np.arange(round(.5 * SR)) / SR
body = np.sin(2 * np.pi * (52 * x + 20 * (1 - np.exp(-x * 25)) / 25))
body *= np.exp(-x * 15) * np.minimum(x / .004, 1)
add(3.0, body * .055)
add(3.0, noise(round(.045 * SR), 3) * np.exp(-np.arange(round(.045 * SR)) / SR * 180) * .023)

# Very low scanner texture, deliberately without alarm-like modulation.
x = np.arange(round(2.3 * SR)) / SR
scan = noise(len(x), 32) * .006
scan += np.sin(2 * np.pi * (740 * x + 25 * x * x)) * .0018
scan *= np.minimum(x / .12, 1) * np.minimum((2.3 - x) / .15, 1)
add(3.35, scan)

lock_times = [3.51, 3.51, 3.84, 4.17, 4.17, 4.5, 4.82, 4.82, 5.15, 5.48]
row_times = sorted(set(lock_times))
for index, start in enumerate(row_times):
    x = np.arange(round(.24 * SR)) / SR
    # A cohesive short glass tone per row: simultaneous selections do not sum.
    frequency = [784, 880, 988, 1175, 988, 1175, 1319][index]
    tone = np.sin(2 * np.pi * frequency * x) * np.exp(-x * 25)
    tone += .16 * np.sin(2 * np.pi * frequency * 2.01 * x) * np.exp(-x * 42)
    tone *= np.minimum(x / .003, 1)
    add(start, tone * .012, (index / 6 - .5) * .32)

# A smooth ending is only for this standalone proof, not the full 18 s edit.
fade = np.clip((DURATION - time) / .15, 0, 1)
mix *= np.where(time >= DURATION - .15, .5 - .5 * np.cos(np.pi * fade), 1)[:, None]
pcm = mix.astype('<f4').tobytes()
input_args = ['ffmpeg', '-hide_banner', '-nostats', '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', 'pipe:0']
measure = run(input_args + ['-af', 'loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json', '-f', 'null', '-'], input=pcm).stderr.decode()
stats = json.loads(re.search(r'\{\s*"input_i".*?\}', measure, re.S).group())
normalizer = (
    'loudnorm=I=-16:TP=-1.5:LRA=7:linear=true:'
    f'measured_I={stats["input_i"]}:measured_TP={stats["input_tp"]}:'
    f'measured_LRA={stats["input_lra"]}:measured_thresh={stats["input_thresh"]}:'
    f'offset={stats["target_offset"]}'
)
OUT.parent.mkdir(parents=True, exist_ok=True)
REPORT.parent.mkdir(parents=True, exist_ok=True)
run(input_args + ['-af', normalizer, '-t', str(DURATION), '-ar', str(SR), '-c:a', 'pcm_s24le', '-y', str(OUT)], input=pcm)

probe = json.loads(run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(OUT)]).stdout)
stream = probe['streams'][0]
assert stream['sample_rate'] == str(SR) and stream['channels'] == 2
assert float(probe['format']['duration']) == DURATION
run(['ffmpeg', '-v', 'error', '-i', str(OUT), '-f', 'null', '-'])
meter = run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(OUT), '-af', 'ebur128=peak=true', '-f', 'null', '-']).stderr.decode()
true_peak = float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS', meter).group(1))
assert true_peak <= -1.4
integrated = float(re.findall(r'I:\s+(-?[0-9.]+) LUFS', meter)[-1])
report = {
    'file': str(OUT.relative_to(ROOT)), 'duration_seconds': DURATION,
    'sample_rate': SR, 'channels': 2, 'codec': stream['codec_name'],
    'integrated_lufs': integrated, 'true_peak_dbfs': true_peak,
    'decode': 'passed', 'voice': False,
    'music': 'Inspired — Kevin MacLeod (incompetech.com), CC BY 4.0',
    'source_excerpt_seconds': [60, 66.5],
    'shutter_seconds': shutters, 'camera_stop_seconds': 3.0,
    'scan_seconds': [3.35, 5.65], 'selection_times_seconds': lock_times,
    'audible_row_locks_seconds': row_times,
    'standalone_end_fade_seconds': .15,
    'note': 'Technical verification only. Original music and full-film score preserved.'
}
REPORT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(report, indent=2, ensure_ascii=False))
