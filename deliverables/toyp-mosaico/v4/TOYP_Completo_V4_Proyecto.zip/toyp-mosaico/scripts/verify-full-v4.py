"""Validate the complete rendered film and extract review frames from the MP4."""
from pathlib import Path
import json
import re
import subprocess
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out/v4'
VIDEO = OUT / 'TOYP_Completo_V4.mp4'

def command(args):
    return subprocess.check_output(args)

info = json.loads(command(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(VIDEO)]))
v = next(s for s in info['streams'] if s['codec_type'] == 'video')
a = next(s for s in info['streams'] if s['codec_type'] == 'audio')
assert (v['width'], v['height'], v['r_frame_rate'], int(v['nb_frames'])) == (1080, 1920, '60/1', 1200)
assert abs(float(v['duration']) - 20) < .001
assert abs(float(info['format']['duration']) - 20) < 1/60
assert v['codec_name'] == 'h264' and a['codec_name'] == 'aac'
assert a['sample_rate'] == '48000' and a['channels'] == 2
subprocess.run(['ffmpeg', '-v', 'error', '-i', str(VIDEO), '-f', 'null', '-'], check=True)

def pcm(path):
    return np.frombuffer(command(['ffmpeg', '-v', 'error', '-i', str(path), '-vn', '-ac', '1', '-ar', '8000', '-f', 'f32le', '-']), dtype='<f4')

x = pcm(ROOT / 'public/audio/full-v4.wav')
y = pcm(VIDEO)
n = min(len(x), len(y))
corr = float(np.corrcoef(x[:n], y[:n])[0, 1])
assert corr > .99
measure = subprocess.run(['ffmpeg', '-hide_banner', '-nostats', '-i', str(VIDEO), '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True, check=True).stderr
peak = float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS', measure).group(1))
assert peak <= -1.4
lufs = float(re.findall(r'I:\s+(-?[0-9.]+) LUFS', measure)[-1])
raw = command(['ffmpeg', '-v', 'error', '-i', str(VIDEO), '-an', '-vf', 'scale=108:192', '-pix_fmt', 'gray', '-f', 'rawvideo', '-'])
frames = np.frombuffer(raw, dtype=np.uint8).reshape((-1, 192, 108))
assert len(frames) == 1200
black = int((frames[60:1182].mean(axis=(1, 2)) < 1).sum())
assert black == 0

# These samples include each category pair and both new logo scenes.
times = [.5, 1.1, 2.9, 4.3, 5.4, 6.4, 7.8, 8.3, 8.8, 9.5, 10.5, 11.5, 12.5, 13.3, 14.3, 18.5]
sheet = Image.new('RGB', (1440, 2660), '#071422')
for i, t in enumerate(times):
    path = OUT / f'final-review-{i}.png'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(t), '-i', str(VIDEO), '-frames:v', '1', str(path)], check=True)
    im = Image.open(path)
    im.thumbnail((360, 640))
    xx, yy = i % 4 * 360, i // 4 * 665
    sheet.paste(im, (xx, yy + 25))
    ImageDraw.Draw(sheet).text((xx + 10, yy + 7), f'{t:.2f} s', fill='white')
sheet.save(OUT / 'TOYP_Completo_V4_Encuadres.jpg', quality=94)
result = {
    'composition': 'ToypFullV4', 'scope': 'Complete social video, including logo opening and institutional closing',
    'width': 1080, 'height': 1920, 'fps': 60, 'frames': 1200,
    'video_duration_seconds': float(v['duration']), 'container_duration_seconds': float(info['format']['duration']),
    'video_codec': v['codec_name'], 'audio_codec': a['codec_name'], 'full_decode': 'passed',
    'unexpected_black_frames_between_1s_and_19_7s': black,
    'source_audio_zero_lag_correlation': corr, 'true_peak_dbfs': peak, 'integrated_lufs': lufs,
    'review_frames_seconds': times, 'voiceover': False,
    'category_pairs': [[1,2],[3,4],[5,6],[7,8],[9,10]],
    'music': 'No music; original sound effects only',
}
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
