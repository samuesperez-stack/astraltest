from pathlib import Path
import subprocess,json,re
import numpy as np
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1];out=root/'out';video=out/'TOYP_40_A_10.mp4'
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(video)]))
v=next(s for s in info['streams'] if s['codec_type']=='video');a=next(s for s in info['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1080,1920,'60/1',1080)
assert abs(float(info['format']['duration'])-18)<1/60
assert v['codec_name']=='h264' and a['codec_name']=='aac'
subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'],check=True)
def pcm(path):
 return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','8000','-f','f32le','-']),dtype='<f4')
x=pcm(root/'public/audio/final.wav');y=pcm(video);n=min(len(x),len(y));corr=float(np.corrcoef(x[:n],y[:n])[0,1]);assert corr>.98
measure=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(video),'-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True,check=True).stderr
peak=float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS',measure).group(1));assert peak<0
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-an','-vf','scale=108:192','-pix_fmt','gray','-f','rawvideo','-'])
frames=np.frombuffer(raw,dtype=np.uint8).reshape((-1,192,108));brightness=frames.mean(axis=(1,2))
# The opening is intentionally black before the reveal; later frames must not disappear.
assert (brightness[60:]<1).sum()==0
times=[1.7,3.8,5.8,6.8,8.5,11.8,12.8,16]
canvas=Image.new('RGB',(1080,1010),'#00112c')
for i,t in enumerate(times):
 p=out/f'v2-review-{i}.jpg'
 subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t),'-i',str(video),'-frames:v','1','-q:v','2',str(p)],check=True)
 im=Image.open(p);im.thumbnail((270,480));xx=i%4*270;yy=i//4*505
 canvas.paste(im,(xx,yy+25));ImageDraw.Draw(canvas).text((xx+10,yy+6),str(t)+' s',fill='white')
canvas.save(out/'TOYP_Mosaico_Encuadres.jpg',quality=94)
result={'width':1080,'height':1920,'fps':60,'frames':1080,'duration':float(info['format']['duration']),'video_codec':v['codec_name'],'audio_codec':a['codec_name'],'full_decode':'passed','source_audio_zero_lag_correlation':corr,'true_peak_dbfs':peak,'unexpected_black_frames_after_first_second':int((brightness[60:]<1).sum()),'review_frames_seconds':times,'voice':'No voice. Inspired by Kevin MacLeod, CC BY 4.0, excerpt plus original SFX.'}
(out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
