# 🎬 Planificación & Storyboard: «De 40 a Solo 10»
### TOYP Venezuela 2026 — JCI Venezuela
**Formato:** Video Vertical 9:16 (1080 × 1920) | 60 FPS | Sin voz en off  
**Duración objetivo:** 18.0 segundos (1080 frames)  
**Estilo Visual:** Mosaico Cinemático + Selección Táctica + Tarjetas de Honor 3D  

---

## 1. El Concepto Narrativo

> **La Premisa:**  
> Más de 40 jóvenes sobresalientes de todo el país postularon sus historias de impacto, liderazgo y excelencia.  
> Un riguroso jurado calificador evaluó cada trayectoria.  
> **Pero solo 10 subirán al escenario como los Galardonados Nacionales TOYP 2026.**

Este concepto genera **tensión dramática, expectativa y máximo prestigio**: no es un simple evento social, es el filtro de excelencia juvenil más estricto del país.

---

## 2. Las 10 Categorías Oficiales de los Galardonados

Cada una de las 10 tarjetas seleccionadas llevará su silueta vectorial y el nombre oficial de su categoría:

1. **Logros Empresariales & Económicos**
2. **Desarrollo Científico & Tecnológico**
3. **Innovación Médica & Salud**
4. **Liderazgo Académico & Educación**
5. **Logros Culturales & Artísticos**
6. **Liderazgo Moral & Ambiental**
7. **Servicio Humanitario & Voluntariado**
8. **Derechos Humanos & Niñez**
9. **Asuntos Legales & Gobierno**
10. **Superación & Logros Personales**

---

## 3. Storyboard Segundo a Segundo (18 Segundos / 1080 Frames @ 60 FPS)

```mermaid
flowchart TD
    A["0.0s - 3.0s: El Mosaico de 40<br/>Grid masivo con 40 fotos"] --> B["3.0s - 6.5s: El Escaneo / Filtro<br/>Láser barre el muro, 30 se apagan"]
    B --> C["6.5s - 11.5s: Despliegue 10 Tarjetas<br/>10 Siluetas SVG doradas + Categorías"]
    C --> D["11.5s - 14.5s: Clímax Tipográfico<br/>SOLO 10 SERÁN LOS GANADORES"]
    D --> E["14.5s - 18.0s: Cierre & Llamado<br/>28 Nov Valencia • Zoom HD • Patrocinios"]
```

### Escena 1: El Muro de los 40 (0.0s – 3.0s | Frames 0 – 180)
* **Visual:**
  * La pantalla se llena completamente con un **mosaico denso de 40 retratos fotográficos** dispuestos en una cuadrícula con leve inclinación en perspectiva 3D (*slight spatial tilt*).
  * La cámara realiza un sutil paneo continuo mientras las fotos parpadean sutilmente con destellos de flash de estudio fotográfico.
  * Tipografía superpuesta de alto impacto con efecto *split-reveal*:
    * `+40 POSTULACIONES RECIBIDAS`
    * `EL TALENTO MÁS ALTO DEL PAÍS`
* **Audio / SFX:** Beat de percusión electrónica ascendente + efecto rítmico de obturador de cámara fotográfica (*shutter camera burst*).

---

### Escena 2: El Escaneo y la Selección (3.0s – 6.5s | Frames 180 – 390)
* **Visual:**
  * El movimiento de cámara se detiene con un golpe seco.
  * Una línea de escaneo dorado/láser recorre verticalmente el mosaico.
  * Al paso del escaneo:
    * **30 casillas se atenúan a blanco y negro** con baja opacidad (quedando como fondo sutil).
    * **10 casillas se iluminan con un halo dorado radiante** (*golden border beam*) y se separan hacia el frente en el eje Z de profundidad.
  * Tipografía en pantalla:
    * `UN JURADO CALIFICADOR`
    * `UNA DECISIÓN HISTÓRICA`
* **Audio / SFX:** Sub-drop grave + sonido de escáner digital táctil + notch lock al seleccionar las 10.

---

### Escena 3: Las 10 Tarjetas de Honor con Siluetas SVG (6.5s – 11.5s | Frames 390 – 690)
* **Visual:**
  * Las 10 casillas seleccionadas se transforman en **tarjetas verticales de honor** organizadas en una composición flotante dinámica (2 filas de 5 o carrusel cinemático).
  * Cada tarjeta contiene:
    1. **Silueta vectorial SVG de una persona** con trazo dorado y aura de contraluz (*rim light*).
    2. Identificador numérico del `01` al `10`.
    3. Etiqueta con el nombre de su categoría oficial (ej. *Desarrollo Científico*, *Logros Empresariales*, etc.).
    4. Sello holográfico de *Nominado Oficial TOYP 2026*.
* **Audio / SFX:** Caída de bajo potente + tintineos metálicos de cristal (*golden chime*) mientras las tarjetas se despliegan.

---

### Escena 4: El Clímax Monumental (11.5s – 14.5s | Frames 690 – 870)
* **Visual:**
  * Corte rápido a negro con destello central:
    * `SOLO 10` (en escala monumental, 220px, oro sobre fondo oscuro).
    * `PORTARÁN EL GALARDÓN TOYP 2026`
    * Subtítulo: `10 Jóvenes. Un país en transformación.`
* **Audio / SFX:** Explosión de impacto percutivo limpio + sub-bass swell.

---

### Escena 5: El Gran Cierre Institucional & Alianzas (14.5s – 18.0s | Frames 870 – 1080)
* **Visual:**
  * **Logotipo Oficial TOYP Venezuela 2026:** Se utiliza exactamente el arte oficial suministrado:
    
    ![Logotipo Oficial TOYP 2026](file:///C:/Users/GAMEMAX/.gemini/antigravity/brain/547f2629-05d1-4a31-b0c3-92ecd38ae10c/logo_referencia_toyp.png)
    
    *(JCI Shield + monograma angular TOYP + subtítulo "10 Jóvenes Sobresalientes Venezuela 2026" + "2026" en serif clásico).*
  * Coordenadas clave:
    * `28 DE NOVIEMBRE • VALENCIA, VENEZUELA`
    * Badge corporativo: `TRANSMISIÓN EN VIVO VÍA ZOOM HD`
  * Bloque de alianzas para empresas que deseen sumarse al evento:
    * `ASOCIA EL PRESTIGIO DE TU MARCA A LOS 10 GANADORES`
    * Canales de contacto: `+58 422 639 5360` • `+58 412 430 4815` • `toypvzla@gmail.com`
    * Badge inferior: `Cupos de Patrocinio Limitados`
* **Audio / SFX:** Resonancia armónica de cierre + fade out elegante.

---

## 4. Especificaciones Técnicas de Implementación

| Elemento | Especificación Técnica |
| :--- | :--- |
| **Framework** | React 19 + Remotion (`durationInFrames: 1080`, `fps: 60`, `1080x1920`) |
| **Mosaico (40)** | Grid procedural responsivo con 40 elementos en CSS Grid / Flexbox 3D (`perspective: 1000px`) |
| **Fotos del Mosaico** | Retratos monocromáticos/iluminación de estudio en alta resolución estilizados para emular postulados reales |
| **Siluetas SVG (10)** | Vector SVG limpio (`stroke`, `fill: rgba(245, 158, 11, 0.15)`, contorno en oro `#F59E0B`) |
| **Paleta de Color** | Azul noche JCI (`#000B1A`, `#001433`), Oro galardón (`#F59E0B`, `#FDE68A`), Cian conectividad (`#00B4D8`) |
| **Tipografía** | Plus Jakarta Sans (Black 900 para números y titulares, SemiBold 600 para categorías) |
| **Audio** | Pista base a 120 BPM (`bg-beat.mp3`) con balance de volumen en 0.22 y SFX a 0.08–0.11 para no saturar |

---

> [!NOTE]
> Este documento representa la hoja de ruta visual acordada. Una vez aprobados los detalles de esta planificación, se procederá a la construcción del código y renderizado final.
