# Revisión V2 — prueba del mosaico y la selección

Prueba de dirección de los primeros 6,5 segundos, 1080 × 1920, 60 fps. La versión inicial de 18 segundos se conserva como `ToypMosaico`. La nueva composición es `ToypMosaicProofV2`; aún no contiene el carrusel, el clímax ni el cierre del video completo.

La revisión recupera la estructura del MD original: muro completo, cámara que se detiene, escaneo dorado y diez tarjetas que se separan del fondo. El movimiento conserva las dimensiones de cada tarjeta y usa un giro con dos caras reales; los retratos no se estiran ni se convierten en formas tipográficas.

## Secuencia

- 0–2,6 s: muro de 41 retratos únicos y una celda de marca. Perspectiva leve, flashes localizados y titular con revelado por máscara. Se recupera el texto «EL TALENTO MÁS ALTO DEL PAÍS».
- 2,58–3,167 s: giro uniforme escalonado hacia caras anónimas. La cámara termina su frenado a los 3 segundos.
- 3,35–5,65 s: el escáner avanza de arriba abajo. Diez posiciones ilustrativas reciben borde dorado y elevación de 150 píxeles en Z; las otras se atenúan. Las caras son anónimas antes de cualquier tratamiento de selección.
- 5,9–6,5 s: reposo de las diez tarjetas para comprobar jerarquía, separación y encuadre antes del despliegue posterior.

Las posiciones seleccionadas son una representación gráfica del filtro de excelencia. No constituyen una selección real de personas ni una lista de ganadores. Se muestran 41 fotografías únicas porque el ZIP contenía 42 archivos y un duplicado exacto.

## Reproducir

```bash
npm ci --no-audit --no-fund
npm run typecheck
npm run render:proof
```

El MP4 queda en `out/v2/TOYP_Mosaico_Prueba_V2.mp4`. Usa Chromium en `/usr/bin/chromium`; adaptar la ruta si procede. Las fuentes, fotografías derivadas y audio ya están incluidos; no se requieren descargas para renderizar tras instalar las dependencias.

`python scripts/audio-proof-v2.py` reproduce el audio con FFmpeg y numpy. Se usa «Inspired», Kevin MacLeod, extracto desde 01:00 y efectos originales sincronizados. La atribución completa está en `docs/MUSIC_ATTRIBUTION.txt` y debe acompañar la prueba al compartirla. El montaje es una prueba, sin créditos sobreimpresos que alteren la evaluación del mosaico.

## Continuidad prevista para el video completo

Las diez tarjetas anónimas se desplegarán como tarjetas verticales de honor con categorías y profundidad. A los 11,5 segundos habrá corte a negro y «SOLO 10», conforme al MD. El cierre institucional ocupará los últimos 3,5 segundos. Estos tramos todavía no forman parte de esta prueba.
