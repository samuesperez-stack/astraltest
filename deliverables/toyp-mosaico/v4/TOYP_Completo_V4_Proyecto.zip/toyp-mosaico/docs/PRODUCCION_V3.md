# TOYP — video completo para redes, V3

**20 segundos · 1080 × 1920 · 60 fps · sin voz.**

Esta versión completa incorpora el ajuste solicitado después de la prueba: textos centrados, apertura animada con la identidad TOYP y desarrollo de todo el MD. Se agregan 1,5 segundos de apertura y medio segundo al cierre respecto al objetivo original de 18 segundos.

## Montaje

| Tiempo | Acción |
| --- | --- |
| 0–1,5 s | Logo centrado. Se reduce de forma uniforme hasta ocupar la celda de marca mientras aparece el muro de retratos. |
| 1,5–4,5 s | Muro completo, paneo contenido y «+40 POSTULACIONES RECIBIDAS», centrado. |
| 4,5–8 s | Giro a caras anónimas, frenado, escaneo dorado y diez posiciones en profundidad. «UN JURADO CALIFICADOR» y «UNA DECISIÓN HISTÓRICA» centrados. |
| 8–13 s | Las mismas tarjetas pasan al carrusel de cinco parejas. Se conserva la relación 2:3 durante todo el recorrido; categorías breves y números centrados. |
| 13–16 s | Corte a negro con destello central y «SOLO 10». Mensaje de galardón y transformación del país. |
| 16–20 s | Cierre institucional centrado: fecha, ciudad, Zoom HD, patrocinios y contactos. |

Los titulares principales quedan centrados en el eje del video. Las etiquetas de las tarjetas se centran dentro de cada tarjeta. Los textos esenciales del cierre se mantienen entre x=120 y x=960 y por encima de y=1500 para dejar margen a las interfaces de redes; la ubicación exacta de los controles varía entre plataformas.

## Materiales

Se conservan las 41 fotografías únicas recibidas y una celda de marca. Los originales quedan fuera de la entrega, incluido el documento de identidad completo: solo se utiliza el recorte facial derivado. Todas las fotografías quedan ocultas antes de la selección gráfica. Las posiciones anónimas no identifican ganadores reales.

La marca vectorial JCI/TOYP procede del portal oficial; la bajada y el año se componen con las fuentes locales siguiendo el arte de referencia. No se afirma que sea una copia píxel a píxel del PNG adjunto. Plus Jakarta Sans y Bodoni Moda incluyen sus licencias OFL.

Las etiquetas visibles del carrusel se abrevian para lectura rápida. `docs/CATEGORIES.json` conserva los diez nombres completos del MD. Los títulos del video original, la fecha y los contactos se mantienen.

## Música

**Inspired — Kevin MacLeod (incompetech.com)**. Creative Commons Attribution 4.0:
https://creativecommons.org/licenses/by/4.0/

Fuente: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1600022

Extracto de 01:00 a 01:20, con automatización de nivel, fundidos y efectos originales de obturador, giro, escáner, selección y transiciones. El crédito aparece al cierre; conservar también `docs/MUSIC_ATTRIBUTION.txt` en la descripción al publicar. No hay locución.

## Editar y exportar

```bash
npm ci --no-audit --no-fund
npm run studio
npm run typecheck
npm run render:full
```

La vista previa está en `http://localhost:3102/ToypFullV3` al ejecutar Studio. El comando de render usa Chromium en `/usr/bin/chromium`; adaptar la ruta si fuera necesario. La composición completa se llama `ToypFullV3`. Las escenas `ToypWorldV3`, `ToypClimaxV3` y `ToypClosingV3` también se registran para revisar sus propios tramos.

`src/v3/World.tsx` mantiene la apertura, el muro y el carrusel dentro del mismo espacio para preservar la continuidad de las tarjetas. `src/v3/Climax.tsx` y `src/v3/Closing.tsx` son escenas independientes. `src/v3/Film.tsx` define la secuencia completa. La animación depende del frame; no usa animaciones CSS ni reloj real.

`python scripts/audio-full-v3.py` reproduce la mezcla. `python scripts/verify-full-v3.py` comprueba el MP4 final y genera los encuadres de revisión. Requieren FFmpeg, numpy y Pillow. Los assets necesarios para renderizar ya están incluidos en el proyecto.

La versión inicial de 18 segundos y la prueba V2 de 6,5 segundos permanecen disponibles como composiciones separadas.
