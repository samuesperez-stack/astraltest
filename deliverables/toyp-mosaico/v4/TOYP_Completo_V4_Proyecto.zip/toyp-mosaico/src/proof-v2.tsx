import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, Img, cancelRender, continueRender, delayRender, staticFile, useCurrentFrame} from 'remotion';
import photos from './photos.json';

// The anonymous positions are illustrative. They do not identify award winners.
export const SELECTED_POSITIONS = [1, 4, 8, 12, 16, 20, 25, 29, 33, 38];
const GOLD = '#F5D590';
const WHITE = '#F6F8FC';
const TILE_W = 176;
const TILE_H = 264;
const STEP_X = 190;
const STEP_Y = 278;
const WALL_W = 1126;
const WALL_H = 1932;
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (x: number) => {const n = clamp(x); return n * n * n * (n * (n * 6 - 15) + 10);};
const progress = (t: number, a: number, b: number) => smooth((t - a) / (b - a));
const out = (x: number) => 1 - Math.pow(1 - clamp(x), 4);

export const tileState = (t: number, i: number) => {
  const row = Math.floor(i / 6);
  const col = i % 6;
  const hit = 3.35 + ((row * STEP_Y + TILE_H / 2) / WALL_H) * 2.3;
  const selected = SELECTED_POSITIONS.indexOf(i);
  const flipStart = 2.58 + col * .019 + row * .012;
  const flip = progress(t, flipStart, flipStart + .42);
  const scan = progress(t, hit, hit + .18);
  const lift = selected >= 0 ? progress(t, hit + .045, hit + .48) : 0;
  return {row, col, hit, selected, flip, scan, lift};
};

const Person: React.FC<{active: number}> = ({active}) => <svg viewBox="0 0 100 145" style={{width: 78, height: 113, display: 'block'}} fill="none">
  <defs><linearGradient id={`person-${active}`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#fff1cd"/><stop offset=".5" stopColor="#D6AE60"/><stop offset="1" stopColor="#A87C38"/></linearGradient></defs>
  <circle cx="50" cy="31" r="20" fill="currentColor" fillOpacity=".075" stroke="currentColor" strokeWidth="1.7"/>
  <path d="M16 136v-27c0-23 13-36 34-36s34 13 34 36v27H16Z" fill="currentColor" fillOpacity=".075" stroke="currentColor" strokeWidth="1.7"/>
  <path d="M30 111v25m40-25v25" stroke="currentColor" strokeWidth=".7" opacity=".5"/>
</svg>;

const Tile: React.FC<{t: number; i: number}> = ({t, i}) => {
  const s = tileState(t, i);
  const chosen = s.selected >= 0;
  const light = chosen ? s.scan : 0;
  const z = s.lift * 150;
  const flashTime = .2 + (i % 5) * .5;
  const flash = i % 7 === 1 ? Math.max(0, 1 - Math.abs(t - flashTime) / .055) * .22 : 0;
  const face: React.CSSProperties = {position: 'absolute', inset: 0, borderRadius: 7, backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', overflow: 'hidden'};
  return <div data-tile={i} style={{position: 'absolute', left: s.col * STEP_X, top: s.row * STEP_Y, width: TILE_W, height: TILE_H, transformStyle: 'preserve-3d', transform: `translateZ(${z}px)`}}>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateY(${180 * s.flip}deg)`}}>
      <div style={{...face, background: '#122130', border: '1px solid #bfd1e32b', transform: 'translateZ(.2px)'}}>
        {i < photos.length ? <Img src={staticFile(photos[i].asset)} style={{width: '100%', height: '100%', objectFit: i === 32 ? 'contain' : 'cover', filter: 'contrast(1.06) brightness(.88)'}}/> : <div style={{height: '100%', display: 'flex', alignItems: 'center', padding: 18}}><Img src={staticFile('toyp-mark.svg')} style={{width: '100%'}}/></div>}
        <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg,#00173316,transparent 60%,#00132935)'}}/>
        <div style={{position: 'absolute', inset: 0, background: '#e9f6ff', opacity: flash}}/>
      </div>
      <div style={{...face, transform: 'rotateY(180deg) translateZ(.2px)', background: light > 0 ? `linear-gradient(145deg,rgba(42,58,72,${.7 + light * .3}),#08131f 60%,#16212c)` : '#102130', border: `${1.5 + light * 1.2}px solid ${chosen && s.scan > 0 ? GOLD : '#758c9e3b'}`, boxShadow: light > 0 ? `0 ${10 + z * .22}px ${18 + z * .36}px #0009, inset 0 1px 0 #ffffff${Math.round(12 + light * 30).toString(16).padStart(2, '0')}, 0 0 ${light * 16}px #eecf7a2b` : '0 6px 12px #0005'}}>
        <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(130deg,#ffffff14,transparent 35%,#00000020)', opacity: .3 + light * .7}}/>
        <div style={{position: 'absolute', top: 16, left: 17, right: 17, display: 'flex', justifyContent: 'space-between', alignItems: 'center', color: light > 0 ? GOLD : '#7990a3', opacity: .28 + light * .72, fontSize: 15, letterSpacing: 1.5, fontWeight: 600}}><span>{light > 0 ? String(s.selected + 1).padStart(2, '0') : '—'}</span><span style={{fontSize: 8, letterSpacing: 1}}>TOYP</span></div>
        <div style={{position: 'absolute', left: 48, top: 68, color: chosen && s.scan > 0 ? GOLD : '#678195', opacity: chosen ? .28 + light * .72 : .28}}><Person active={i}/></div>
        <div style={{position: 'absolute', bottom: 28, left: 18, right: 18, height: 1, background: light > 0 ? GOLD : '#8396a4', opacity: .16 + light * .36}}/>
        <div style={{position: 'absolute', bottom: 12, left: 0, right: 0, textAlign: 'center', fontSize: 8, letterSpacing: 2.2, color: light > 0 ? GOLD : '#8396a4', opacity: .35 + light * .5}}>VENEZUELA · 2026</div>
        {/* A moving specular highlight belongs to the surface, never to the whole frame. */}
        {chosen && s.scan > 0 && <div style={{position: 'absolute', inset: -40, background: 'linear-gradient(115deg,transparent 35%,#fff1c52b 48%,transparent 61%)', transform: `translateX(${-240 + progress(t, s.hit, s.hit + .7) * 480}px)`}}/>}
        {!chosen && <div style={{position: 'absolute', inset: 0, background: '#000811', opacity: s.scan * .68}}/>}
      </div>
    </div>
  </div>;
};

const SplitLine: React.FC<{t: number; at: number; children: React.ReactNode; style?: React.CSSProperties}> = ({t, at, children, style}) => <div style={{overflow: 'hidden', paddingBottom: 7, ...style}}><div style={{transform: `translateY(${(1 - out((t - at) / .55)) * 110}%)`}}>{children}</div></div>;

const Copy: React.FC<{t: number}> = ({t}) => {
  const exit = progress(t, 2.3, 2.64);
  const first = progress(t, 3.07, 3.35) * (1 - progress(t, 4.04, 4.27));
  const second = progress(t, 4.3, 4.57) * (1 - progress(t, 5.55, 5.83));
  return <>
    {t < 2.7 && <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,transparent 24%,#00081222 37%,#000812bd 57%,#000812ef 79%,#000812b0)', opacity: progress(t, .15, .6) * (1 - exit)}}/>
      <div style={{position: 'absolute', left: 72, right: 60, top: 865, transform: `translateY(${-exit * 40}px)`, opacity: 1 - exit}}>
        <SplitLine t={t} at={.2} style={{fontSize: 306, fontWeight: 800, letterSpacing: -20, lineHeight: .95}}>+40</SplitLine>
        <div style={{marginTop: 31, fontSize: 62, lineHeight: 1.12, fontWeight: 700, letterSpacing: -2.3}}>
          <SplitLine t={t} at={.37}>POSTULACIONES</SplitLine>
          <SplitLine t={t} at={.44}>RECIBIDAS</SplitLine>
        </div>
        <SplitLine t={t} at={.65} style={{marginTop: 36, fontSize: 24, letterSpacing: 2.5, color: '#d1dce5', fontWeight: 500}}>EL TALENTO MÁS ALTO DEL PAÍS</SplitLine>
      </div>
    </>}
    {t > 3 && t < 4.3 && <>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 530, background: 'linear-gradient(transparent,#000b1a80)', opacity: first}}/>
      <div style={{position: 'absolute', left: 70, bottom: 178, opacity: first, transform: `translateY(${(1 - progress(t, 3.07, 3.43)) * 24}px)`}}>
        <div style={{fontSize: 18, letterSpacing: 4, color: GOLD, marginBottom: 27}}>TOYP VENEZUELA 2026</div>
        <div style={{fontSize: 67, lineHeight: 1.08, fontWeight: 700, letterSpacing: -2.3}}>UN JURADO<br/>CALIFICADOR</div>
      </div>
    </>}
    {t > 4.25 && t < 5.85 && <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 570, background: 'linear-gradient(#000b1a80,transparent)', opacity: second}}/>
      <div style={{position: 'absolute', left: 70, top: 178, opacity: second, transform: `translateY(${(1 - progress(t, 4.3, 4.65)) * 22}px)`}}>
        <div style={{fontSize: 18, letterSpacing: 4, color: '#b8c8d6', marginBottom: 24}}>EXCELENCIA. LIDERAZGO. IMPACTO.</div>
        <div style={{fontSize: 64, lineHeight: 1.1, letterSpacing: -1.9, fontWeight: 700, color: GOLD}}>UNA DECISIÓN<br/>HISTÓRICA</div>
      </div>
    </>}
  </>;
};

export const ToypMosaicProofV2: React.FC = () => {
  const t = useCurrentFrame() / 60;
  const [handle] = useState(() => delayRender('TOYP proof fonts'));
  useEffect(() => {Promise.all(['800 306px Jakarta', '700 67px Jakarta', '500 24px Jakarta'].map(font => document.fonts.load(font))).then(() => continueRender(handle)).catch(cancelRender);}, [handle]);
  const camera = progress(t, 0, 3);
  const pullback = progress(t, 3.1, 4.1);
  const scanner = clamp((t - 3.35) / 2.3);
  const scannerOpacity = progress(t, 3.28, 3.4) * (1 - progress(t, 5.64, 5.82));
  return <AbsoluteFill style={{background: '#000914', color: WHITE, overflow: 'hidden', fontFamily: 'Jakarta'}}>
    <style>{`@font-face{font-family:Jakarta;src:url('${staticFile('fonts/PlusJakartaSans.ttf')}');font-weight:200 800}*{box-sizing:border-box}`}</style>
    <Audio src={staticFile('audio/proof-v2.wav')}/>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%,#143047,#000914 78%)'}}/>
    <AbsoluteFill style={{perspective: 2400, perspectiveOrigin: '50% 50%'}}>
      <div style={{position: 'absolute', left: (1080 - WALL_W) / 2, top: (1920 - WALL_H) / 2, width: WALL_W, height: WALL_H, transformStyle: 'preserve-3d', transform: `translateY(${28 * (1 - camera)}px) rotateX(${4.5 * (1 - camera)}deg) rotateY(${-7 * (1 - camera)}deg) rotateZ(${-2.8 * (1 - camera)}deg) scale(${1.085 - camera * .085 - pullback * .14})`}}>
        {Array.from({length: 42}, (_, i) => <Tile key={i} i={i} t={t}/>)}
        {t > 3.25 && t < 5.84 && <div style={{position: 'absolute', left: -30, right: -30, top: scanner * WALL_H, transform: 'translateZ(.8px)', height: 1.5, background: GOLD, opacity: scannerOpacity, boxShadow: '0 0 10px 2px #f3cc8566'}}><div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 36, background: 'linear-gradient(transparent,#efd28b20)'}}/></div>}
      </div>
    </AbsoluteFill>
    <AbsoluteFill style={{pointerEvents: 'none', background: 'linear-gradient(180deg,#000b1a44,transparent 16%,transparent 86%,#000b1a55)'}}/>
    <Copy t={t}/>
  </AbsoluteFill>;
};
