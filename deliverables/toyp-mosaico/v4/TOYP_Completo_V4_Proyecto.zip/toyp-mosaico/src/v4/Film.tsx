import React from 'react';
import {AbsoluteFill, Audio, Series, staticFile, useVideoConfig} from 'remotion';
import {World} from './World';
import {Climax} from './Climax';
import {Closing} from './Closing';

export const ToypFullV4: React.FC = () => {
  const {fps} = useVideoConfig();
  return <AbsoluteFill>
    <Audio src={staticFile('audio/full-v4.wav')}/>
    <Series>
      <Series.Sequence name="Logo, mosaico y tarjetas" durationInFrames={13 * fps} premountFor={fps}><World/></Series.Sequence>
      <Series.Sequence name="SOLO 10" durationInFrames={3 * fps} premountFor={fps}><Climax/></Series.Sequence>
      <Series.Sequence name="Cierre y patrocinios" durationInFrames={4 * fps} premountFor={fps}><Closing/></Series.Sequence>
    </Series>
  </AbsoluteFill>;
};
