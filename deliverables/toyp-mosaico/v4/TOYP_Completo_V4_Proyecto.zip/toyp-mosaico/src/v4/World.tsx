import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import photos from '../photos.json';
import {tileState} from '../proof-v2';
import {Canvas, GOLD, WHITE, LogoLockup, Person, SplitLine, clamp, labels, lerp, p} from './design';

const W = 176, H = 264, SX = 190, SY = 278, WW = 1126, WH = 1932;
export const activePair = (t: number) => p(t, 8.82, 9.28) + p(t, 9.82, 10.28) + p(t, 10.82, 11.28) + p(t, 11.82, 12.28);

// These positions are illustrative, not an announcement of selected people.
// Every object keeps the same 2:3 aspect ratio from photo to honor card.
const Tile: React.FC<{t: number; i: number}> = ({t, i}) => {
  const m = Math.max(0, t - 1.5);
  const s = tileState(m, i);
  const chosen = s.selected >= 0;
  const light = chosen ? s.scan : 0;
  const deploy = p(t, 8, 8.75);
  const hero = chosen ? p(t, 8.15, 8.5) : 0;
  const index = Math.max(s.selected, 0);
  const pair = Math.floor(index / 2);
  const distance = pair - activePair(t);
  const targetX = WW / 2 + (index % 2 === 0 ? -210 : 210) + (distance < 0 ? distance * 1120 : distance * 90);
  const targetY = WH / 2 + 410 - Math.max(distance, 0) * 38;
  const targetZ = -Math.abs(distance) * 600;
  const move = p(t, .65, 1.5);
  const cx = i === 41 ? lerp(WW / 2, s.col * SX + W / 2, move) : lerp(s.col * SX + W / 2, targetX, chosen ? deploy : 0);
  const cy = i === 41 ? lerp(WH / 2 - 70, s.row * SY + H / 2, move) : lerp(s.row * SY + H / 2, targetY, chosen ? deploy : 0);
  const z = chosen ? lerp(s.lift * 150, targetZ, deploy) : 0;
  const scale = i === 41 ? lerp(3.65, 1, move) : lerp(1, 360 / W, chosen ? deploy : 0);
  const rotate = chosen ? clamp(distance / 2) * -20 * deploy + (distance < 0 ? Math.max(distance, -1) * -18 * deploy : 0) : 0;
  const intro = i === 41 ? p(t, 0, .24) : p(t, .89 + Math.abs(s.col - 2.5) * .03 + Math.abs(s.row - 3) * .02, 1.5);
  const visibility = chosen ? 1 : 1 - p(t, 8, 8.5);
  const stageLight = chosen ? 1 - deploy * clamp(Math.abs(distance)) * .9 : 1;
  const readable = 1 - p(Math.abs(distance), .05, .85);
  const flashAt = 1.7 + (i % 5) * .5;
  const flash = i % 7 === 1 ? Math.max(0, 1 - Math.abs(t - flashAt) / .055) * .22 : 0;
  const face: React.CSSProperties = {position: 'absolute', inset: 0, borderRadius: 7, backfaceVisibility: 'hidden', WebkitBackfaceVisibility: 'hidden', overflow: 'hidden'};
  if (visibility === 0) return null;
  return <div data-tile={i} data-selected={chosen} style={{position: 'absolute', left: cx - W / 2, top: cy - H / 2, width: W, height: H, transformStyle: 'preserve-3d', opacity: intro * visibility, transform: `translateZ(${z}px) rotateY(${rotate}deg) scale(${scale})`}}>
    <div style={{position: 'absolute', inset: 0, transformStyle: 'preserve-3d', transform: `rotateY(${s.flip * 180}deg)`}}>
      <div style={{...face, transform: 'translateZ(.2px)', background: i === 41 && t < 1.5 ? 'transparent' : '#122130', border: `1px solid ${i === 41 && t < 1.5 ? 'transparent' : '#bfd1e32b'}`}}>
        {i < 41 ? <Img src={staticFile(photos[i].asset)} style={{width: '100%', height: '100%', objectFit: i === 32 ? 'contain' : 'cover', filter: 'contrast(1.06) brightness(.88)'}}/> : <div style={{height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><LogoLockup width={140}/></div>}
        {i < 41 && <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(180deg,#00173316,transparent 60%,#00132935)'}}/>}
        <div style={{position: 'absolute', inset: 0, background: '#e9f6ff', opacity: flash}}/>
      </div>
      <div style={{...face, transform: 'rotateY(180deg) translateZ(.2px)', opacity: stageLight, background: light > 0 ? 'linear-gradient(145deg,#2a3a48,#08131f 60%,#16212c)' : '#102130', border: `${1.5 + light * 1.2}px solid ${light > 0 ? GOLD : '#758c9e3b'}`, boxShadow: light > 0 ? `0 ${10 + s.lift * 30}px ${18 + s.lift * 45}px #0009, inset 0 1px 0 #ffffff${Math.round(12 + light * 30).toString(16).padStart(2, '0')}, 0 0 ${light * 16}px #eecf7a2b` : '0 6px 12px #0005'}}>
        <div style={{position: 'absolute', inset: 0, background: 'linear-gradient(130deg,#ffffff14,transparent 35%,#00000020)'}}/>
        <div style={{position: 'absolute', top: 15, left: 10, right: 10, textAlign: 'center', color: light > 0 ? GOLD : '#7990a3', opacity: .28 + light * .72, fontSize: lerp(15, 16, hero), letterSpacing: 1.5, fontWeight: 600}}>{light > 0 ? String(index + 1).padStart(2, '0') : '—'}</div>
        <div style={{position: 'absolute', left: 48, top: lerp(68, 53, hero), color: light > 0 ? GOLD : '#678195', opacity: chosen ? .28 + light * .72 : .28}}><Person/></div>
        {chosen && <div data-category={index + 1} style={{position: 'absolute', left: 8, right: 8, top: 179, color: WHITE, fontSize: 19, fontWeight: 600, lineHeight: 1.23, textAlign: 'center', opacity: hero * readable}}>{labels[index][0]}<br/>{labels[index][1]}</div>}
        <div style={{position: 'absolute', bottom: 28, left: 18, right: 18, height: 1, background: light > 0 ? GOLD : '#8396a4', opacity: (.16 + light * .36) * (1 - hero)}}/>
        <div style={{position: 'absolute', bottom: 12, left: 0, right: 0, textAlign: 'center', fontSize: 8, letterSpacing: 1.4, color: light > 0 ? GOLD : '#8396a4', opacity: .35 + light * .5}}>{hero > .5 ? 'CATEGORÍA TOYP · 2026' : 'VENEZUELA · 2026'}</div>
        {chosen && light > 0 && <div style={{position: 'absolute', inset: -40, background: 'linear-gradient(115deg,transparent 35%,#fff1c52b 48%,transparent 61%)', transform: `translateX(${-240 + p(m, s.hit, s.hit + .7) * 480}px)`}}/>}
        {!chosen && <div style={{position: 'absolute', inset: 0, background: '#000811', opacity: s.scan * .68}}/>}
      </div>
    </div>
  </div>;
};

const Copy: React.FC<{t: number}> = ({t}) => {
  const m = t - 1.5;
  const exit = p(m, 2.3, 2.64);
  const first = p(m, 3.07, 3.35) * (1 - p(m, 4.04, 4.27));
  const second = p(m, 4.3, 4.57) * (1 - p(m, 5.55, 5.83));
  return <>
    {m >= 0 && m < 2.7 && <>
      <AbsoluteFill style={{background: 'linear-gradient(180deg,transparent 24%,#00081222 37%,#000812bd 57%,#000812ef 79%,#000812b0)', opacity: p(m, .15, .6) * (1 - exit)}}/>
      <div data-safe-copy="forty" style={{position: 'absolute', left: 120, right: 120, top: 689, textAlign: 'center', transform: `translateY(${-exit * 40}px)`, opacity: 1 - exit}}>
        <SplitLine t={m} at={.2} style={{fontSize: 306, fontWeight: 800, letterSpacing: -15, paddingRight: 15, lineHeight: .95}}>+40</SplitLine>
        <div style={{marginTop: 31, fontSize: 65, lineHeight: 1.12, fontWeight: 700, letterSpacing: -2.3}}>
          <SplitLine t={m} at={.37}>POSTULACIONES</SplitLine>
          <SplitLine t={m} at={.44}>RECIBIDAS</SplitLine>
        </div>
        <SplitLine t={m} at={.65} style={{marginTop: 37, fontSize: 30, letterSpacing: 1.3, color: '#d1dce5', fontWeight: 500}}>EL TALENTO MÁS ALTO DEL PAÍS</SplitLine>
      </div>
    </>}
    {m > 3 && m < 4.3 && <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 620, height: 680, background: 'linear-gradient(transparent,#000b1ac0 35%,#000b1ac0 65%,transparent)', opacity: first}}/>
      <div data-safe-copy="jury" style={{position: 'absolute', left: 120, right: 120, top: 847, textAlign: 'center', opacity: first, transform: `translateY(${(1 - p(m, 3.07, 3.43)) * 24}px)`}}>
        <div style={{fontSize: 24, letterSpacing: 3, color: GOLD, marginBottom: 25}}>TOYP VENEZUELA 2026</div>
        <div style={{fontSize: 82, lineHeight: 1.08, fontWeight: 700, letterSpacing: -2.5}}>UN JURADO<br/>CALIFICADOR</div>
      </div>
    </>}
    {m > 4.25 && m < 5.85 && <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 620, height: 680, background: 'linear-gradient(transparent,#000b1ac0 35%,#000b1ac0 65%,transparent)', opacity: second}}/>
      <div data-safe-copy="decision" style={{position: 'absolute', left: 120, right: 120, top: 847, textAlign: 'center', opacity: second, transform: `translateY(${(1 - p(m, 4.3, 4.65)) * 22}px)`}}>
        <div style={{fontSize: 22, letterSpacing: 2, color: '#b8c8d6', marginBottom: 24}}>EXCELENCIA. LIDERAZGO. IMPACTO.</div>
        <div style={{fontSize: 80, lineHeight: 1.1, letterSpacing: -2, fontWeight: 700, color: GOLD}}>UNA DECISIÓN<br/>HISTÓRICA</div>
      </div>
    </>}
    {t >= 8 && <>
      <div data-safe-copy="categories" style={{position: 'absolute', left: 120, right: 120, top: 873, opacity: p(t, 8.52, 8.8), textAlign: 'center'}}>
        <SplitLine t={t} at={8.52} style={{fontSize: 78, lineHeight: 1.15, letterSpacing: -2.6, fontWeight: 700}}>10 CATEGORÍAS</SplitLine>
        <SplitLine t={t} at={8.58} style={{fontSize: 44, marginTop: 24, color: GOLD}}>Un mismo honor.</SplitLine>
      </div>
    </>}
  </>;
};

export const World: React.FC = () => {
  const {fps} = useVideoConfig();
  const t = useCurrentFrame() / fps;
  const m = Math.max(0, t - 1.5);
  const camera = p(m, 0, 3);
  const pullback = p(m, 3.1, 4.1);
  const boot = p(t, .65, 1.5);
  const deploy = p(t, 8, 8.75);
  const scale = lerp(lerp(1, 1.085 - camera * .085 - pullback * .14, boot), 1, deploy);
  const scanner = clamp((m - 3.35) / 2.3);
  const scannerOpacity = p(m, 3.28, 3.4) * (1 - p(m, 5.64, 5.82));
  return <Canvas>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%,#143047,#000914 78%)'}}/>
    <AbsoluteFill style={{perspective: 2400, perspectiveOrigin: '50% 50%'}}>
      <div style={{position: 'absolute', left: (1080 - WW) / 2, top: (1920 - WH) / 2, width: WW, height: WH, transformStyle: 'preserve-3d', transform: `translateY(${28 * (1 - camera) * boot}px) rotateX(${4.5 * (1 - camera) * boot}deg) rotateY(${-7 * (1 - camera) * boot}deg) rotateZ(${-2.8 * (1 - camera) * boot}deg) scale(${scale})`}}>
        {Array.from({length: 42}, (_, i) => <Tile key={i} i={i} t={t}/>)}
        {m > 3.25 && m < 5.84 && <div style={{position: 'absolute', left: -30, right: -30, top: scanner * WH, transform: 'translateZ(.8px)', height: 1.5, background: GOLD, opacity: scannerOpacity, boxShadow: '0 0 10px 2px #f3cc8566'}}><div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 36, background: 'linear-gradient(transparent,#efd28b20)'}}/></div>}
      </div>
    </AbsoluteFill>
    <AbsoluteFill style={{pointerEvents: 'none', background: 'linear-gradient(180deg,#000b1a44,transparent 16%,transparent 86%,#000b1a55)'}}/>
    <Copy t={t}/>
  </Canvas>;
};
