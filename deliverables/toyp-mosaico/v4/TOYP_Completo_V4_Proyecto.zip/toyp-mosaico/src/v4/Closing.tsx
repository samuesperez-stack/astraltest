import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Canvas, GOLD, LogoLockup, p} from './design';

export const Closing: React.FC = () => {
  const {fps} = useVideoConfig();
  const t = useCurrentFrame() / fps;
  const reveal = p(t, 0, .3);
  return <Canvas>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 33%,#123049,#000914 76%)'}}/>
    <AbsoluteFill style={{opacity: reveal, transform: `translateY(${(1 - reveal) * 18}px)`}}>
      <div data-safe-copy="logo" style={{position: 'absolute', left: 0, right: 0, top: 195}}><LogoLockup width={370}/></div>
      <div data-safe-copy="date" style={{position: 'absolute', left: 120, right: 120, top: 690, fontSize: 46, fontWeight: 700}}>28 DE NOVIEMBRE</div>
      <div data-safe-copy="place" style={{position: 'absolute', left: 120, right: 120, top: 760, fontSize: 33, letterSpacing: 2, color: '#c4d5e2'}}>VALENCIA · VENEZUELA</div>
      <div data-safe-copy="zoom" style={{position: 'absolute', left: 160, right: 160, top: 846, border: '1px solid #78cfdf55', borderRadius: 40, padding: '17px 12px', fontSize: 30, color: '#b1e5f0'}}>TRANSMISIÓN EN VIVO VÍA ZOOM HD</div>
      <div data-safe-copy="sponsor" style={{position: 'absolute', left: 120, right: 120, top: 981, fontSize: 43, lineHeight: 1.3, fontWeight: 700}}>Asocia el prestigio de tu marca<br/>a los 10 galardonados.</div>
      <div style={{position: 'absolute', left: 410, right: 410, top: 1140, height: 1, background: GOLD, opacity: .5}}/>
      <div data-safe-copy="phones" style={{position: 'absolute', left: 120, right: 120, top: 1185, fontSize: 35, lineHeight: 1.65}}>+58 422 639 5360<br/>+58 412 430 4815</div>
      <div data-safe-copy="email" style={{position: 'absolute', left: 120, right: 120, top: 1340, fontSize: 43, fontWeight: 600, color: GOLD}}>toypvzla@gmail.com</div>
      <div data-safe-copy="limited" style={{position: 'absolute', left: 120, right: 120, top: 1440, fontSize: 29, color: '#c0cfdb'}}>Cupos de patrocinio limitados</div>
    </AbsoluteFill>
    <AbsoluteFill style={{background: '#000914', opacity: p(t, 3.78, 4)}}/>
  </Canvas>;
};
