import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Img, cancelRender, continueRender, delayRender, staticFile} from 'remotion';

export const GOLD = '#F5D590';
export const WHITE = '#F6F8FC';
export const clamp = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => {const n = clamp(x); return n * n * n * (n * (n * 6 - 15) + 10);};
export const p = (t: number, a: number, b: number) => smooth((t - a) / (b - a));
export const lerp = (a: number, b: number, q: number) => a + (b - a) * q;
export const labels = [
  ['Empresa', 'y economía'], ['Ciencia', 'y tecnología'], ['Medicina', 'y salud'],
  ['Academia', 'y educación'], ['Cultura', 'y arte'], ['Moral', 'y ambiente'],
  ['Servicio', 'humanitario'], ['Derechos', 'humanos y niñez'],
  ['Leyes', 'y gobierno'], ['Superación', 'personal'],
];

export const Canvas: React.FC<{children: React.ReactNode; background?: string}> = ({children, background = '#000914'}) => {
  const [handle] = useState(() => delayRender('TOYP V3 local fonts'));
  useEffect(() => {Promise.all(['800 306px Jakarta', '700 84px Jakarta', '600 44px Jakarta', '400 140px Bodoni'].map(font => document.fonts.load(font))).then(() => continueRender(handle)).catch(cancelRender);}, [handle]);
  return <AbsoluteFill style={{background, color: WHITE, fontFamily: 'Jakarta', textAlign: 'center', overflow: 'hidden'}}>
    <style>{`@font-face{font-family:Jakarta;src:url('${staticFile('fonts/PlusJakartaSans.ttf')}');font-weight:200 800}@font-face{font-family:Bodoni;src:url('${staticFile('fonts/BodoniModa.ttf')}');font-weight:400 900}*{box-sizing:border-box}`}</style>
    {children}
  </AbsoluteFill>;
};

export const LogoLockup: React.FC<{width: number}> = ({width}) => <div style={{width, textAlign: 'center', margin: '0 auto'}}>
  <Img src={staticFile('toyp-mark.svg')} style={{width: '100%', display: 'block'}}/>
  <div style={{fontSize: width * .048, lineHeight: 1.42, marginTop: width * .028, fontWeight: 500}}>10 JÓVENES SOBRESALIENTES<br/>VENEZUELA 2026</div>
  <div style={{fontFamily: 'Bodoni', fontSize: width * .32, lineHeight: 1.12, marginTop: width * .025}}>2026</div>
</div>;

export const Person: React.FC = () => <svg viewBox="0 0 100 145" style={{width: 78, height: 113, display: 'block'}} fill="none">
  <circle cx="50" cy="31" r="20" fill="currentColor" fillOpacity=".075" stroke="currentColor" strokeWidth="1.7"/>
  <path d="M16 136v-27c0-23 13-36 34-36s34 13 34 36v27H16Z" fill="currentColor" fillOpacity=".075" stroke="currentColor" strokeWidth="1.7"/>
  <path d="M30 111v25m40-25v25" stroke="currentColor" strokeWidth=".7" opacity=".5"/>
</svg>;

export const SplitLine: React.FC<{t: number; at: number; children: React.ReactNode; style?: React.CSSProperties}> = ({t, at, children, style}) => <div style={{overflow: 'hidden', paddingBottom: 8, ...style}}><div style={{transform: `translateY(${(1 - (1 - Math.pow(1 - clamp((t - at) / .5), 4))) * 110}%)`}}>{children}</div></div>;
