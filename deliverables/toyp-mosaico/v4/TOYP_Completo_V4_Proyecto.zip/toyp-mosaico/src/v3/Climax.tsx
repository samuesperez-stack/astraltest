import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {Canvas, GOLD, p, SplitLine} from './design';

export const Climax: React.FC = () => {
  const {fps} = useVideoConfig();
  const t = useCurrentFrame() / fps;
  return <Canvas background="#01040A">
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 46%,#1a1b1a 0%,#01040A 67%)'}}/>
    <div data-safe-copy="solo" style={{position: 'absolute', left: 120, right: 120, top: 345, fontSize: 90, letterSpacing: 12, fontWeight: 700, color: GOLD}}>SOLO</div>
    <div data-safe-copy="ten" style={{position: 'absolute', left: 100, right: 100, top: 445, fontSize: 570, lineHeight: 1.15, fontWeight: 800, letterSpacing: -34, paddingRight: 34, background: 'linear-gradient(135deg,#fff1c7 15%,#e6bc64 56%,#b98a37 100%)', WebkitBackgroundClip: 'text', color: 'transparent', transform: `scale(${1.08 - p(t, 0, .42) * .08})`}}>10</div>
    <div data-safe-copy="award" style={{position: 'absolute', left: 120, right: 120, top: 1160, fontSize: 47, lineHeight: 1.22, fontWeight: 700}}>
      <SplitLine t={t} at={.12}>PORTARÁN EL GALARDÓN</SplitLine>
      <SplitLine t={t} at={.19}>TOYP 2026</SplitLine>
    </div>
    <div data-safe-copy="country" style={{position: 'absolute', left: 120, right: 120, top: 1375, fontSize: 36, lineHeight: 1.4, color: '#bbc7d3', opacity: p(t, .32, .65)}}>10 jóvenes.<br/>Un país en transformación.</div>
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 49%,#fff0ce,transparent 65%)', opacity: (1 - p(t, 0, .12)) * .55}}/>
  </Canvas>;
};
