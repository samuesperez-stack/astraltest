# TOYP Venezuela 2026 — De +40 a solo 10

**Versión actual:** [video completo V3 para redes](docs/PRODUCCION_V3.md), 20 s, apertura con logo, textos centrados, mosaico, carrusel de tarjetas verticales, «SOLO 10» y cierre. `npm run render:full` exporta `ToypFullV3` a `out/v3/TOYP_40_A_10_Completo_V3.mp4`.

La [prueba V2](docs/REVISION_V2.md) se conserva en `ToypMosaicProofV2`. La descripción que sigue documenta la versión inicial de 18 s, también conservada para comparación.

18 segundos, 1080×1920, 60 fps, 1080 frames. Sin voz en off. Dirección Apple-style aprobada por el usuario: mosaico → pliegue/reorganización → diez categorías anónimas → 10 monumental → cierre institucional.

## Instalar y renderizar

Node 24 y Chromium. El script usa `/usr/bin/chromium`; adaptar esa ruta a otra máquina.

```bash
npm ci --no-audit --no-fund
npm run typecheck
npm run build
npm run render
```

`npm run studio` abre la composición `ToypMosaico` en el puerto 3102. El MP4 se genera en `out/TOYP_40_A_10.mp4`. Tras instalar las dependencias no se necesita red, API o TTS para exportar.

## Materiales y decisiones

Se recibieron 42 JPEG; los archivos 22 y 40 eran idénticos. Se usan las 41 fotografías distintas y una celda de marca en la cuadrícula 6×7. Los nombres y hashes de origen están en `src/photos.json`. El documento de identidad se recortó a su retrato; la foto girada se orientó correctamente. Los originales permanecen intactos en el entorno y no se incluyen en la entrega. Los derivados monocromáticos en `public/photos` bastan para renderizar.

No se seleccionaron diez rostros ni se atribuyeron premios a personas. Las diez tarjetas representan categorías, con siluetas genéricas. Las etiquetas se abrevian para lectura; los nombres completos están en `docs/CATEGORIES.json`. Se utiliza dos columnas por cinco filas para que las etiquetas tengan tamaño suficiente en vertical.

La marca vectorial JCI/TOYP procede del portal oficial y se conserva de los proyectos anteriores. La bajada y el año se componen con Plus Jakarta Sans y Bodoni Moda según la imagen de referencia del usuario; no es copia píxel a píxel del PNG adjunto. Las licencias OFL están junto a los archivos de fuente.

## Música — atribución requerida

**Inspired — Kevin MacLeod (incompetech.com)**

Licensed under Creative Commons Attribution 4.0 International: https://creativecommons.org/licenses/by/4.0/

Source: https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1600022

Adaptación: extracto de 18 segundos desde 01:00, fundidos, automatización de volumen y efectos/percusiones originales superpuestos. El crédito aparece en pantalla; conservar esta atribución en la descripción de la publicación. La página de licencia del editor y metadatos están guardados en `docs/`. La licencia se comprobó en el sitio; no se obtuvo música de TikTok.

El MP3 original y la mezcla final están incluidos. `python scripts/audio.py` reproduce la mezcla con FFmpeg y numpy. Pillow se utilizó para preparar recortes; no hace falta para renderizar los derivados incluidos.

## Editar y verificar

- `src/root.tsx`: geometría, fotografías, máscaras, tarjetas y textos; animación determinista por frame.
- `src/photos.json`: inventario de las 41 fotografías distintas.
- `scripts/audio.py`: mezcla reproducible.
- `scripts/verify.py`: dimensiones, fps, duración, decodificación, pico verdadero, comparación temporal de audio y hoja de encuadres. Requiere FFmpeg, numpy y Pillow.
- `docs/BRIEF.md`: MD original, conservado sin cambios. La planificación conversacional aprobó el tratamiento anónimo y etiquetas breves.

Referencias de diseño: Apple-style Keynote, Seamless Morphing y Build the Floor del repositorio https://github.com/LeaddeOpenLab/awesome-opus-5-5-video-prompts . No se copiaron videos o gráficos de sus creadores.
