"""Prepare the licensed music for this video; source is downloaded, not redistributed."""
from pathlib import Path
import subprocess,urllib.request,tempfile
ROOT=Path(__file__).resolve().parents[1]
subprocess.run(['python',str(ROOT/'scripts/audio-sfx-v5.py')],check=True)
with tempfile.TemporaryDirectory() as directory:
    track=Path(directory)/'close-up.mp3'
    request=urllib.request.Request('https://assets.mixkit.co/music/1167/1167.mp3',headers={'User-Agent':'Mozilla/5.0'})
    track.write_bytes(urllib.request.urlopen(request,timeout=60).read())
    graph='[0:a]atrim=duration=20,asetpts=PTS-STARTPTS,volume=0.34,afade=t=in:d=0.35,afade=t=out:st=19.2:d=0.8[m];[1:a]volume=0.65[s];[m][s]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-16:TP=-1.6:LRA=7,aresample=48000[a]'
    subprocess.run(['ffmpeg','-v','error','-y','-ss','12','-i',str(track),'-i',str(ROOT/'public/audio/v5-sfx.wav'),'-filter_complex',graph,'-map','[a]','-t','20','-ac','2',str(ROOT/'public/audio/full-v5.wav')],check=True)
