"""Package the reproducible complete video project; never include source ID scans."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[1]
archive = root / 'out/v5/TOYP_Completo_V5_Proyecto.zip'
excluded = {'node_modules', 'build', 'out', 'originals', '__pycache__', '.git'}
files = [p for p in sorted(root.rglob('*')) if p.is_file() and not any(part in excluded for part in p.relative_to(root).parts) and p.name not in {'MANIFEST.json', 'full-v5.wav'}]
files += [root / 'out/v5' / name for name in ['verification.json', 'sfx-info.json', 'TOYP_Completo_V5_Encuadres.jpg']]
manifest = [{'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, Path('toyp-mosaico') / p.relative_to(root))
    z.writestr('toyp-mosaico/MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any('/originals/' in n or 'contact-input' in n for n in z.namelist())
    assert len([n for n in z.namelist() if '/public/photos/' in n and n.endswith('.jpg')]) == 41
    for name in ['Film.tsx', 'World.tsx', 'Climax.tsx', 'Closing.tsx', 'design.tsx']:
        assert z.read('toyp-mosaico/src/v5/' + name) == (root / 'src/v5' / name).read_bytes()
print(archive, archive.stat().st_size)
