import {ToypFullV5} from './v5/Film';
import {ToypFullV4} from './v4/Film';
import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Composition,Img,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import photos from './photos.json';
import {ToypMosaicProofV2} from './proof-v2';
import {ToypFullV3} from './v3/Film';
import {World} from './v3/World';
import {Climax} from './v3/Climax';
import {Closing as ClosingV3} from './v3/Closing';
const gold='#F6D58C',white='#F0F8FF';
const c=(n:number)=>Math.max(0,Math.min(1,n));
const ease=(n:number)=>{n=c(n);return n*n*(3-2*n);};
const p=(t:number,a:number,b:number)=>ease((t-a)/(b-a));
const lerp=(a:number,b:number,q:number)=>a+(b-a)*q;
const cats=[['Empresa y','economía'],['Ciencia y','tecnología'],['Medicina','y salud'],['Academia y','educación'],['Cultura y','arte'],['Moral y','ambiente'],['Servicio','humanitario'],['Derechos humanos','y niñez'],['Leyes y','gobierno'],['Superación','personal']];
const full=['Logros Empresariales & Económicos','Desarrollo Científico & Tecnológico','Innovación Médica & Salud','Liderazgo Académico & Educación','Logros Culturales & Artísticos','Liderazgo Moral & Ambiental','Servicio Humanitario & Voluntariado','Derechos Humanos & Niñez','Asuntos Legales & Gobierno','Superación & Logros Personales'];
const Silhouette=()=> <svg width="95" height="135" viewBox="0 0 100 145"><circle cx="50" cy="32" r="20" fill="#e7bd6b15" stroke={gold} strokeWidth="1.5"/><path d="M13 137v-29Q13 72 50 72t37 36v29Z" fill="#e7bd6b12" stroke={gold} strokeWidth="1.5"/><path d="M28 108v29m44-29v29" stroke={gold} opacity=".5"/></svg>;
const cell=(i:number)=>({x:42+(i%6)*167,y:500+Math.floor(i/6)*176,w:156,h:164});
const card=(i:number)=>({x:72+(i%2)*478,y:425+Math.floor(i/2)*219,w:458,h:195});
const pieces=[{x:215,y:640,w:175,h:120,r:-35},{x:285,y:680,w:125,h:200,r:0},{x:285,y:875,w:125,h:210,r:0},{x:205,y:1080,w:285,h:105,r:0},{x:570,y:560,w:290,h:115,r:0},{x:520,y:650,w:110,h:220,r:0},{x:800,y:650,w:110,h:220,r:0},{x:520,y:865,w:110,h:220,r:0},{x:800,y:865,w:110,h:220,r:0},{x:570,y:1070,w:290,h:115,r:0}];
const Mosaic:React.FC<{t:number}>=({t})=>{
 const fold=p(t,4.7,6.65),q=p(t,0,2.8),opacity=1-p(t,6.25,6.7);
 return <AbsoluteFill style={{perspective:1800,opacity}}><AbsoluteFill style={{transformOrigin:'50% 50%',transform:`rotateY(${-7+q*4}deg) rotateX(${3-q*2}deg) rotateZ(${-1.7+q*.9}deg) scale(${1.09-q*.06}) translateY(${q*-16}px)`}}>
 {Array.from({length:42},(_,i)=>{const s=cell(i),dest=card(i%10),delay=(i%6)*.035,f=p(t,4.7+delay,6.5+delay);return <div key={i} style={{position:'absolute',left:lerp(s.x,dest.x+dest.w/2-50,f),top:lerp(s.y,dest.y+dest.h/2-65,f),width:lerp(s.w,100,f),height:lerp(s.h,130,f),overflow:'hidden',borderRadius:lerp(5,15,f),background:'#092036',border:`1px solid ${t>3?gold+'55':'#8bb6c02b'}`,boxShadow:'0 10px 22px #0005',transform:`rotateY(${f*90}deg) translateZ(${f*70}px)`,opacity:1-fold*.7}}>
 {i<41?<Img src={staticFile(photos[i].asset)} style={{width:'100%',height:'100%',objectFit:i===32?'contain':'cover',filter:`contrast(1.04) brightness(${.65+p(t,3+(i%7)*.1,3.3+(i%7)*.1)*.12})`}}/>:<div style={{height:'100%',display:'flex',alignItems:'center',padding:12}}><Img src={staticFile('toyp-mark.svg')} style={{width:'100%'}}/></div>}
 </div>;})}
 </AbsoluteFill>
 {t>3&&t<6.3&&<div style={{position:'absolute',left:30,right:30,top:180+p(t,3,5.3)*1510,height:2,background:gold,boxShadow:'0 0 22px 5px #edc77866',opacity:1-p(t,5.7,6.3)}}/>}
 <AbsoluteFill style={{background:'linear-gradient(0deg,#000b1ae0,transparent 26%,transparent 72%,#000b1aaa)'}}/>
 </AbsoluteFill>;
};
const Cards:React.FC<{t:number}>=({t})=>{
 const reveal=p(t,5.8,6.9),morph=p(t,11.35,12.4);
 return <AbsoluteFill style={{opacity:reveal*(1-p(t,12.25,12.65)),perspective:1800}}>{cats.map((labels,i)=>{
 const a=card(i),b=pieces[i],lift=p(t,5.8+i*.04,6.8+i*.04);
 return <div key={i} style={{position:'absolute',left:lerp(a.x,b.x,morph),top:lerp(a.y,b.y,morph),width:lerp(a.w,b.w,morph),height:lerp(a.h,b.h,morph),borderRadius:lerp(17,4,morph),background:morph>.65?gold:'linear-gradient(130deg,#14283a,#07182a)',border:`1px solid ${gold}`,boxShadow:'0 13px 38px #0008,inset 0 1px 0 #fff2',overflow:'hidden',transform:`translateY(${(1-lift)*95}px) rotateY(${(1-lift)*-70}deg) rotateZ(${b.r*morph}deg)`}}>
 <div style={{opacity:1-p(t,11.35,11.85),position:'absolute',inset:0}}>
 <div style={{position:'absolute',left:21,top:16,fontSize:24,fontWeight:700,color:gold}}>{String(i+1).padStart(2,'0')}</div>
 <div style={{position:'absolute',left:24,top:45}}><Silhouette/></div>
 <div style={{position:'absolute',left:139,top:65,right:15,fontSize:labels[0].length>14?24:28,lineHeight:1.25,fontWeight:600,color:white}}>{labels[0]}<br/>{labels[1]}</div>
 <div style={{position:'absolute',left:139,top:155,fontSize:12,letterSpacing:1.8,color:gold}}>CATEGORÍA TOYP 2026</div>
 </div></div>;
 })}</AbsoluteFill>;
};
const Title:React.FC<{t:number}>=({t})=>{
 if(t<3)return <div style={{position:'absolute',left:70,right:70,top:60,textAlign:'center',background:'#001026d9',borderTop:'1px solid #d4af3760',borderBottom:'1px solid #d4af3760',padding:'30px 20px',clipPath:`inset(0 0 ${p(t,2.65,3)*100}% 0)`,transform:`translateY(${(1-p(t,.12,.7))*80}px)`,opacity:p(t,.05,.35)}}><div style={{fontSize:132,fontWeight:800,letterSpacing:-7,color:white}}>+40</div><div style={{fontSize:49,fontWeight:700,letterSpacing:-1}}>POSTULACIONES RECIBIDAS</div><div style={{fontSize:23,letterSpacing:3.5,color:'#c8d7e3',marginTop:22}}>HISTORIAS DE IMPACTO EN VENEZUELA</div></div>;
 if(t<6.5)return <div style={{position:'absolute',left:60,right:60,top:715,textAlign:'center',background:'#000b1ae8',padding:'35px 20px',opacity:p(t,3,3.3)*(1-p(t,5.9,6.5))}}><div style={{fontSize:58,fontWeight:700,lineHeight:1.15}}>UN JURADO<br/>CALIFICADOR</div><div style={{fontSize:26,letterSpacing:3,color:gold,marginTop:26}}>UNA DECISIÓN HISTÓRICA</div></div>;
 if(t<11.5)return <><div style={{position:'absolute',left:70,right:70,top:190,textAlign:'center',fontSize:56,fontWeight:700,letterSpacing:-1,opacity:p(t,6.5,6.9)*(1-p(t,11.1,11.5))}}>10 CATEGORÍAS.<br/><span style={{color:gold}}>UN MISMO HONOR.</span></div><div style={{position:'absolute',left:0,right:0,top:1620,textAlign:'center',fontSize:25,color:'#9ab2c5',opacity:1-p(t,11,11.5)}}>Los galardonados están por revelarse.</div></>;
 return null;
};
const Closing:React.FC<{t:number}>=({t})=>{const a=p(t,14.5,15.05);return <AbsoluteFill style={{opacity:a,transform:`scale(${.96+.04*a})`}}>
 <div style={{position:'absolute',left:320,top:130,width:440,textAlign:'center'}}><Img src={staticFile('toyp-mark.svg')} style={{width:440}}/><div style={{fontSize:21,lineHeight:1.5,marginTop:12}}>10 JÓVENES SOBRESALIENTES<br/>VENEZUELA 2026</div><div style={{fontFamily:'Bodoni',fontSize:140,lineHeight:1.15,marginTop:15}}>2026</div></div>
 <div style={{position:'absolute',left:50,right:50,top:780,textAlign:'center',fontSize:34,fontWeight:600}}>28 DE NOVIEMBRE · VALENCIA, VENEZUELA</div>
 <div style={{position:'absolute',left:245,top:870,width:590,border:'1px solid #00b4d866',borderRadius:50,padding:'17px 20px',textAlign:'center',fontSize:25,color:'#81d8e5'}}>TRANSMISIÓN EN VIVO VÍA ZOOM HD</div>
 <div style={{position:'absolute',left:75,right:75,top:1020,textAlign:'center',fontSize:45,fontWeight:700,lineHeight:1.2}}>Asocia el prestigio de tu marca<br/>a los 10 galardonados.</div>
 <div style={{position:'absolute',left:90,right:90,top:1220,height:1,background:'#d7b97555'}}/>
 <div style={{position:'absolute',left:0,right:0,top:1290,textAlign:'center',fontSize:35,lineHeight:1.9,color:white}}>+58 422 639 5360<br/>+58 412 430 4815</div>
 <div style={{position:'absolute',left:0,right:0,top:1460,textAlign:'center',fontSize:43,fontWeight:600,color:gold}}>toypvzla@gmail.com</div>
 <div style={{position:'absolute',left:0,right:0,top:1610,textAlign:'center',fontSize:27,color:'#aec1d2'}}>Cupos de patrocinio limitados</div>
 </AbsoluteFill>;};
const Film:React.FC=()=>{
 const t=useCurrentFrame()/60;
 const [h]=useState(()=>delayRender('Fonts'));useEffect(()=>{Promise.all(['800 100px Jakarta','600 28px Jakarta','400 140px Bodoni'].map(s=>document.fonts.load(s))).then(()=>continueRender(h)).catch(cancelRender);},[h]);
 const close=p(t,14.35,14.95),number=p(t,12.1,12.65);
 return <AbsoluteFill style={{background:'#000b1a',color:white,fontFamily:'Jakarta',overflow:'hidden'}}><style>{`@font-face{font-family:Jakarta;src:url('${staticFile('fonts/PlusJakartaSans.ttf')}');font-weight:200 800}@font-face{font-family:Bodoni;src:url('${staticFile('fonts/BodoniModa.ttf')}');font-weight:400 900}*{box-sizing:border-box}`}</style><Audio src={staticFile('audio/final.wav')}/><AbsoluteFill style={{background:'radial-gradient(ellipse at 50% 35%,#0a2d43 0%,#000b1a 76%)'}}/>
 <AbsoluteFill style={{opacity:1-close,transformOrigin:'50% 35%',transform:`translateY(${-close*220}px) scale(${1-close*.65})`}}>
 {t<6.7&&<Mosaic t={t}/>}<Cards t={t}/><Title t={t}/>
 {t>=11.5&&<><div style={{position:'absolute',left:0,right:0,top:320,textAlign:'center',fontSize:78,fontWeight:700,letterSpacing:13,color:gold,opacity:p(t,11.5,11.9)}}>SOLO</div><div style={{position:'absolute',left:0,right:0,top:440,textAlign:'center',fontSize:610,lineHeight:1.15,fontWeight:800,letterSpacing:-35,color:gold,opacity:number}}>10</div><div style={{position:'absolute',left:80,right:80,top:1250,textAlign:'center',fontSize:49,fontWeight:700,lineHeight:1.2,opacity:p(t,12.5,12.9)}}>PORTARÁN EL GALARDÓN<br/>TOYP VENEZUELA 2026</div><div style={{position:'absolute',left:0,right:0,top:1450,textAlign:'center',fontSize:28,color:'#b7c9d7',opacity:p(t,12.7,13.1)}}>10 jóvenes. Un país en transformación.</div></>}
 </AbsoluteFill>
 {t>=14.5&&<Closing t={t}/>}
 <div style={{position:'absolute',left:0,right:0,bottom:32,fontSize:14,color:'#8da3b4',textAlign:'center',opacity:t>=14.5?.8:0}}>Música: Inspired — Kevin MacLeod · CC BY 4.0 · incompetech.com</div>
 </AbsoluteFill>;
};
export const Root:React.FC=()=> <>
  <Composition id="ToypFullV5" component={ToypFullV5} durationInFrames={1200} fps={60} width={1080} height={1920}/>
  <Composition id="ToypFullV4" component={ToypFullV4} durationInFrames={1200} fps={60} width={1080} height={1920}/>
  <Composition id="ToypFullV3" component={ToypFullV3} durationInFrames={1200} fps={60} width={1080} height={1920}/>
  <Composition id="ToypWorldV3" component={World} durationInFrames={780} fps={60} width={1080} height={1920}/>
  <Composition id="ToypClimaxV3" component={Climax} durationInFrames={180} fps={60} width={1080} height={1920}/>
  <Composition id="ToypClosingV3" component={ClosingV3} durationInFrames={240} fps={60} width={1080} height={1920}/>
  <Composition id="ToypMosaico" component={Film} durationInFrames={1080} fps={60} width={1080} height={1920}/>
  <Composition id="ToypMosaicProofV2" component={ToypMosaicProofV2} durationInFrames={390} fps={60} width={1080} height={1920}/>
</>;
