import React from 'react';
import {AbsoluteFill,Audio,Sequence,staticFile,useCurrentFrame,useVideoConfig} from 'remotion';
import {World} from './World';
import {Climax} from './Climax';
import {Closing} from './Closing';
import {p} from './design';
export const ToypFullV5:React.FC=()=>{
const {fps}=useVideoConfig();const t=useCurrentFrame()/fps;
return <AbsoluteFill style={{background:'#000914'}}><Audio src={staticFile('audio/full-v5.wav')}/>
<Sequence name="Logo, mosaico y tarjetas" durationInFrames={Math.round(13.35*fps)} premountFor={fps}><AbsoluteFill style={{opacity:1-p(t,12.65,13.35),transform:`scale(${1-.035*p(t,12.65,13.35)})`}}><World/></AbsoluteFill></Sequence>
<Sequence name="SOLO 10 con relieve" from={Math.round(12.65*fps)} durationInFrames={Math.round(3.7*fps)} premountFor={fps}><AbsoluteFill style={{opacity:p(t,12.65,13.35)*(1-p(t,15.65,16.35))}}><Climax/></AbsoluteFill></Sequence>
<Sequence name="Cierre animado" from={Math.round(15.65*fps)} durationInFrames={Math.round(4.35*fps)} premountFor={fps}><AbsoluteFill style={{opacity:p(t,15.65,16.35)}}><Closing/></AbsoluteFill></Sequence></AbsoluteFill>;
};
