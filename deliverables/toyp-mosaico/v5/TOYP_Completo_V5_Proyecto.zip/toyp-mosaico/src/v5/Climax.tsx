import React from 'react';
import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import {Canvas,GOLD,p} from './design';
export const Climax:React.FC=()=>{
const t=useCurrentFrame()/useVideoConfig().fps, shine=p(t,.6,2.1);
const type:React.CSSProperties={position:'absolute',inset:0,fontSize:540,lineHeight:1.12,fontWeight:800,letterSpacing:-30,paddingRight:30};
return <Canvas><AbsoluteFill style={{background:'radial-gradient(ellipse at 50% 45%,#182d3b,#000914 75%)'}}/>
<div style={{position:'absolute',left:120,right:120,top:415,fontSize:88,fontWeight:700,letterSpacing:10,background:`linear-gradient(110deg,${GOLD} 38%,#fffaf0 49%,${GOLD} 60%)`,backgroundSize:'250% 100%',backgroundPosition:`${110-shine*220}% 0`,WebkitBackgroundClip:'text',color:'transparent'}}>SOLO</div>
<div style={{position:'absolute',left:110,right:110,top:535,height:620,perspective:1500}}><div style={{position:'absolute',inset:0,transformStyle:'preserve-3d',transform:`rotateX(${9-5*p(t,0,3.4)}deg) rotateY(${-13+19*p(t,0,3.4)}deg) scale(${.94+.06*p(t,0,.9)})`}}>
{Array.from({length:14},(_,i)=><div key={i} style={{...type,color:i%2?'#8e6228':'#a57632',transform:`translateZ(${-14+i}px) translate(${(14-i)*.7}px,${(14-i)*.5}px)`}}>10</div>)}
<div style={{...type,background:'linear-gradient(130deg,#fff0c2,#dbad56 54%,#a47732)',WebkitBackgroundClip:'text',color:'transparent',transform:'translateZ(1px)'}}>10</div>
<div style={{...type,background:'linear-gradient(110deg,transparent 40%,#fff9e6c0 49%,transparent 58%)',backgroundSize:'300% 100%',backgroundPosition:`${110-shine*220}% 0`,WebkitBackgroundClip:'text',color:'transparent',transform:'translateZ(2px)'}}>10</div></div></div>
<div style={{position:'absolute',left:120,right:120,top:1220,fontSize:46,lineHeight:1.3,fontWeight:700,opacity:p(t,.35,.85),transform:`translateY(${24*(1-p(t,.35,.85))}px)`}}>PORTARÁN EL GALARDÓN<br/>TOYP 2026</div>
<div style={{position:'absolute',left:120,right:120,top:1400,fontSize:34,lineHeight:1.4,color:'#bbc7d3',opacity:p(t,.55,1)}}>10 jóvenes.<br/>Un país en transformación.</div></Canvas>;
};
