# Dirección actual — V4: el directo pierde el control

La conversación del usuario reemplazó expresamente el freezer y el one-take obligatorio. La dirección aprobada está en `docs/V4_DIRECTION.md`. Conservar V1–V3; las instrucciones de estética freezer inferiores son históricas y no se aplican a V4. Tipografía: Bebas Neue, Anton e IBM Plex Mono. Ungüento blanco opaco y supermercado chino de barrio son requisitos explícitos.

# Codex instructions — CHEKI Freezer

Read `docs/PRODUCTION_BRIEF.md`, `docs/SCENE_PLAN.md`, `docs/QUALITY_GATES.md`, and `docs/ASSET_PROVENANCE.md` BEFORE changing implementation.

**Goal**: produce a polished 42.893061 s, 1080x1920, 30 fps lyric video from the user-supplied audio. Treat the existing Remotion code as an incomplete prototype, NOT a completed production. Deliver final MP4 with verified audio/video.

**Nonnegotiable**:
- A genuine, scene-based freezer environment in dark blue, electric blue and purple; independent visual layers and coordinated camera movement.
- Do NOT present pan/zoom across flattened storyboard crops as finished animated sequences.
- Text/lyric timing MUST be manually checked against supplied audio; `remotion/src/timeline.ts` is inaccurate and incomplete. No claims of word-perfect sync without verification.
- Keep displayed text readable on mobile; identify and eliminate baked-in 'LETRA FRASE' placeholders and poster labels.
- Prefer reproducible, frame-deterministic animation using Remotion. FFmpeg is acceptable for finishing and verification.
- Cite provenance in project notes; no commercial-release-rights claims from the supplied file.

**Workflow**: inspect existing resources -> inspect and repair toolchain -> map audio/transcript -> build 1 fully animated 5-8 s proof -> render/check proof -> complete scene system -> render/check full video -> deliver MP4 plus source.

Try `cd remotion && npm install && npm run studio`, then CLI render. If network or Chromium blocks progress, report precisely and use an installed rendering pipeline, keeping source portable. Don't silently substitute low-effort slide sequences.
