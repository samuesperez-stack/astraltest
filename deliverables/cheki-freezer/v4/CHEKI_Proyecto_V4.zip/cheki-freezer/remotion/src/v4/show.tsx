import React, {useEffect,useState} from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import lyrics from '../lyrics.json';
import features from '../audio-features.json';

const clamp=(v:number)=>Math.max(0,Math.min(1,v));
const prog=(t:number,a:number,b:number)=>clamp((t-a)/(b-a));
const ease=(v:number)=>1-Math.pow(1-clamp(v),3);
const at=(name:string)=>staticFile(`assets/v4/${name}`);
const ink='#fff7e8', gold='#ffce66';
const mono={fontFamily:'IBMPlexMono',fontSize:24} as const;
const starts=[0,2.93,5.64,8.18,10.95,13.28,16.12,18.25,21.14,23.78,26.4,29,31.78,34.23,36.92,39.61];
const backdrops=['room','room','room','classroom','classroom','bureau','bureau','theatre','theatre','supermarket','supermarket','room','control','control','finalstage','finalstage'];

const Prop:React.FC<{name:string;x:number;y:number;w:number;rotate?:number;scale?:number;opacity?:number;flip?:boolean}>=({name,x,y,w,rotate=0,scale=1,opacity=1,flip=false})=>(
  <Img src={at(name+'.png')} style={{position:'absolute',left:x,top:y,width:w,opacity,transformOrigin:'50% 80%',transform:`rotate(${rotate}deg) scale(${flip?-scale:scale},${scale})`}}/>
);

const Papers:React.FC<{t:number;start:number;count?:number}>=({t,start,count=14})=><AbsoluteFill>{Array.from({length:count},(_,i)=>{
 const p=prog(t,start+(i%4)*.055,start+1.1+(i%4)*.055),angle=i*2.399;
 return <div key={i} style={{position:'absolute',left:480+Math.cos(angle)*p*920,top:1030-Math.sin(angle)*p*500-p*300+p*p*580,width:160,height:65,background:'#f4ead8',color:'#151820',opacity:t>=start?1:0,transform:`rotate(${i*23+p*220}deg) scale(${.4+p*.8})`,boxShadow:'0 8px 15px #0005',fontFamily:'BebasNeue',fontSize:23,padding:8}}>VERSO {String(i+1).padStart(2,'0')}<div style={{height:3,background:'#1a1a1a',marginTop:4,width:'75%'}}/></div>;
 })}</AbsoluteFill>;

const Background:React.FC<{name:string;t:number;scene:number;foreground?:boolean}>=({name,t,scene,foreground=false})=>{
 const age=t-starts[scene],s=1.045+Math.min(age,3)*.014;
 return <Img src={at(name+'.jpg')} style={{position:'absolute',width:1080,height:1920,objectFit:'cover',transform:`scale(${s}) translate(${Math.sin(age*.55)*9}px,${Math.cos(age*.4)*7}px)`,clipPath:foreground?`inset(${name==='bureau'?'55':name==='supermarket'?'68':'69'}% 0 0 0)`:undefined}}/>;
};

function rows(words:typeof lyrics.cues[number]['words']){
 if(words.length<3)return [words];
 let best=1,score=Infinity;
 for(let i=1;i<words.length;i++){
 const n=Math.max(words.slice(0,i).map(w=>w.word).join(' ').length,words.slice(i).map(w=>w.word).join(' ').length);
 if(n<score){score=n;best=i;}
 }
 return words.map(w=>w.word).join(' ').length<=20?[words]:[words.slice(0,best),words.slice(best)];
}
const Lyric:React.FC<{t:number;scene:number}>=({t,scene})=>{
 const cue=lyrics.cues.find(c=>t>=c.start&&t<c.end);
 if(!cue||t>=15.378&&t<16.12||t>=42.169)return null;
 let words=cue.words;
 if(scene===6)words=words.filter(w=>t>=w.start&&t<w.end);
 const lines=rows(words),maxChars=Math.max(...lines.map(r=>r.map(w=>w.word).join(' ').length));
 const size=Math.min(scene===6?150:116,900/(maxChars*.48));
 const whiteRibbon=scene===1;
 return <div style={{position:'absolute',left:75,right:75,top:scene===13?190:245,textAlign:'center',fontFamily:'BebasNeue',fontSize:size,lineHeight:1.04,letterSpacing:1.2,textTransform:'uppercase',color:whiteRibbon?'#16191e':ink,textShadow:whiteRibbon?'none':'0 4px 9px #000d',transform:`translateY(${(1-ease(prog(t,cue.start,cue.start+.16)))*35}px)`,opacity:Math.min(1,prog(t,cue.start,cue.start+.065),prog(cue.end-t,0,.08))}}>
 {lines.map((row,i)=><div key={i} style={{whiteSpace:'nowrap'}}>{row.map((w,j)=>{
 const age=t-w.start,active=age>=0&&t<w.end;
 const raw=w.word.replace(/[^\p{L}]/gu,'').toLowerCase();
 const hit=['barro','garras','doble','vuelo','sueno','deceso','agarre'].includes(raw);
 let transform=`scale(${active?1+Math.sin(clamp(age/.2)*Math.PI)*.09:1})`;
 if(raw==='barro')transform+=` translateY(${Math.pow(prog(t,2.52,2.85),2)*24}px) skewX(${prog(t,2.52,2.85)*-10}deg)`;
 return <React.Fragment key={w.start}><span style={{display:'inline-block',color:active&&hit&&!whiteRibbon?gold:undefined,opacity:t<w.start?.58:1,transform,transformOrigin:'50% 80%'}}>{w.word}</span>{j<row.length-1?' ':''}</React.Fragment>;
 })}</div>)}
 </div>;
};

const Cage:React.FC<{t:number}>=({t})=>{
 const rise=ease(prog(t,.7,1.45)),melt=prog(t,2.3,2.86);
 return <AbsoluteFill style={{opacity:1-melt}}><svg width="1080" height="1920" style={{transform:`translateY(${(1-rise)*1800}px)`}}><defs><linearGradient id="steel"><stop stopColor="#25303e"/><stop offset=".33" stopColor="#d9dce0"/><stop offset=".6" stopColor="#697585"/><stop offset="1" stopColor="#17202c"/></linearGradient></defs>{[80,270,460,650,840,1030].map((x,i)=><path key={i} d={`M${x} 700 Q${x+Math.sin(i)*melt*240} ${1100+melt*250} ${x} ${1850+melt*400}`} stroke="url(#steel)" strokeWidth="30" fill="none"/>)}<path d="M0 720H1080M0 1640H1080" stroke="url(#steel)" strokeWidth="36"/></svg></AbsoluteFill>;
};

const Cream:React.FC<{t:number}>=({t})=>{
 const p=ease(prog(t,3.45,4.15));
 return <svg width="1080" height="1920" style={{position:'absolute',inset:0}}><defs><linearGradient id="cream" x2="0" y2="1"><stop stopColor="#ffffff"/><stop offset=".6" stopColor="#fff"/><stop offset="1" stopColor="#dedee4"/></linearGradient></defs><path d="M1130 1230C340 1420 150 1100 780 1030S1060 700 540 660S-110 640 15 480Q110 360 540 370T1160 350" fill="none" stroke="url(#cream)" strokeWidth="90" strokeLinecap="round" strokeDasharray="4000" strokeDashoffset={4000*(1-p)}/><path d="M180 370Q420 330 580 365T900 365" fill="none" stroke="url(#cream)" strokeWidth="330" strokeLinecap="round"/></svg>;
};

const SystemBox:React.FC<{x:number;y:number;w:number;title:string;children:React.ReactNode;rotate?:number}>=({x,y,w,title,children,rotate=0})=><div style={{position:'absolute',left:x,top:y,width:w,background:'#101723f5',border:'2px solid #8fadc1',boxShadow:'12px 18px 0 #0006',color:ink,transform:`rotate(${rotate}deg)`}}><div style={{...mono,fontSize:20,padding:'14px 20px',borderBottom:'1px solid #8fadc1',display:'flex',justifyContent:'space-between'}}><span>{title}</span><span>— □ ×</span></div><div style={{padding:26}}>{children}</div></div>;

const Action:React.FC<{t:number;scene:number;energy:number}>=({t,scene,energy})=>{
 const age=t-starts[scene],bob=Math.sin(t*2)*5+energy*3;
 let pose='xokas-talk',x=265,y=810,w=600,rot=0,scale=1;
 if(scene===1){pose='xokas-tube';x=245;y=740;w=620;}
 if(scene===2){pose='xokas-react';}
 if(scene===4){pose='xokas-react';}
 if(scene===5||scene===6){pose='xokas-react';x=400;y=670;w=570;}
 if(scene===6){
   if(t<16.855)scale=1+prog(t,16.12,16.8)*.5;
   if(t>=17.632){pose='xokas-talk';scale=1;}
 }
 if(scene===8&&t>=22.84){pose='xokas-compress';x=275;y=750;w=600;}
 if(scene===9||scene===10){pose='xokas-react';x=565;y=770;w=490;}
 if(scene===11){pose='xokas-fly';x=220;y=800-prog(t,30.65,31.78)**2*2200;w=650;rot=-prog(t,30.5,31.78)*12;}
 if(scene===12){pose='xokas-fly';x=245;y=800;rot=Math.sin(age*2)*6;}
 if(scene===13){pose='xokas-react';x=280;y=970;w=560;}
 if(scene>=14){pose='xokas-win';x=230;y=850;w=650;}
 return <>
 {scene===1&&<Cream t={t}/>}
 {scene===0&&<>
   <SystemBox x={85} y={570} w={430} title="CHAT · EN DIRECTO" rotate={-3}><div style={{...mono,color:gold}}>chat: te pedimos</div><div style={{fontFamily:'Anton',fontSize:62,marginTop:8}}>16 BARRAS</div></SystemBox>
 </>}
 {scene===6&&t>=16.855&&t<17.632?<>{[0,1,2].map(i=><div key={i} style={{position:'absolute',inset:0,clipPath:`inset(${i*33}% 0 ${66-i*33}% 0)`,transform:`translateX(${Math.sin(t*24+i)*70}px)`}}><Prop name={pose} x={x} y={y} w={w}/></div>)}</>:<Prop name={pose} x={x} y={y+bob} w={w} rotate={rot} scale={scale}/>}
 {(scene===0||scene===1||scene===2||scene===5||scene===6||scene===9||scene===10)&&<Background name={backdrops[scene]} t={t} scene={scene} foreground/>}
 {scene===0&&<><Cage t={t}/>{t>2.3&&Array.from({length:9},(_,i)=><Prop key={i} name="mud" x={-100+i*145} y={1400+Math.sin(i)*100+prog(t,2.3,2.9)*350} w={320} scale={prog(t,2.3,2.6)} rotate={i*25}/>)}</>}
 {scene===1&&<Prop name="mud" x={20} y={1350} w={380} opacity={1-prog(t,3.5,4.4)}/>}
 {scene===2&&<><Papers t={t} start={6.1}/><Prop name="hand" x={620-ease(prog(t,7.3,7.9))*180} y={1700-ease(prog(t,7.3,7.9))*650} w={560} rotate={-25+prog(t,7.4,8.1)*35}/></>}
 {scene===3&&<>
   <div style={{position:'absolute',inset:0,overflow:'hidden',clipPath:`polygon(0 0,${100-prog(t,8.18,9.8)*100}% 0,${100-prog(t,8.18,9.8)*100}% 100%,0 100%)`}}><Background name="room" t={t} scene={scene}/></div>
   <Prop name="metal-claw" x={-680+ease(prog(t,8.5,9.7))*1900} y={580} w={700} rotate={-35}/>
   <svg width="1080" height="1920" style={{position:'absolute',inset:0,opacity:prog(t,9.25,9.5)*(1-prog(t,10,10.6))}}>{[0,1,2].map(i=><path key={i} d={`M${240+i*180} 540L${390+i*180} 1400`} stroke="#bdefff" strokeWidth={9-i*2}/>)}</svg>
   {t>=9.667&&[0,1].map(i=><div key={i} style={{position:'absolute',left:i?730:15,top:i?810:600,width:300,height:210,background:'#15302b',border:'12px solid #8c6741',transform:`rotate(${i?12:-10}deg) translateY(${Math.sin(age*2+i)*18}px)`,fontFamily:'BebasNeue',fontSize:64,color:'#f9f4dc',padding:20}}>{i?'AQUELARRES':'PIZARRAS'}</div>)}
 </>}
 {scene===4&&t>=12.1&&<div style={{position:'absolute',left:90,top:650,width:900,background:'#360c16ef',border:'3px solid #eb4663',padding:35,textAlign:'center',transform:`translateX(${ease(prog(t,12.75,13.21))*1350}px) rotate(-4deg)`}}><div style={{...mono,color:'#ff8095'}}>LA PARTIDA HA TERMINADO</div><div style={{fontFamily:'Anton',fontSize:140}}>DECESO</div><div style={{...mono}}>VOLVER A INTENTAR ↵</div></div>}
 {scene===5&&<>
   {t<15.378&&<SystemBox x={65} y={630} w={480} title="PROCESO EN TRÁMITE"><div style={mono}>SOLICITUD DE RIMA<br/><br/>☐ CONTEMPLATIVO<br/>☐ PERIFRÁSTICO<br/><br/>ESTADO: ESPERANDO...</div></SystemBox>}
   {t>=15.378&&<><div style={{position:'absolute',left:55,top:480,width:420,height:400,overflow:'hidden',background:'#15110f',border:'14px solid #8a6941',boxShadow:'inset 0 0 30px #000,8px 12px 15px #0008'}}><Prop name="illojuan" x={-5} y={35*(1-ease(prog(t,15.378,15.52)))} w={410}/></div><div style={{position:'absolute',left:55,top:350,fontFamily:'Anton',fontSize:104,transform:'rotate(-5deg)',color:gold,textShadow:'0 5px 8px #000'}}>¿UN PERI QUÉ?</div><Papers t={t} start={15.7} count={18}/></>}
 </>}
 {scene===6&&t>=17.632&&<svg width="1080" height="1920" style={{position:'absolute',inset:0}}><path d="M660 0L120 1460H1080Z" fill="#fff0b0" opacity=".17"/><ellipse cx="640" cy="1430" rx="430" ry="100" fill="#fff5b8" opacity=".16"/></svg>}
 {scene===7&&t>=20.192&&<>{[0,1].map(i=><div key={i} style={{position:'absolute',width:190,height:1450,top:-300+prog(t,20.192,21.14)**2*1500,left:i?860:30,background:'repeating-linear-gradient(90deg,#591b25,#8c2834 40px,#350d15 60px)',transformOrigin:'50% 0%',transform:`rotate(${(i?-1:1)*prog(t,20.192,21.14)*40}deg)`}}/>) }<Papers t={t} start={20.4} count={8}/></>}
 {scene===8&&<>
   <Prop name="noble" x={10} y={720} w={280} rotate={Math.sin(t*6)*5*prog(t,21.97,22.6)}/>
   {t>21.97&&[0,1,2].map(i=><div key={i} style={{position:'absolute',left:175+Math.sin(t*5+i)*20,top:640-i*85-prog(t,21.97,22.84)*120,color:'#ff7698',fontSize:65,opacity:1-i*.2}}>♥</div>)}
   {t<23.45?<Prop name="oak" x={550} y={450+prog(t,22.84,23.45)*780} w={720} scale={1-prog(t,22.84,23.45)*.75}/>:<Prop name="bonsai" x={650} y={1180} w={235} rotate={-prog(t,23.45,23.78)*10}/>}
 </>}
 {scene===9&&<>
   {Array.from({length:12},(_,i)=>{const b=24.65+i*.105,p=ease(prog(t,b,b+.65));return t<b?null:<Prop key={i} name={['bonsai','noodles','oil','rice','cereal','can'][Math.floor(i/2)]} x={470+(i%2?1:-1)*p*(180+(i%3)*70)} y={1320-p*180+Math.floor(i/4)*90} w={160+Math.floor(i/4)*25} rotate={(i%2?1:-1)*p*18}/>;})}
   {t>24.7&&<div style={{position:'absolute',left:20,top:1210,width:1040,height:6,background:'#ff3349',boxShadow:'0 0 24px #ff3349',transform:`translateY(${Math.sin(t*18)*30}px)`}}/>}
 </>}
 {scene===10&&<>
   <div style={{position:'absolute',left:70,top:690,width:940,height:720,border:'3px solid #76d9f9',background:'#0c1828b8',boxShadow:'inset 0 0 80px #000'}}><div style={{...mono,padding:20,display:'flex',justifyContent:'space-between'}}><span>PLAYER 01</span><span>DUEL</span><span>PLAYER 02</span></div><div style={{position:'absolute',top:90,left:35,width:350,height:15,background:gold}}/><div style={{position:'absolute',top:90,right:35,width:350*(1-prog(t,27.65,27.85)),height:15,background:'#ff456d'}}/></div>
   <Prop name="noodles" x={140+prog(t,27.4,27.65)*150} y={980} w={220} rotate={prog(t,27.4,27.65)*18}/>
   <Prop name="noodles" x={690+prog(t,27.65,28.1)*500} y={980+prog(t,27.65,28.1)**2*600} w={220} rotate={-prog(t,27.65,28.1)*150} flip/>
   <div style={{position:'absolute',left:470,top:900,fontSize:100,color:gold,fontFamily:'Anton'}}>+</div>
   {t>27.7&&<div style={{position:'absolute',left:150,right:150,top:1150,textAlign:'center',fontFamily:'Anton',fontSize:110,color:gold}}>PERFECT</div>}
 </>}
 {scene===11&&<>
   {t<30.65&&<SystemBox x={110} y={570} w={860} title="TIEMPO SIN RIMAR"><div style={{fontFamily:'Anton',fontSize:110,textAlign:'center'}}>{Math.round(ease(prog(t,29,30.1))*15).toString().padStart(2,'0')} AÑOS</div></SystemBox>}
   {t>=30.65&&<svg width="1080" height="1920" style={{position:'absolute',inset:0}}>{Array.from({length:14},(_,i)=><path key={i} d={`M${i*90-60} ${((t*1700+i*149)%2100)-200}v${150+i%3*100}`} stroke="#e5edff" strokeWidth="5" opacity=".6"/>)}</svg>}
 </>}
 {scene===12&&<>{['FLAMA','KARL KANI'].map((s,i)=>{const a=prog(t,31.9+i*.8,32.15+i*.8);return <SystemBox key={s} x={80+i*370} y={580+i*130} w={500} title="SELECCIONAR VESTUARIO" rotate={i?7:-7}><div style={{fontFamily:'Anton',fontSize:64}}>{s}</div><div style={{fontFamily:'Anton',fontSize:110,color:'#ff496c',opacity:a}}>×</div></SystemBox>;})}</>}
 {scene===13&&<>
   {[0,1,2].map(i=><SystemBox key={i} x={50+i*140} y={700+i*90} w={600} title={['RENDER ENGINE','AMAZING MECHANICS','SYSTEM OVERLOAD'][i]} rotate={(i-1)*7}><div style={{...mono,color:i===2?'#ff708c':'#9ee7d5'}}>frames: {Math.floor(t*30)} / 1287<br/>realidad.exe → {i===2?'ERROR':'PROCESANDO'}<br/>calidad: MAX</div></SystemBox>)}
   {t>=35.15&&<div style={{position:'absolute',left:60,right:60,top:480,padding:'24px 25px',background:gold,color:'#101723',border:'5px solid #fff3cb',transform:`rotate(-3deg) scale(${.92+.08*ease(prog(t,35.15,35.35))})`,boxShadow:'12px 15px 0 #0008',fontFamily:'Anton',fontSize:74,lineHeight:1.1,textAlign:'center'}}>ESTOY CODIFICANDO<br/>A MÁXIMA CALIDAD</div>}
   <Prop name="bonsai" x={770} y={1500} w={160}/>
 </>}
 {scene>=14&&<>
   {[['SPOK',37.25,50],['JUANITO',38.1,380],['SCENO',39.0,710]].map(([name,start,left],i)=>{
    const visible=prog(t,Number(start),Number(start)+.2);
    return <div key={String(name)} style={{position:'absolute',left:Number(left),top:650,width:300,textAlign:'center',opacity:visible,transform:`translateY(${(1-ease(visible))*100}px)`}}><div style={{height:5,background:['#a9f4ed',gold,'#be9eff'][i],boxShadow:'0 0 40px #fff'}}/><div style={{fontFamily:'BebasNeue',fontSize:67,background:'#111821dd',padding:12}}>{name}</div></div>;
   })}
   <Prop name="bonsai" x={830} y={1510} w={160}/>
   <div style={{position:'absolute',left:90,right:90,top:1460,height:270,background:'linear-gradient(110deg,#36281f,#1b1512 50%,#4a3422)',borderTop:'16px solid #8e6440',borderBottom:'10px solid #15100d',boxShadow:'0 -10px 25px #0005'}}><div style={{display:'flex',gap:35,padding:24}}>{Array.from({length:14},(_,i)=><div key={i} style={{width:18,height:18,borderRadius:12,background:i%3?'#a48b64':'#8af2cf',boxShadow:'0 3px 4px #000'}}/>)}</div><div style={{fontFamily:'BebasNeue',fontSize:60,textAlign:'center',letterSpacing:12,color:'#cab79b'}}>MESÓN MASÓN</div></div>
   {t>42.17&&<div style={{position:'absolute',left:0,right:0,top:330,textAlign:'center',fontFamily:'Anton',fontSize:180,color:gold,transform:`scale(${.85+.15*ease(prog(t,42.17,42.4))})`,textShadow:'0 9px 0 #131924'}}>YO SUENO</div>}
   <div style={{position:'absolute',bottom:110,left:0,right:0,textAlign:'center',fontFamily:'BebasNeue',fontSize:60,letterSpacing:8,opacity:prog(t,40.7,41.5)}}>CHEKI · LOS DIOZES</div>
 </>}
 </>;
};

export const RealityV4:React.FC=()=>{
 const [fontHandle]=useState(()=>delayRender('V4 fonts'));
 useEffect(()=>{Promise.all(['BebasNeue','Anton','IBMPlexMono'].map(n=>document.fonts.load(`100px ${n}`))).then(()=>continueRender(fontHandle)).catch(cancelRender);},[fontHandle]);
 const frame=useCurrentFrame(),t=frame/30,energy=features.energy[frame]??0;
 let scene=0;starts.forEach((s,i)=>{if(t>=s)scene=i;});
 const bg=backdrops[scene],age=t-starts[scene];
 const punch=[2.52,9.319,12.726,20.192,25.39,27.7,31.068,35.15,42.17].reduce((v,s)=>v+Math.exp(-Math.max(0,t-s)*16)*(t>=s?1:0),0);
 const stable=scene===5||scene===10;
 return <AbsoluteFill style={{background:'#10151e',color:ink,overflow:'hidden'}}>
 <style>{`@font-face{font-family:BebasNeue;src:url('${staticFile('fonts/BebasNeue.ttf')}')}@font-face{font-family:Anton;src:url('${staticFile('fonts/Anton.ttf')}')}@font-face{font-family:IBMPlexMono;src:url('${staticFile('fonts/IBMPlexMono.ttf')}')}`}</style>
 <Audio src={staticFile('cheki-fragment.mp3')}/>
 <AbsoluteFill style={{transform:`scale(${1+punch*.018}) translate(${stable?0:Math.sin(t*2.3)*3}px,${stable?0:Math.sin(t*1.8)*3}px)`}}>
   <Background name={bg} t={t} scene={scene}/>
   <AbsoluteFill style={{background:'linear-gradient(180deg,#09101d99 0%,transparent 45%,transparent 80%,#08101d88 100%)'}}/>
   <Action t={t} scene={scene} energy={energy}/>
 </AbsoluteFill>
 {scene!==1&&<div style={{position:'absolute',left:0,top:110,width:1080,height:480,background:'radial-gradient(ellipse,#0d1421a0,transparent 72%)'}}/>}
 <Lyric t={t} scene={scene}/>
 <div style={{position:'absolute',left:65,top:78,...mono,fontSize:20,letterSpacing:3,display:'flex',alignItems:'center',gap:12}}><span style={{width:11,height:11,borderRadius:10,background:'#ef5867',opacity:.7+.3*Math.sin(t*3)}}/>EN DIRECTO</div>
 <div style={{position:'absolute',right:65,top:78,...mono,fontSize:18,letterSpacing:2,color:'#fff9'}}>LOS DIOZES / CHEKI</div>
 {age<.1&&scene>0&&<AbsoluteFill style={{background:'#f4eddc',opacity:.08*(1-age/.1),mixBlendMode:'screen'}}/>}
 <AbsoluteFill style={{pointerEvents:'none',boxShadow:'inset 0 0 130px 30px #0006'}}/>
 </AbsoluteFill>;
};
