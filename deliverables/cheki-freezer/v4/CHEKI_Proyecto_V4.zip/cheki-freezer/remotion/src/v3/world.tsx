import React, { useLayoutEffect, useRef, useState } from "react";
import * as T from "three";
import {
  AbsoluteFill,
  Audio,
  cancelRender,
  continueRender,
  delayRender,
  staticFile,
  useCurrentFrame,
} from "remotion";
import lyrics from "../lyrics.json";
import features from "../audio-features.json";
import { pose } from "./path";
const W = 1080,
  H = 1920;
const clamp = (v: number) => T.MathUtils.clamp(v, 0, 1);
const smooth = (v: number) => {
  const t = clamp(v);
  return t * t * (3 - 2 * t);
};
type Runtime = { draw: (f: number) => void; dispose: () => void };
function canvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}
function canvasMap(c: HTMLCanvasElement) {
  const t = new T.CanvasTexture(c);
  t.colorSpace = T.SRGBColorSpace;
  t.minFilter = T.LinearFilter;
  t.generateMipmaps = false;
  return t;
}
function radial() {
  const c = canvas(128, 128),
    x = c.getContext("2d")!;
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, "rgba(210,238,255,1)");
  g.addColorStop(0.18, "rgba(125,180,255,.4)");
  g.addColorStop(1, "rgba(70,100,255,0)");
  x.fillStyle = g;
  x.fillRect(0, 0, 128, 128);
  return canvasMap(c);
}
function label(lines: string[], color = "#d9f4ff", bg = false) {
  const c = canvas(1024, 512),
    x = c.getContext("2d")!;
  if (bg) {
    x.fillStyle = "#07162b";
    x.fillRect(0, 0, 1024, 512);
    x.strokeStyle = "#84bdeb";
    x.lineWidth = 8;
    x.strokeRect(10, 10, 1004, 492);
  }
  x.textAlign = "center";
  x.textBaseline = "middle";
  x.font = `${lines.length === 1 ? 132 : 108}px MarkerV3`;
  x.shadowColor = color;
  x.shadowBlur = 9;
  x.fillStyle = color;
  lines.forEach((s, i) =>
    x.fillText(s, 512, 256 + (i - (lines.length - 1) / 2) * 130, 950),
  );
  return canvasMap(c);
}
async function build(c: HTMLCanvasElement): Promise<Runtime> {
  const font = await new FontFace(
    "MarkerV3",
    `url(${staticFile("fonts/Marker.ttf")})`,
  ).load();
  (document.fonts as FontFaceSet & { add: (f: FontFace) => void }).add(font);
  const loader = new T.TextureLoader();
  const urls = [
    "v3/frost-steel.png",
    "performer.png",
    "v3/performer-reach.png",
    "can.png",
    "hero-ice.png",
    "illojuan-sticker.png",
    "xokas-sticker.png",
  ];
  const maps = await Promise.all(
    urls.map((s) => loader.loadAsync(staticFile("assets/" + s))),
  );
  maps.forEach((m) => {
    m.colorSpace = T.SRGBColorSpace;
    m.anisotropy = 2;
  });
  const [frost, artistA, artistB, can, ice, illo, xokas] = maps;
  const renderer = new T.WebGLRenderer({
    canvas: c,
    antialias: false,
    alpha: false,
    preserveDrawingBuffer: true,
    powerPreference: "high-performance",
  });
  renderer.setSize(W, H, false);
  renderer.setPixelRatio(1);
  renderer.outputColorSpace = T.SRGBColorSpace;
  renderer.toneMapping = T.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.35;
  const scene = new T.Scene();
  scene.background = new T.Color("#020714");
  scene.fog = new T.FogExp2("#030a1d", 0.025);
  const camera = new T.PerspectiveCamera(64, W / H, 0.08, 80);
  scene.add(new T.HemisphereLight("#d0e6ff", "#10172c", 3.8));
  scene.add(new T.AmbientLight("#534f99", 0.55));
  const steel = new T.MeshStandardMaterial({
    color: "#58728b",
    map: frost,
    roughness: 0.68,
    metalness: 0.35,
  });
  const dark = new T.MeshStandardMaterial({
    color: "#13213d",
    roughness: 0.45,
    metalness: 0.7,
  });
  const purple = new T.MeshBasicMaterial({
    color: "#a85aff",
    toneMapped: false,
  });
  const cyan = new T.MeshBasicMaterial({ color: "#75cfff", toneMapped: false });
  const haloMap = radial();
  const boxGeo = new T.BoxGeometry(1, 1, 1);
  const objects: T.Object3D[] = [];
  function box(
    x: number,
    y: number,
    z: number,
    sx: number,
    sy: number,
    sz: number,
    mat: T.Material = dark,
  ) {
    const m = new T.Mesh(boxGeo, mat);
    m.position.set(x, y, z);
    m.scale.set(sx, sy, sz);
    scene.add(m);
    return m;
  }
  function glow(
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    color: string,
    opacity = 0.17,
  ) {
    const m = new T.Sprite(
      new T.SpriteMaterial({
        map: haloMap,
        color,
        transparent: true,
        opacity,
        depthWrite: false,
        blending: T.AdditiveBlending,
      }),
    );
    m.position.set(x, y, z);
    m.scale.set(w, h, 1);
    scene.add(m);
    return m;
  }
  function plane(
    map: T.Texture,
    x: number,
    y: number,
    z: number,
    w: number,
    h: number,
    rot = 0,
    opacity = 1,
  ) {
    const m = new T.Mesh(
      new T.PlaneGeometry(w, h),
      new T.MeshBasicMaterial({
        map,
        transparent: true,
        opacity,
        side: T.DoubleSide,
        depthWrite: false,
        toneMapped: false,
      }),
    );
    m.position.set(x, y, z);
    m.rotation.y = rot;
    scene.add(m);
    return m;
  }
  function sign(
    lines: string[],
    x: number,
    y: number,
    z: number,
    w = 5,
    h = 2.5,
    color = "#c6edff",
    bg = false,
  ) {
    return plane(label(lines, color, bg), x, y, z, w, h);
  }
  // Real geometry corridor: wall panels, freezer cases, shelves, light tubes and ceiling.
  const wallMap = frost.clone();
  wallMap.wrapS = wallMap.wrapT = T.RepeatWrapping;
  wallMap.repeat.set(40, 3);
  wallMap.needsUpdate = true;
  const floorMap = frost.clone();
  floorMap.wrapS = floorMap.wrapT = T.RepeatWrapping;
  floorMap.repeat.set(3, 30);
  floorMap.needsUpdate = true;
  const wallMat = new T.MeshBasicMaterial({
    map: wallMap,
    color: "#c2d9ff",
    toneMapped: false,
  });
  const floorMat = new T.MeshBasicMaterial({
    map: floorMap,
    color: "#b5d0fa",
    toneMapped: false,
  });
  box(0, -0.14, -56, 14, 0.25, 150, floorMat);
  box(0, 8.5, -56, 14, 0.3, 150, floorMat);
  box(-7, 4.2, -56, 0.25, 8.5, 150, wallMat);
  box(7, 4.2, -56, 0.25, 8.5, 150, wallMat);
  const shelfData: { p: T.Vector3; s: T.Vector3 }[] = [];
  for (let j = 0; j < 32; j++) {
    const z = 7 - j * 4;
    for (const side of [-1, 1]) {
      shelfData.push({
        p: new T.Vector3(side * 5.6, 0.15, z),
        s: new T.Vector3(2.5, 0.2, 3.7),
      });
      for (const y of [1.8, 3.8, 5.8])
        shelfData.push({
          p: new T.Vector3(side * 5.65, y, z),
          s: new T.Vector3(2.55, 0.12, 3.8),
        });
      box(side * 4.32, 4.1, z + 1.96, 0.07, 7.7, 0.065, j % 2 ? cyan : purple);
      glow(
        side * 4.32,
        4,
        z + 1.9,
        1.5,
        8,
        side < 0 ? "#448aff" : "#9a48ff",
        0.13,
      );
      box(side * 5.6, 7.85, z, 2.5, 0.055, 0.12, side < 0 ? cyan : purple);
    }
    if (j % 3 === 0) {
      box(0, 8.05, z, 8.6, 0.045, 0.09, j % 2 ? purple : cyan);
      glow(0, 7.5, z, 9, 2, "#5067ff", 0.12);
    }
  }
  const shelves = new T.InstancedMesh(boxGeo, steel, shelfData.length);
  const tmp = new T.Object3D();
  shelfData.forEach((v, i) => {
    tmp.position.copy(v.p);
    tmp.scale.copy(v.s);
    tmp.rotation.set(0, 0, 0);
    tmp.updateMatrix();
    shelves.setMatrixAt(i, tmp.matrix);
  });
  scene.add(shelves);
  // Hundreds of photo-textured cans are instanced on independently parallaxing shelves.
  const canMat = new T.MeshBasicMaterial({
    map: can,
    alphaTest: 0.12,
    side: T.DoubleSide,
    toneMapped: false,
  });
  const canGeo = new T.PlaneGeometry(0.67, 1.15);
  const cans = new T.InstancedMesh(canGeo, canMat, 32 * 2 * 3 * 4);
  let ci = 0;
  for (let j = 0; j < 32; j++)
    for (const side of [-1, 1])
      for (const y of [2.42, 4.42, 6.42])
        for (let k = 0; k < 4; k++) {
          tmp.position.set(
            side * (5.35 + (k % 2) * 0.6),
            y,
            7 - j * 4 - 1.35 + Math.floor(k / 2) * 1.65,
          );
          tmp.scale.setScalar(1);
          tmp.rotation.set(0, side * 0.6, 0);
          tmp.updateMatrix();
          cans.setMatrixAt(ci++, tmp.matrix);
        }
  scene.add(cans);
  const lightA = new T.PointLight("#72b9ff", 42, 24, 2);
  const lightB = new T.PointLight("#aa69ff", 35, 22, 2);
  scene.add(lightA, lightB);

  // Characters are independent 2.5D photographic elements in the spatial set.
  const actor1 = plane(artistA, 0.2, 3.3, -15, 5.1, 7.65);
  const actor2 = plane(artistB, 0.3, 3.4, -70, 5.1, 7.65);
  const reflectionMat = artistA.clone();
  const refl = plane(reflectionMat, 0.2, -2.7, -15, 5.1, 7.65, 0, 0.13);
  refl.scale.y = -1;
  sign(["LOS DIOZES"], 0, 7, -17, 7, 3.5, "#ae77ff");
  sign(["MESÓN MASÓN"], 0, 7.2, -73, 8, 4, "#a870ff");
  // Photo ice combined with actual 3D crystalline boxes.
  const hero1 = plane(ice, -0.7, 3.7, -26, 6, 5.55, 0.12);
  const hero2 = plane(ice, 1.1, 3.1, -56, 7, 6.4, -0.15);
  const glassMat = new T.MeshStandardMaterial({
    map: frost,
    color: "#92cfff",
    transparent: true,
    opacity: 0.21,
    roughness: 0.18,
    metalness: 0.3,
    depthWrite: false,
  });
  const iceGeo = new T.BoxGeometry(1, 1, 1);
  const crystalMat = new T.MeshStandardMaterial({
    color: "#a4d5ff",
    transparent: true,
    opacity: 0.57,
    roughness: 0.16,
    metalness: 0.18,
    depthWrite: false,
    emissive: "#27496f",
    emissiveIntensity: 0.28,
  });
  const chunks = new T.InstancedMesh(iceGeo, crystalMat, 55);
  const iceWire = new T.InstancedMesh(
    iceGeo,
    new T.MeshBasicMaterial({
      color: "#c6edff",
      transparent: true,
      opacity: 0.24,
      wireframe: true,
      depthWrite: false,
    }),
    55,
  );
  scene.add(chunks, iceWire);
  const floatingCans = [
    plane(can, 2, 3.1, -32, 2.6, 4.1, -0.2),
    plane(can, -1, 2.8, -81, 3, 4.6, 0.3),
    plane(can, 2, 5.4, -104, 1.6, 2.6),
  ];
  // Continuous ice gates and hotel motifs instead of a sequence of flat backgrounds.
  for (const z of [-20, -47, -60, -76, -101]) {
    box(-3.65, 3.7, z, 0.28, 7.4, 0.35, steel);
    box(3.65, 3.7, z, 0.28, 7.4, 0.35, steel);
    box(0, 7.35, z, 7.5, 0.22, 0.35, steel);
    box(-3.45, 3.7, z + 0.08, 0.04, 7, 0.04, cyan);
    box(3.45, 3.7, z + 0.08, 0.04, 7, 0.04, purple);
  }
  sign(["HOTEL", "MALIGNO"], -3.5, 6.1, -35, 3.6, 1.8, "#ae70ff", true);
  sign(["MARBELLA VICE"], 3.6, 1.7, -50, 3.2, 1.6, "#7ed9ff", true);
  // Stream-reaction monitor, physically inside the route.
  box(-1.3, 4.7, -42.25, 4.8, 3.5, 0.32, steel);
  box(-1.3, 4.7, -42.03, 4.4, 3.1, 0.08, dark);
  const periFace = plane(illo, -1.3, 5.15, -41.92, 3.05, 2.7);
  const periText = sign(
    ["¿UN PERI QUÉ?"],
    -1.3,
    3.45,
    -41.88,
    4.2,
    2.1,
    "#d6c4ff",
  );
  const idle = sign(["MESÓN MASÓN"], -1.3, 4.7, -41.9, 4.1, 2.05, "#767fa7");
  // Abstract ice wall with genuinely separate moving fragments and a portal gap.
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    const m = box(
      Math.cos(a) * 3.1,
      3.7 + Math.sin(a) * 3.1,
      -58,
      1.7,
      2.7,
      0.6,
      glassMat,
    );
    m.rotation.z = -a;
    objects.push(m);
  }
  // Crown geometry in the aisle, an emblem not a title card.
  const crownPts = [
    [-3, 3.3, -83],
    [-3.3, 6.1, -83],
    [-1.4, 4.7, -83],
    [0, 7.3, -83],
    [1.4, 4.7, -83],
    [3.3, 6.1, -83],
    [3, 3.3, -83],
    [-3, 3.3, -83],
  ].map((v) => new T.Vector3(...(v as [number, number, number])));
  const crown = new T.Line(
    new T.BufferGeometry().setFromPoints(crownPts),
    new T.LineBasicMaterial({ color: "#b9dcff", toneMapped: false }),
  );
  scene.add(crown);
  glow(0, 4.8, -83, 8, 7, "#7250fa", 0.18);
  // Coding meme on a curved route-side streaming console, with a live progress bar.
  const codeFrame = box(1.15, 4.9, -99, 4.1, 2.8, 0.45, steel);
  const codeBack = box(1.15, 4.9, -98.72, 3.95, 2.65, 0.08, dark);
  const codeCanvas = canvas(1024, 640);
  const codeCtx = codeCanvas.getContext("2d")!;
  const codeMap = canvasMap(codeCanvas);
  const codeScreen = plane(codeMap, 1.15, 4.9, -98.64, 3.8, 2.4);
  const codeFace = plane(xokas, 2.2, 4.15, -98.49, 1.3, 1.45);
  const monitorPivot = new T.Group();
  monitorPivot.position.set(3.3, 4.9, -99);
  scene.add(monitorPivot);
  [codeFrame, codeBack, codeScreen, codeFace].forEach((o) =>
    monitorPivot.attach(o),
  );
  // Credits belong to the set: tilted frozen name plates above the exit.
  const credits = [
    ["SPOK", -1.1, 5.8, -107],
    ["JUANITO", 0, 6.6, -110],
    ["SCENO", 1.1, 5.8, -113],
  ] as const;
  const creditMeshes:T.Mesh[]=[];
  credits.forEach(([name, x, y, z], i) => {
    const p = sign(
      [name],
      x,
      y,
      z,
      3.6,
      1.8,
      i % 2 ? "#ceefff" : "#ae80ff",
      true,
    );
    p.rotation.z = (i - 1) * 0.1; p.userData.baseY=y;creditMeshes.push(p);
  });
  sign(["LOS DIOZES"], 0, 7.6, -117, 8, 4, "#b58bff");
  // Both doors are actual hinged geometry; the camera never cuts to a title frame.
  const startHinge = new T.Group();
  startHinge.position.set(-3.7, 0, 4);
  scene.add(startHinge);
  const doorMat = new T.MeshStandardMaterial({
    map: frost,
    color: "#627993",
    roughness: 0.5,
    metalness: 0.6,
  });
  function addDoor(parent: T.Group) {
    const d = new T.Mesh(new T.BoxGeometry(7.4, 8.2, 0.3), doorMat);
    d.position.set(3.7, 4.1, 0);
    parent.add(d);
    const logo = new T.Mesh(
      new T.PlaneGeometry(5, 2.5),
      new T.MeshBasicMaterial({
        map: label(["CHEKI", "LOS DIOZES"], "#d7edff"),
        transparent: true,
        depthWrite: false,
        toneMapped: false,
      }),
    );
    logo.position.set(3.7, 4.7, 0.18);
    parent.add(logo);
    const led = new T.Mesh(
      new T.PlaneGeometry(1.5, 0.75),
      new T.MeshBasicMaterial({
        map: label(["−18°C"], "#83cdff", true),
        toneMapped: false,
      }),
    );
    led.position.set(5.8, 7, 0.18);
    parent.add(led);
  }
  addDoor(startHinge);
  const exitHinge = new T.Group();
  exitHinge.position.set(-3.7, 0, -118);
  scene.add(exitHinge);
  addDoor(exitHinge);
  // Snow in physical space and drifting volumetric-looking fog sprites.
  const snowPos = new Float32Array(430 * 3);
  for (let i = 0; i < 430; i++) {
    snowPos[i * 3] = ((i * 733) % 1400) / 100 - 7;
    snowPos[i * 3 + 1] = ((i * 367) % 850) / 100;
    snowPos[i * 3 + 2] = 10 - ((i * 1013) % 14000) / 100;
  }
  const snowGeo = new T.BufferGeometry();
  snowGeo.setAttribute("position", new T.BufferAttribute(snowPos, 3));
  const snow = new T.Points(
    snowGeo,
    new T.PointsMaterial({
      color: "#c2e6ff",
      size: 0.035,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
    }),
  );
  scene.add(snow);
  const fogs: T.Sprite[] = [];
  for (let i = 0; i < 22; i++) {
    const m = glow(
      ((i % 3) - 1) * 3,
      1 + (i % 4) * 1.7,
      8 - i * 6,
      12,
      3,
      "#a3b8dc",
      0.075,
    );
    fogs.push(m);
  }
  // Word objects track the camera; exit fragments fade before the next cue begins.
  const cueGroups = lyrics.cues.map((cue) => {
    const group = new T.Group();
    scene.add(group);
    const words: {
      m: T.Mesh;
      b: T.Mesh;
      x: number;
      y: number;
      word: (typeof cue.words)[number];
    }[] = [];
    const ctx = canvas(1, 1).getContext("2d")!;
    ctx.font = "100px MarkerV3";
    const widths = cue.words.map(
      (v) => (ctx.measureText(v.word.toUpperCase()).width / 100) * 0.35 + 0.1,
    );
    const total = widths.reduce((a, b) => a + b, 0);
    let rows: number[][] = [];
    if (total <= 3.55) {
      rows = [widths.map((_, i) => i)];
    } else {
      let split = 1,
        best = Infinity;
      for (let k = 1; k < widths.length; k++) {
        const left = widths.slice(0, k).reduce((a, b) => a + b, 0),
          right = total - left,
          score = Math.max(left, right);
        if (score < best) {
          split = k;
          best = score;
        }
      }
      rows = [
        widths.map((_, i) => i).slice(0, split),
        widths.map((_, i) => i).slice(split),
      ];
    }
    const largest = Math.max(
      ...rows.map((r) => r.reduce((a, i) => a + widths[i], 0)),
    );
    const textScale = Math.min(1, 3.55 / largest);
    widths.forEach((_, i) => (widths[i] *= textScale));
    rows.forEach((indices, ri) => {
      const sum = indices.reduce((v, i) => v + widths[i], 0);
      let cursor = -sum / 2;
      indices.forEach((i) => {
        const word = cue.words[i],
          w = widths[i],
          c = canvas(Math.max(128, Math.ceil(w * 330)), 190),
          x = c.getContext("2d")!;
        x.font = "125px MarkerV3";
        x.textAlign = "center";
        x.textBaseline = "middle";
        x.lineJoin = "round";
        x.strokeStyle = "#10213e";
        x.lineWidth = 9;
        x.strokeText(word.word.toUpperCase(), c.width / 2, 86, c.width - 12);
        x.fillStyle = "#f1faff";
        x.fillText(word.word.toUpperCase(), c.width / 2, 86, c.width - 12);
        const mat = new T.MeshBasicMaterial({
          map: canvasMap(c),
          transparent: true,
          depthTest: false,
          depthWrite: false,
          toneMapped: false,
        });
        const geo = new T.PlaneGeometry(
          Math.max(0.18, w - 0.14 * textScale),
          0.56 * textScale,
        );
        const m = new T.Mesh(geo, mat);
        const b = new T.Mesh(geo, mat.clone());
        m.renderOrder = 101;
        b.renderOrder = 100;
        group.add(b, m);
        const bx = cursor + w / 2,
          by = (rows.length - 1 - ri) * 0.54 * textScale;
        words.push({ m, b, x: bx, y: by, word });
        cursor += w;
      });
    });
    return { cue, group, words };
  });
  const camHelper = new T.PerspectiveCamera(64, W / H, 0.08, 80);
  const forward = new T.Vector3(),
    right = new T.Vector3(),
    up = new T.Vector3();
  function draw(frame: number) {
    const t = frame / 30,
      pulse = features.pulse[frame] ?? 0;
    const at = pose(t);
    camera.position.copy(at.p);
    camera.position.x += Math.sin(frame * 1.7) * pulse * 0.025;
    camera.position.y += Math.cos(frame * 1.3) * pulse * 0.017;
    camera.lookAt(at.q);
    camera.rotateZ(at.roll);
    camera.fov = 64 + pulse * 0.7;
    camera.updateProjectionMatrix();
    lightA.position.set(camera.position.x - 3, 6, camera.position.z - 6);
    lightB.position.set(camera.position.x + 3, 5, camera.position.z - 8);
    actor1.rotation.z = Math.sin(t * 2) * 0.012;
    actor2.rotation.z = Math.sin(t * 1.7) * 0.015;
    actor2.position.y = 3.4 + Math.sin(t * 2.1) * 0.04;
    hero1.rotation.z = Math.sin(t) * 0.1;
    hero1.position.y = 3.7 + Math.sin(t * 1.4) * 0.2;
    hero2.rotation.z = -t * 0.12;
    floatingCans.forEach((m, i) => {
      m.rotation.z = Math.sin(t * 1.4 + i) * 0.16;
      m.position.y = [3.1, 2.8, 5.4][i] + Math.sin(t * 1.7 + i) * 0.22;
    });
    for (let i = 0; i < 55; i++) {
      const z = 5 - i * 2.2,
        a = i * 2.4 + t * (i % 2 ? 0.14 : -0.11),
        r = 2.7 + (i % 4) * 0.55;
      tmp.position.set(Math.cos(a) * r, 3.5 + Math.sin(a) * 2.5, z);
      tmp.rotation.set(t * 0.13 + i, t * 0.22 + i * 0.7, i + t * 0.05);
      tmp.scale.setScalar(0.35 + (i % 5) * 0.16);
      tmp.updateMatrix();
      chunks.setMatrixAt(i, tmp.matrix);
      iceWire.setMatrixAt(i, tmp.matrix);
    }
    chunks.instanceMatrix.needsUpdate = true;
    iceWire.instanceMatrix.needsUpdate = true;
    objects.forEach((m, i) => {
      m.rotation.z = (-i * Math.PI) / 4 + Math.sin(t * 0.7 + i) * 0.1;
      m.position.z = -58 + Math.sin(t + i) * 0.2;
    });
    startHinge.rotation.y = -smooth((t - 0.35) / 1.6) * 1.85;
    exitHinge.rotation.y = -(1 - smooth((t - 40.2) / 2)) * 1.85;
    const peri = t >= 14.7 && t <= 16.5;
    periFace.visible = peri;
    periText.visible = peri;
    idle.visible = !peri;
    const encoding = t >= 33.9 && t <= 37.25;
    codeFace.visible = encoding;
    creditMeshes.forEach(m=>{const distance=camera.position.z-m.position.z;m.position.y=m.userData.baseY+Math.max(0,5-distance)*.8;});
    monitorPivot.rotation.y = -smooth((t - 37.05) / 0.9) * 1.55;
    codeCtx.fillStyle = "#080e26";
    codeCtx.fillRect(0, 0, 1024, 640);
    codeCtx.strokeStyle = "#8dc7ff";
    codeCtx.lineWidth = 5;
    codeCtx.strokeRect(10, 10, 1004, 620);
    codeCtx.fillStyle = "#81b8d9";
    codeCtx.font = "25px monospace";
    codeCtx.fillText("FREEZER.EXE  /  −18°C", 45, 67);
    codeCtx.font = "70px MarkerV3";
    codeCtx.fillStyle = "#e2f4ff";
    codeCtx.fillText(
      encoding ? "ESTOY CODIFICANDO" : "MESÓN MASÓN",
      45,
      205,
      935,
    );
    codeCtx.fillStyle = "#bc83ff";
    codeCtx.fillText(
      encoding ? "A MÁXIMA CALIDAD" : "LOS DIOZES",
      45,
      300,
      935,
    );
    codeCtx.fillStyle = "#263d69";
    codeCtx.fillRect(45, 390, 650, 29);
    codeCtx.fillStyle = "#9c76ff";
    codeCtx.fillRect(45, 390, 650 * clamp((t - 33.9) / 1.4), 29);
    codeCtx.font = "27px monospace";
    codeCtx.fillStyle = "#b0c6e3";
    codeCtx.fillText("1080 × 1920 · 30 FPS", 45, 480);
    codeMap.needsUpdate = true;
    fogs.forEach((m, i) => {
      m.position.x = ((i % 3) - 1) * 3 + Math.sin(t * 0.7 + i) * 1.5;
      m.position.y = 1 + (i % 4) * 1.7 + Math.sin(t * 0.5 + i) * 0.25;
    });
    snow.rotation.z = Math.sin(t * 0.2) * 0.005;
    forward.set(0, 0, -1).applyQuaternion(camera.quaternion);
    right.set(1, 0, 0).applyQuaternion(camera.quaternion);
    up.set(0, 1, 0).applyQuaternion(camera.quaternion);
    cueGroups.forEach(({ cue, group, words }) => {
      const age = t - cue.start,
        after = t - cue.end;
      group.visible = age >= 0 && after < 0;
      if (!group.visible) return;
      const liveTime = Math.min(t, cue.end);
      const cp = pose(liveTime);
      camHelper.position.copy(cp.p);
      camHelper.lookAt(cp.q);
      camHelper.rotateZ(cp.roll);
      const fw = new T.Vector3(0, 0, -1).applyQuaternion(camHelper.quaternion),
        uu = new T.Vector3(0, 1, 0).applyQuaternion(camHelper.quaternion);
      const lower = (t > 14.5 && t < 16.6) || (t > 33.8 && t < 37.3);
      group.position
        .copy(cp.p)
        .addScaledVector(fw, 5.6)
        .addScaledVector(uu, lower ? -2.65 : -0.78);
      group.quaternion.copy(camHelper.quaternion);
      group.rotateY(Math.sin(t * 0.8 + cue.line) * 0.075);
      group.rotateZ((cue.line % 2 ? 1 : -1) * 0.025);
      const alpha = smooth(age / 0.08) * smooth((cue.end - t) / 0.08);
      words.forEach(({ m, b, x, y, word }, i) => {
        const active = t >= word.start && t < word.end,
          hit = active ? Math.exp(-(t - word.start) * 18) : 0;
        const shatter = Math.max(0, 0.1 - (cue.end - t)) * 2;
        m.position.set(
          x + (i % 2 ? 1 : -1) * shatter * 0.5,
          y + shatter * (i - 2) * 0.3 + (active ? 0.04 : 0),
          active ? 0.08 + hit * 0.09 : 0,
        );
        m.rotation.z = shatter * (i - 2) * 0.2;
        m.scale.setScalar(active ? 1.035 + hit * 0.055 : 1);
        (m.material as T.MeshBasicMaterial).color.set(
          active ? "#bd8cff" : t >= word.end ? "#eefaff" : "#cadbea",
        );
        (m.material as T.MeshBasicMaterial).opacity = alpha;
        b.position.copy(m.position).add(new T.Vector3(0.024, -0.035, -0.03));
        b.rotation.copy(m.rotation);
        b.scale.copy(m.scale);
        (b.material as T.MeshBasicMaterial).color.set("#3165b7");
        (b.material as T.MeshBasicMaterial).opacity = alpha * 0.8;
      });
    });
    scene.traverse((o) => {
      if (o instanceof T.Sprite)
        o.visible = Math.abs(o.position.z - camera.position.z) < 30;
    });
    renderer.render(scene, camera);
  }
  const dispose = () => {
    scene.traverse((o) => {
      if (o instanceof T.Mesh || o instanceof T.Points || o instanceof T.Line) {
        o.geometry.dispose();
        const ms = Array.isArray(o.material) ? o.material : [o.material];
        ms.forEach((m) => m.dispose());
      }
    });
    maps.forEach((m) => m.dispose());
    renderer.dispose();
  };
  return { draw, dispose };
}
export const OneTakeV3: React.FC = () => {
  const f = useCurrentFrame(),
    ref = useRef<HTMLCanvasElement>(null),
    runtime = useRef<Runtime | null>(null),
    last = useRef(f);
  last.current = f;
  const [handle] = useState(() =>
    delayRender("Loading continuous 3D freezer world"),
  );
  useLayoutEffect(() => {
    let stopped = false;
    build(ref.current!)
      .then((r) => {
        if (stopped) {
          r.dispose();
          return;
        }
        runtime.current = r;
        r.draw(last.current);
        continueRender(handle);
      })
      .catch((e) => cancelRender(e));
    return () => {
      stopped = true;
      runtime.current?.dispose();
      runtime.current = null;
    };
  }, [handle]);
  useLayoutEffect(() => {
    runtime.current?.draw(f);
  }, [f]);
  return (
    <AbsoluteFill style={{ background: "#030816", overflow: "hidden" }}>
      <Audio src={staticFile("cheki-fragment.mp3")} />
      <canvas
        ref={ref}
        width={W}
        height={H}
        style={{ width: "100%", height: "100%" }}
      />
      <AbsoluteFill
        style={{
          pointerEvents: "none",
          background: "radial-gradient(ellipse,transparent 45%,#0008 100%)",
        }}
      />
      <AbsoluteFill
        style={{
          background: "#020511",
          opacity: f < 5 ? 1 - f / 5 : f > 1281 ? (f - 1281) / 6 : 0,
        }}
      />
    </AbsoluteFill>
  );
};
