import * as T from "three";
export const route = [
  { t: 0, p: [0, 3.3, 12], q: [0, 3.3, 0], r: 0 },
  { t: 2.8, p: [0, 3.1, 3], q: [0, 3.6, -8], r: -0.025 },
  { t: 6.2, p: [-2.6, 3.4, -7], q: [0.25, 3.8, -16], r: 0.065 },
  { t: 9.3, p: [2.4, 2.6, -17], q: [-1, 3.4, -26], r: -0.07 },
  { t: 12.4, p: [-2.2, 4.4, -25], q: [1.3, 3.6, -34], r: 0.09 },
  { t: 15.8, p: [1.1, 3.4, -34], q: [-1.2, 4.4, -41], r: -0.035 },
  { t: 18.6, p: [-1.9, 1.3, -43], q: [0, 2.8, -52], r: -0.12 },
  { t: 21.4, p: [2.3, 3.7, -52], q: [0, 3.5, -61], r: 0.1 },
  { t: 24.4, p: [-2.4, 4.5, -61], q: [0.3, 3.8, -70], r: -0.06 },
  { t: 27.8, p: [1.7, 2.9, -71], q: [-1, 3.6, -80], r: 0.05 },
  { t: 31, p: [0, 3.8, -80], q: [1, 4, -88], r: -0.04 },
  { t: 34.4, p: [-2.2, 3.7, -88], q: [1.1, 4.8, -97], r: 0.035 },
  { t: 36.4, p: [0.7, 3.3, -93], q: [1.1, 4.8, -98], r: -0.02 },
  { t: 38.4, p: [0, 4, -100], q: [0, 4.3, -109], r: 0.04 },
  { t: 41.3, p: [0, 3.6, -109], q: [0, 3.8, -118], r: 0 },
  { t: 42.9, p: [0, 3.6, -113], q: [0, 3.8, -118], r: 0 },
];
function sample(time: number, key: "p" | "q") {
  let i = route.findIndex(
    (v, n) => n < route.length - 1 && time >= v.t && time < route[n + 1].t,
  );
  if (i < 0) i = time < 0 ? 0 : route.length - 2;
  const a = route[i],
    b = route[i + 1],
    prev = route[Math.max(0, i - 1)],
    next = route[Math.min(route.length - 1, i + 2)],
    dt = b.t - a.t,
    u = T.MathUtils.clamp((time - a.t) / dt, 0, 1);
  return new T.Vector3(
    ...([0, 1, 2].map((k) => {
      const m0 = (b[key][k] - prev[key][k]) / (b.t - prev.t);
      const m1 = (next[key][k] - a[key][k]) / (next.t - a.t);
      return (
        (2 * u ** 3 - 3 * u ** 2 + 1) * a[key][k] +
        (u ** 3 - 2 * u ** 2 + u) * dt * m0 +
        (-2 * u ** 3 + 3 * u ** 2) * b[key][k] +
        (u ** 3 - u ** 2) * dt * m1
      );
    }) as [number, number, number]),
  );
}
export function pose(time: number) {
  let i = route.findIndex(
    (v, n) => n < route.length - 1 && time >= v.t && time < route[n + 1].t,
  );
  if (i < 0) i = route.length - 2;
  const u = T.MathUtils.clamp(
    (time - route[i].t) / (route[i + 1].t - route[i].t),
    0,
    1,
  );
  const smooth = u * u * (3 - 2 * u);
  return {
    p: sample(time, "p"),
    q: sample(time, "q"),
    roll: T.MathUtils.lerp(route[i].r, route[i + 1].r, smooth),
  };
}
