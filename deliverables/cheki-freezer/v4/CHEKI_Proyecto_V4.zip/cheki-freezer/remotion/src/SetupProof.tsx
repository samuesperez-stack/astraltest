import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame} from 'remotion';
// Procedural scene prototype. No transcript or word timing has been inferred.
const frost = Array.from({length: 90}, (_, i) => ({x:(i*733)%1080,y:(i*367)%1920,r:2+i%5}));
export const Freezer: React.FC = () => {
 const f=useCurrentFrame();
 const open=interpolate(f,[15,100],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 const push=1+Math.min(f,180)*0.0004;
 return <AbsoluteFill style={{background:'#030818',overflow:'hidden'}}>
  <Audio src={staticFile('cheki-fragment.mp3')}/>
  <AbsoluteFill style={{transform:`scale(${push}) translateX(${Math.sin(f/70)*8}px)`}}>
   <svg width="1080" height="1920" viewBox="0 0 1080 1920">
    <defs>
     <linearGradient id="wall"><stop stopColor="#070e28"/><stop offset=".5" stopColor="#25396c"/><stop offset="1" stopColor="#071128"/></linearGradient>
     <linearGradient id="metal"><stop stopColor="#09122c"/><stop offset=".5" stopColor="#90bfe4"/><stop offset="1" stopColor="#18264d"/></linearGradient>
     <linearGradient id="ice" x2="1" y2="1"><stop stopColor="#c7efff" stopOpacity=".7"/><stop offset=".4" stopColor="#3f86ef" stopOpacity=".12"/><stop offset="1" stopColor="#a54af0" stopOpacity=".65"/></linearGradient>
     <radialGradient id="glow"><stop stopColor="#7356f7" stopOpacity=".5"/><stop offset="1" stopColor="#132a68" stopOpacity="0"/></radialGradient>
    </defs>
    <rect x="38" y="40" width="1004" height="1840" rx="32" fill="url(#metal)"/>
    <path d="M80 100H1000V1810H80Z" fill="url(#wall)"/>
    <path d="M80 100L220 260H860L1000 100M80 1810L220 1620H860L1000 1810" fill="none" stroke="#68b8ff" strokeWidth="4"/>
    <rect x="102" y="140" width="14" height="1590" fill="#8edfff"/>
    <rect x="962" y="140" width="14" height="1590" fill="#b65cff"/>
    {[620,1030,1440].map((y,j)=><g key={y}>
     {Array.from({length:6},(_,i)=><g key={i} transform={`translate(${180+i*125} ${y-245})`}>
      <rect width="86" height="230" rx="23" fill={i%2?'#17274e':'#28205a'} stroke="#6c9bdc" strokeWidth="3"/>
      <ellipse cx="43" cy="10" rx="36" ry="8" fill="url(#metal)"/>
      <path d="M15 75L43 90L70 60M20 140L65 110" stroke="#a54af0" strokeWidth="5" fill="none"/>
      {frost.slice(0,12).map((p,k)=><circle key={k} cx={p.x%80} cy={p.y%220} r="2" fill="#d8edff" opacity=".6"/>)}
     </g>)}
     <path d={`M105 ${y}H975L880 ${y+65}H190Z`} fill="url(#metal)"/>
     {Array.from({length:18},(_,i)=><path key={i} d={`M${120+i*48} ${y}L${200+i*39} ${y+60}`} stroke="#061127" strokeWidth="5"/>)}
     <rect x="120" y={y+65} width="840" height="7" fill={j%2?'#a54af0':'#74cfff'}/>
    </g>)}
    <ellipse cx="540" cy="850" rx="700" ry="1000" fill="url(#glow)"/>
   </svg>
  </AbsoluteFill>
  <AbsoluteFill style={{transform:`translate(${Math.sin(f/55)*18}px, ${-f*.5}px)`}}>
   <svg width="1080" height="1920">{[0,1,2].map((n)=><g key={n} transform={`translate(${190+n*240} ${1200-n*100+Math.sin(f/23+n)*16}) rotate(${f*.08+n*18})`}>
    <path d="M0 0L160 -35L205 110L45 155Z" fill="url(#ice)" stroke="#b6e8ff" strokeWidth="3"/>
    <path d="M0 0L75 45L160 -35M75 45L45 155M75 45L205 110" fill="none" stroke="#b6e8ff" opacity=".6"/>
   </g>)}</svg>
  </AbsoluteFill>
  <AbsoluteFill style={{transformOrigin:'left center',transform:`perspective(1600px) rotateY(${-open*104}deg)`,background:'linear-gradient(115deg,rgba(46,92,154,.96),rgba(8,18,46,.98) 55%,rgba(77,31,136,.95))',border:'28px solid #23395b',boxShadow:'inset 0 0 120px #050b1b'}}>
   <div style={{position:'absolute',top:170,right:100,color:'#a4dfff',font:'64px monospace',border:'5px solid #0a1027',padding:20,boxShadow:'0 0 35px #3f86ef'}}>−18°</div>
   <div style={{position:'absolute',top:700,left:120,color:'#d8edff',font:'italic 900 170px sans-serif',transform:'rotate(-8deg)',textShadow:'0 0 30px #3f86ef'}}>CHEKI</div>
   <div style={{position:'absolute',top:940,left:200,color:'#a54af0',font:'bold 54px sans-serif',transform:'rotate(-8deg)'}}>LOS DIOZES</div>
   <div style={{position:'absolute',top:750,right:40,width:35,height:450,borderRadius:18,background:'linear-gradient(90deg,#060c1b,#7896c1,#060c1b)'}}/>
  </AbsoluteFill>
  <AbsoluteFill style={{pointerEvents:'none'}}>
   <svg width="1080" height="1920">{frost.map((p,i)=><circle key={i} cx={p.x+Math.sin(f/45+i)*12} cy={(p.y-f*(.3+i%3*.12)+3840)%1920} r={p.r} fill="#d8edff" opacity={.08+open*.14}/>)}</svg>
   {[0,1,2].map(i=><div key={i} style={{position:'absolute',left:-200+i*250+Math.sin(f/60+i)*90,top:1400-i*200-f*.8,width:1000,height:320,borderRadius:'50%',background:'radial-gradient(ellipse,rgba(157,189,239,.17),transparent 65%)',filter:'blur(35px)',opacity:open}}/>)}
  </AbsoluteFill>
 </AbsoluteFill>;
};
