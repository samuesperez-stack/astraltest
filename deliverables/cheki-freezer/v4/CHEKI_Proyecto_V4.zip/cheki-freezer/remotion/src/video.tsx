import React from "react";
import {
  AbsoluteFill,
  Audio,
  Img,
  interpolate,
  staticFile,
  useCurrentFrame,
} from "remotion";
import features from "./audio-features.json";
import lyrics from "./lyrics.json";
import "./styles.css";
import { KineticLyrics } from "./v2/kinetic";
import { References } from "./v2/references";
const W = 1080,
  H = 1920;
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const ease = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
const particles = Array.from({ length: 65 }, (_, i) => ({
  x: (i * 733 + 61) % W,
  y: (i * 367 + 71) % H,
  r: 1 + (i % 4),
  s: 0.3 + (i % 7) * 0.09,
}));
const Crown = ({
  size = 100,
  color = "#d8edff",
}: {
  size?: number;
  color?: string;
}) => (
  <svg width={size} height={size * 0.7} viewBox="0 0 100 70">
    <path
      d="M12 55L8 14L33 38L49 4L67 38L91 12L86 55ZM12 65H86"
      fill="none"
      stroke={color}
      strokeWidth="4"
      strokeLinejoin="round"
    />
  </svg>
);
const Cube = ({
  size,
  rx,
  ry,
  rz,
}: {
  size: number;
  rx: number;
  ry: number;
  rz: number;
}) => (
  <div
    style={{
      width: size,
      height: size,
      position: "relative",
      transformStyle: "preserve-3d",
      transform: `rotateX(${rx}deg) rotateY(${ry}deg) rotateZ(${rz}deg)`,
    }}
  >
    {[
      `translateZ(${size / 2}px)`,
      `rotateY(180deg) translateZ(${size / 2}px)`,
      `rotateY(90deg) translateZ(${size / 2}px)`,
      `rotateY(-90deg) translateZ(${size / 2}px)`,
      `rotateX(90deg) translateZ(${size / 2}px)`,
      `rotateX(-90deg) translateZ(${size / 2}px)`,
    ].map((t, i) => (
      <div key={i} className="cube-face" style={{ transform: t }} />
    ))}
  </div>
);
const IceField = ({
  f,
  burst = false,
  light = false,
}: {
  f: number;
  burst?: boolean;
  light?: boolean;
}) => (
  <AbsoluteFill style={{ perspective: 1500 }}>
    {Array.from({ length: burst ? 14 : 7 }, (_, i) => {
      const angle = i * 2.4,
        travel = burst ? clamp(f / 70) * 600 : 0;
      const size = light ? 45 + (i % 4) * 16 : 70 + (i % 4) * 30;
      return (
        <div
          key={i}
          style={{
            position: "absolute",
            left: 540 + Math.cos(angle) * (280 + travel) - size / 2,
            top:
              940 +
              Math.sin(angle) * (650 + travel) +
              Math.sin(f / 27 + i) * 25,
            opacity: light ? 0.45 : 0.75,
            transform: `translateZ(${(i % 3) * 40}px)`,
          }}
        >
          <Cube
            size={size}
            rx={25 + f * (i % 2 ? 0.35 : -0.22)}
            ry={35 + f * 0.4 + i * 19}
            rz={i * 27 + f * 0.1}
          />
        </div>
      );
    })}
  </AbsoluteFill>
);
const Can = ({
  f,
  index = 0,
  scale = 1,
}: {
  f: number;
  index?: number;
  scale?: number;
}) => (
  <div
    style={{
      width: 220,
      height: 490,
      position: "relative",
      transform: `scale(${scale}) rotate(${Math.sin(f / 43 + index) * 7}deg)`,
      filter: "drop-shadow(0 20px 25px #02081799)",
    }}
  >
    <Img
      src={staticFile("assets/can.png")}
      style={{
        position: "absolute",
        left: -60,
        top: -10,
        width: 340,
        height: 510,
        objectFit: "contain",
      }}
    />
  </div>
);
const Cracks = ({ f, opacity = 1 }: { f: number; opacity?: number }) => (
  <AbsoluteFill style={{ opacity }}>
    <svg width={W} height={H}>
      <g stroke="#c2e9ff" fill="none" strokeWidth="2" opacity=".8">
        {Array.from({ length: 10 }, (_, i) => {
          const a = (i * Math.PI) / 5;
          const radius = 300 + clamp(f / 10) * 900;
          const x = 540 + Math.cos(a) * radius,
            y = 940 + Math.sin(a) * radius;
          return (
            <path
              key={i}
              d={`M540 940L${540 + Math.cos(a + 0.2) * 180} ${940 + Math.sin(a + 0.2) * 180}L${x} ${y}M${540 + Math.cos(a + 0.2) * 180} ${940 + Math.sin(a + 0.2) * 180}l${Math.cos(a + 1) * 200} ${Math.sin(a + 1) * 200}`}
              strokeDasharray="1800"
              strokeDashoffset={1800 * (1 - clamp(f / 9))}
            />
          );
        })}
      </g>
    </svg>
  </AbsoluteFill>
);
const Glass = ({ f, heavy = false }: { f: number; heavy?: boolean }) => (
  <AbsoluteFill style={{ pointerEvents: "none", opacity: heavy ? 0.7 : 0.4 }}>
    <svg width={W} height={H}>
      {particles.map((p, i) => (
        <g
          key={i}
          transform={`translate(${p.x} ${(p.y + f * (i % 4 === 0 ? 0.35 : 0.02)) % H})`}
        >
          <ellipse
            rx={p.r * 1.4}
            ry={p.r * 2}
            fill="#c7e6ff11"
            stroke="#d2eeff33"
            strokeWidth="1"
          />
          <path d={`M-1 -${p.r}L1 -${p.r}`} stroke="#edffff88" />
        </g>
      ))}
    </svg>
  </AbsoluteFill>
);
const Atmosphere = ({ f, pulse }: { f: number; pulse: number }) => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <svg width={W} height={H}>
      {particles.map((p, i) => (
        <circle
          key={i}
          cx={(p.x + Math.sin(f / 80 + i) * 25 + 1080) % 1080}
          cy={(p.y - f * p.s + 10000) % 1920}
          r={p.r * 0.65}
          fill="#d8edff"
          opacity={0.1 + (i % 5) * 0.05}
        />
      ))}
    </svg>
    {[0, 1, 2].map((i) => (
      <div
        key={i}
        style={{
          position: "absolute",
          left: -380 + i * 280 + Math.sin(f / 65 + i) * 160,
          top: 1480 - i * 490 - Math.sin(f / 95 + i) * 100,
          width: 1250,
          height: 380,
          borderRadius: "50%",
          background: "radial-gradient(ellipse,#90b7e51c,transparent 65%)",
          transform: `rotate(${-12 + i * 11}deg)`,
          filter: "blur(18px)",
        }}
      />
    ))}
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at ${25 + Math.sin(f / 80) * 15}% 30%,#2458bb${Math.round(
          12 + pulse * 12,
        )
          .toString(16)
          .padStart(
            2,
            "0",
          )},transparent 65%),radial-gradient(ellipse at 85% 65%,#9225bf25,transparent 70%)`,
        mixBlendMode: "screen",
      }}
    />
    <AbsoluteFill
      style={{
        background: "radial-gradient(ellipse,transparent 30%,#00000085 100%)",
      }}
    />
  </AbsoluteFill>
);
const Door = ({
  open,
  f,
  closing = false,
}: {
  open: number;
  f: number;
  closing?: boolean;
}) => (
  <AbsoluteFill style={{ perspective: 1600 }}>
    <AbsoluteFill
      style={{
        transformOrigin: "0% 50%",
        transform: `rotateY(${-open * 108}deg)`,
        border: "30px solid #18324d",
        borderRadius: 18,
        background:
          "linear-gradient(115deg,#142e4a 2%,#0b1630 30%,#0c1c36 66%,#243958)",
        boxShadow: "inset 0 0 90px #030819,inset 5px 0 20px #b7e7ff55",
      }}
    >
      <Glass f={f} heavy />
      <Cracks f={100} opacity={0.09} />
      <div
        style={{
          position: "absolute",
          right: 95,
          top: 190,
          padding: "18px 30px",
          background: "#03081b",
          border: "4px solid #344b6f",
          color: "#b3ebff",
          font: "70px monospace",
          textShadow: "0 0 16px #288bff",
          transform: "rotate(-2deg)",
        }}
      >
        −18°
      </div>
      <div
        style={{
          position: "absolute",
          top: 600,
          left: 80,
          width: 850,
          transform: "rotate(-10deg)",
          color: "#e5f4ff",
          font: "174px Marker",
          letterSpacing: -12,
          textShadow: "2px 7px #4b9cff,0 0 30px #68b9ff44",
        }}
      >
        CHEKI
      </div>
      <div
        style={{
          position: "absolute",
          top: 850,
          left: 170,
          font: "64px Marker",
          color: "#ac6cf6",
          transform: "rotate(-10deg)",
        }}
      >
        LOS DIOZES
      </div>
      <div
        style={{
          position: "absolute",
          top: 1000,
          left: 230,
          transform: "rotate(-8deg)",
        }}
      >
        <Crown size={150} color="#b0bfff" />
      </div>
      <div
        style={{
          position: "absolute",
          right: 60,
          top: 760,
          width: 37,
          height: 470,
          background: "linear-gradient(90deg,#020714,#6d899f,#0c1531)",
          borderRadius: 20,
          boxShadow: "-14px 8px 18px #0008",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: 150,
          left: 100,
          font: "19px monospace",
          letterSpacing: 8,
          color: "#adc9df88",
        }}
      >
        MESÓN MASÓN
      </div>
    </AbsoluteFill>
  </AbsoluteFill>
);
const HeroIce = ({ f, scale = 1 }: { f: number; scale?: number }) => (
  <div
    style={{
      position: "absolute",
      left: 60,
      top: 420,
      width: 960,
      height: 1000,
      transform: `translateY(${Math.sin(f / 32) * 24}px) rotate(${-9 + Math.sin(f / 60) * 5}deg) scale(${scale})`,
      filter: "drop-shadow(0 0 35px #427bc744)",
    }}
  >
    <Img
      src={staticFile("assets/hero-ice.png")}
      style={{ width: "100%", height: "100%", objectFit: "contain" }}
    />
  </div>
);
const Performer = ({
  f,
  close = false,
  side = false,
}: {
  f: number;
  close?: boolean;
  side?: boolean;
}) => (
  <div
    style={{
      position: "absolute",
      left: close ? -210 : side ? 200 : 20,
      top: close ? -10 : 210,
      width: close ? 1650 : 1080,
      height: close ? 2475 : 1620,
      transform: `translate(${Math.sin(f / 43) * 12}px,${Math.sin(f / 29) * 9}px) rotate(${Math.sin(f / 76) * 0.9}deg) scale(${1 + f * 0.00045})`,
      transformOrigin: close ? "50% 20%" : "50% 75%",
      filter: "drop-shadow(-15px 0 24px #389af533)",
    }}
  >
    <Img
      src={staticFile("assets/performer.png")}
      style={{ width: "100%", height: "100%", objectFit: "contain" }}
    />
  </div>
);
const Scene = ({
  id,
  f,
  len,
  pulse,
}: {
  id: number;
  f: number;
  len: number;
  pulse: number;
}) => {
  switch (id) {
    case 0:
      return (
        <>
          <Performer f={f} side />
          <Door open={ease((f - 8) / 55)} f={f} />
        </>
      );
    case 1:
      return (
        <>
          <Performer f={f} />
          <IceField f={f} light />
        </>
      );
    case 2:
      return (
        <>
          <HeroIce f={f} />
          <IceField f={f} />
        </>
      );
    case 3:
      return (
        <>
          <div
            style={{
              position: "absolute",
              left: 110,
              top: 490,
              transform: `perspective(1200px) rotateY(${-15 + f * 0.22}deg) rotateZ(-8deg)`,
              display: "flex",
              gap: 80,
            }}
          >
            {[0, 1, 2].map((i) => (
              <Can key={i} f={f} index={i} scale={1.15} />
            ))}
          </div>
          <div
            style={{
              position: "absolute",
              left: 0,
              right: 0,
              top: 1120,
              height: 35,
              background: "linear-gradient(#b6e6ff,#172a52,#040b1b)",
              transform: "rotate(-8deg)",
              boxShadow: "0 5px 30px #644bfc",
            }}
          />
          <IceField f={f} />
        </>
      );
    case 4:
      return (
        <>
          <div
            style={{
              position: "absolute",
              left: 270,
              top: 480,
              transform: `perspective(1600px) rotateZ(${-12 + f * 0.12}deg) scale(2.1)`,
            }}
          >
            <Can f={f} />
          </div>
          <Glass f={f} heavy />
          <Cracks f={f} opacity={0.24} />
        </>
      );
    case 5:
      return (
        <>
          <div
            style={{
              opacity: 0.52,
              filter: "blur(2px)",
              transform: `translateX(${-f * 0.45}px) scaleX(-1)`,
            }}
          >
            <Performer f={f} close />
          </div>
          <Glass f={f} heavy />
          <div
            style={{
              position: "absolute",
              left: 700,
              top: 0,
              height: 1920,
              width: 14,
              background: "#b6f2ff",
              boxShadow: "0 0 45px #469dff",
              transform: "rotate(8deg)",
            }}
          />
        </>
      );
    case 6:
      return (
        <>
          <div style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
            <Img
              src={staticFile("assets/performer.png")}
              style={{
                position: "absolute",
                height: 4100,
                width: 2734,
                objectFit: "contain",
                left: -700 + f * 0.6,
                top: -2650,
                transform: `rotate(${-12 + f * 0.1}deg)`,
              }}
            />
          </div>
          <IceField f={f} />
        </>
      );
    case 7:
      return (
        <>
          <div
            style={{
              position: "absolute",
              left: 235,
              top: 750,
              width: 610,
              height: 680,
              transform: `rotate(${-8 + Math.sin(f / 40) * 4}deg)`,
              background:
                "linear-gradient(95deg,#34275d,#7062b8 28%,#443670 60%,#130f30)",
              clipPath: "polygon(0 0,100% 0,86% 100%,14% 100%)",
              borderTop: "22px solid #b3b9f4",
              boxShadow: "inset 0 0 70px #050517",
            }}
          />
          <svg
            width={1080}
            height={1920}
            style={{ position: "absolute", top: 0 }}
          >
            <path
              d={`M${240 + Math.sin(f / 20) * 40} 180Q540 360 530 830`}
              stroke="#9bd2ff88"
              strokeWidth={22 + pulse * 15}
              fill="none"
            />
            <path
              d={`M${240 + Math.sin(f / 20) * 40} 180Q540 360 530 830`}
              stroke="#efffff88"
              strokeWidth="4"
              fill="none"
            />
          </svg>
          <HeroIce f={f} scale={0.54} />
          <IceField f={f} light />
        </>
      );
    case 8:
      return (
        <>
          <Performer f={f} close />
          <div
            style={{
              position: "absolute",
              left: -100,
              top: 570,
              width: 1300,
              height: 15,
              background: "#9968ff99",
              boxShadow: "0 0 40px #7341ff",
              transform: "rotate(-20deg)",
            }}
          />
          <Glass f={f} />
        </>
      );
    case 9:
      return (
        <>
          <HeroIce f={f} scale={1.55} />
          <Cracks f={f} opacity={0.6} />
        </>
      );
    case 10:
      return (
        <>
          <div
            style={{
              transform: `scale(.85) rotate(-12deg) translateY(-120px)`,
              filter: "saturate(.45) contrast(1.3)",
            }}
          >
            <Performer f={f} />
            <IceField f={f} />
          </div>
          <AbsoluteFill
            style={{
              background:
                "repeating-linear-gradient(0deg,transparent,transparent 5px,#0005 6px,#0005 8px)",
            }}
          />
          <div
            style={{
              position: "absolute",
              top: 200,
              left: 100,
              font: "24px monospace",
              color: "#c0e7ff",
            }}
          >
            CAM 03 · −18°C
          </div>
          <div
            style={{
              position: "absolute",
              top: 202,
              right: 110,
              width: 14,
              height: 14,
              background: "#a78bea",
              borderRadius: "50%",
              opacity: 0.5 + pulse * 0.5,
            }}
          />
        </>
      );
    case 11:
      return (
        <>
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                inset: 100 + i * 65,
                border: "3px solid #9bbdff55",
                transform: `perspective(800px) rotateY(${Math.sin(f / 90) * 14}deg) translateZ(${(f % 60) * 2 - i * 50}px)`,
                boxShadow: "inset 0 0 40px #493c7133",
              }}
            />
          ))}
          <Performer f={f} side />
          <Glass f={f} />
        </>
      );
    case 12:
      return (
        <>
          <HeroIce f={f} scale={1 - clamp(f / 65) * 0.5} />
          <IceField f={f} burst />
          <Cracks f={f} opacity={1 - clamp(f / 60)} />
        </>
      );
    case 13:
      return (
        <>
          <Performer f={f} />
          <IceField f={f} light />
          <div
            style={{
              position: "absolute",
              top: 130,
              left: 465,
              transform: `rotate(${Math.sin(f / 20) * 10}deg)`,
              opacity: 0.7,
            }}
          >
            <Crown size={180} />
          </div>
        </>
      );
    default:
      return (
        <>
          <Door open={1 - ease(f / (len * 0.7))} f={f} closing />
          <Glass f={f} heavy />
        </>
      );
  }
};
export const Freezer: React.FC = () => {
  const f = useCurrentFrame();
  let scene = 0;
  features.cuts.forEach((c, i) => {
    if (f >= c) scene = i;
  });
  const local = f - features.cuts[scene];
  const len = (features.cuts[scene + 1] ?? 1287) - features.cuts[scene];
  const pulse = features.pulse[f] ?? 0;
  const cam = scene === 8 ? 1.1 : scene === 10 ? 0.98 : 1.03 + local * 0.00045;
  return (
    <AbsoluteFill style={{ background: "#020612", overflow: "hidden" }}>
      <style>{`@font-face{font-family:Marker;src:url('${staticFile("fonts/Marker.ttf")}')}@font-face{font-family:Title;src:url('${staticFile("fonts/Title.ttf")}')}`}</style>
      <Audio src={staticFile("cheki-fragment.mp3")} />
      <AbsoluteFill
        style={{
          transform: `scale(${cam}) translate(${Math.sin(f / 73) * 9}px,${Math.cos(f / 90) * 6}px)`,
        }}
      >
        <Img
          src={staticFile("assets/freezer-tunnel.png")}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            filter: `brightness(${scene === 9 ? 0.32 : 0.62}) saturate(1.15)`,
            transform: `scale(${1.04 + local * 0.0007}) translateX(${Math.sin(local / 65) * 12}px)`,
          }}
        />
        <Scene id={scene} f={local} len={len} pulse={pulse} />
      </AbsoluteFill>
      <Atmosphere f={f} pulse={pulse} />
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(#020612bb 0%,transparent 20%,transparent 78%,#020612a0 100%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: 85,
          left: 75,
          right: 75,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          color: "#c8e3f0",
          font: "18px monospace",
          letterSpacing: 6,
          opacity: 0.72,
        }}
      >
        <span>CHEKI</span>
        <span style={{ fontSize: 14, letterSpacing: 4 }}>LOS DIOZES</span>
      </div>
      <References f={f} />
      <KineticLyrics f={f} scene={scene} />
      {scene > 0 && local < 10 && (
        <Cracks f={local} opacity={(1 - local / 10) * 0.5} />
      )}
      <AbsoluteFill
        style={{
          background: "#add8ff",
          opacity: local < 3 && scene > 0 ? (1 - local / 3) * 0.12 : 0,
          mixBlendMode: "screen",
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage:
            "url('data:image/svg+xml,%3Csvg viewBox=%220 0 180 180%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22n%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%22.85%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 opacity=%22.6%22 filter=%22url(%23n)%22/%3E%3C/svg%3E')",
          backgroundSize: "180px 180px",
          opacity: 0.055,
          transform: `translate(${(f % 3) - 1}px,${(f % 5) - 2}px) scale(1.01)`,
          mixBlendMode: "screen",
        }}
      />
      <AbsoluteFill
        style={{
          background: "#020612",
          opacity: f < 6 ? 1 - f / 6 : f > 1280 ? (f - 1280) / 7 : 0,
        }}
      />
    </AbsoluteFill>
  );
};
