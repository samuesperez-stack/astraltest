import React from "react";
import lyrics from "../lyrics.json";
import features from "../audio-features.json";
import { referenceActive } from "./references";
const clamp = (v: number) => Math.max(0, Math.min(1, v));
const ease = (v: number) => 1 - Math.pow(1 - clamp(v), 3);
const extrusion =
  "1px 1px #1d3155,2px 2px #1d3155,3px 3px #1b294b,4px 4px #141d3d,5px 5px #101632,6px 6px #0c1228,0 9px 15px #000b";
export const KineticLyrics: React.FC<{ f: number; scene: number }> = ({
  f,
  scene,
}) => {
  const t = f / 30,
    cue = lyrics.cues.find((c) => t >= c.start && t < c.end);
  if (!cue) return null;
  const age = (t - cue.start) * 30,
    remaining = (cue.end - t) * 30,
    entry = ease(age / 5),
    exit = clamp(remaining / 4),
    frozen = [2, 9, 12].includes(scene);
  const reaction = referenceActive(f);
  const lower = [0, 8, 14].includes(scene) || reaction;
  const tilt = frozen ? -6 : cue.line % 2 ? 2 : -2;
  const size = cue.text.length > 31 ? 65 : cue.text.length > 23 ? 77 : 92;
  const pulse = features.pulse[f] ?? 0;
  const top = reaction ? 1210 : lower ? 1280 : frozen ? 720 : 760;
  return (
    <div
      style={{
        position: "absolute",
        left: 76,
        right: 76,
        top,
        textAlign: "center",
        opacity: entry * exit,
        transform: `perspective(1200px) translateY(${(1 - entry) * (cue.line % 2 ? -22 : 28)}px) rotate(${tilt}deg) rotateX(${(1 - entry) * 12}deg) skewX(${(1 - entry) * -7}deg)`,
        transformOrigin: "50% 50%",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: -65,
          background: "radial-gradient(ellipse,#020a1bd9,transparent 74%)",
          filter: "blur(14px)",
        }}
      />
      {frozen && (
        <div
          style={{
            position: "absolute",
            inset: -32,
            clipPath: "polygon(2% 6%,93% 0,100% 12%,97% 92%,7% 100%,0 86%)",
            background:
              "linear-gradient(135deg,#c6ecff1a,#5472bd09 50%,#b894ff25)",
            boxShadow: "inset 0 0 30px #c5eaff44",
            border: "2px solid #c6eaff66",
          }}
        />
      )}
      <div
        style={{
          position: "relative",
          fontFamily: "Marker",
          fontSize: size,
          lineHeight: 1.39,
          textTransform: "uppercase",
          letterSpacing: -2,
        }}
      >
        {cue.words.map((word, i) => {
          const on = t >= word.start && t < word.end,
            past = t >= word.end;
          const wf = (t - word.start) * 30;
          const impact = on ? Math.exp(-Math.max(0, wf) / 5) : 0;
          const scale = on
            ? 1.02 +
              0.065 * impact +
              Math.sin(Math.max(0, wf) * 0.75) *
                0.025 *
                Math.exp(-Math.max(0, wf) / 10)
            : 1;
          const color = on ? "#c196ff" : past ? "#e6f6ff" : "#cbdce9";
          const split = on && wf < 3 ? 1 - wf / 3 : 0;
          const chips = on && wf < 12;
          const text = word.word;
          return (
            <span
              key={`${cue.start}-${i}`}
              style={{
                display: "inline-block",
                position: "relative",
                margin: "0 11px",
                transform: `translate(${on ? Math.sin(wf * 1.5) * impact * 2 : 0}px,${on ? -5 - impact * 5 : 0}px) rotate(${on ? (i % 2 ? 1 : -1) * impact * 2 : 0}deg) scale(${scale})`,
                zIndex: on ? 2 : 1,
              }}
            >
              {on && (
                <span
                  style={{
                    position: "absolute",
                    left: -9,
                    right: -9,
                    top: "62%",
                    height: "23%",
                    background:
                      "linear-gradient(90deg,#549dfc22,#9e68f366,#6bbcff18)",
                    clipPath: "polygon(0 18%,95% 0,100% 75%,3% 100%)",
                    transform: `scaleX(${ease(wf / 5)})`,
                    transformOrigin: "left",
                    filter: "blur(1px)",
                  }}
                />
              )}
              {split > 0 && (
                <>
                  <span
                    aria-hidden
                    style={{
                      position: "absolute",
                      inset: 0,
                      color: "#56d7ff",
                      opacity: split * 0.65,
                      transform: `translateX(${-7 * split}px)`,
                      clipPath: "inset(5% 0 50% 0)",
                    }}
                  >
                    {text}
                  </span>
                  <span
                    aria-hidden
                    style={{
                      position: "absolute",
                      inset: 0,
                      color: "#b86eff",
                      opacity: split * 0.65,
                      transform: `translateX(${7 * split}px)`,
                      clipPath: "inset(50% 0 5% 0)",
                    }}
                  >
                    {text}
                  </span>
                </>
              )}
              <span
                style={{
                  position: "relative",
                  color,
                  textShadow: extrusion,
                  WebkitTextStroke: on ? ".7px #dceaff" : ".4px #d2e7f466",
                  filter: on
                    ? `drop-shadow(0 0 ${6 + pulse * 7}px #9150ff44)`
                    : undefined,
                }}
              >
                {text}
              </span>
              {on && (
                <svg
                  width="100%"
                  height="18"
                  viewBox="0 0 220 18"
                  preserveAspectRatio="none"
                  style={{
                    position: "absolute",
                    left: 0,
                    bottom: -5,
                    overflow: "visible",
                  }}
                >
                  <path
                    d="M2 12L72 4L94 10L139 3L158 9L218 2"
                    stroke="#9bd6ff"
                    strokeWidth="3"
                    strokeLinecap="round"
                    fill="none"
                    strokeDasharray="240"
                    strokeDashoffset={240 * (1 - ease(wf / 5))}
                  />
                </svg>
              )}
              {chips &&
                Array.from({ length: 5 }, (_, k) => {
                  const a = ((k * 72 + i * 19) * Math.PI) / 180,
                    d = 12 + wf * 3.5;
                  return (
                    <span
                      key={k}
                      style={{
                        position: "absolute",
                        left: `calc(50% + ${Math.cos(a) * d}px)`,
                        top: `calc(50% + ${Math.sin(a) * d}px)`,
                        width: 3 + (k % 2) * 2,
                        height: 8 + (k % 3) * 3,
                        background: k % 2 ? "#bb8fff" : "#d9f7ff",
                        opacity: (1 - wf / 12) * 0.7,
                        transform: `rotate(${k * 42 + wf * 9}deg)`,
                        pointerEvents: "none",
                      }}
                    />
                  );
                })}
            </span>
          );
        })}
      </div>
      {frozen && (
        <svg
          width="100%"
          height="100%"
          style={{
            position: "absolute",
            inset: 0,
            pointerEvents: "none",
            opacity: 0.16 + pulse * 0.12,
          }}
        >
          <path
            d="M0 5L90 15L140 0M820 30L770 75L800 130M30 150L80 120L100 135"
            stroke="#d0ecff"
            strokeWidth="1.5"
            fill="none"
          />
        </svg>
      )}
    </div>
  );
};
