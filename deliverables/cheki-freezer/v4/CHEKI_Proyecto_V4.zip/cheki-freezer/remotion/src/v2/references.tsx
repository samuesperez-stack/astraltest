import React from "react";
import { AbsoluteFill, Img, staticFile } from "remotion";
import lyrics from "../lyrics.json";
const clamp = (v: number) => Math.min(1, Math.max(0, v));
const ease = (v: number) => 1 - Math.pow(1 - clamp(v), 3);
const periCue = lyrics.cues.find((c) => c.text.includes("peri qué"))!;
const periWord = periCue.words.find((w) => w.word.includes("peri"))!;
export const references = {
  periIn: periCue.start - 0.24,
  periOut: periCue.end + 0.32,
  encoderIn: 34.05,
  encoderOut: 37.05,
};
export const referenceActive = (f: number) => {
  const t = f / 30;
  return (
    (t >= references.periIn && t < references.periOut) ||
    (t >= references.encoderIn && t < references.encoderOut)
  );
};
const burst = (frame: number, x: number, y: number) =>
  Array.from({ length: 9 }, (_, i) => {
    const a = (i * Math.PI * 2) / 9;
    const d = 55 + frame * 7;
    return (
      <div
        key={i}
        style={{
          position: "absolute",
          left: x + Math.cos(a) * d,
          top: y + Math.sin(a) * d,
          width: 5 + (i % 3) * 3,
          height: 15 + (i % 4) * 5,
          background: i % 2 ? "#b08bff" : "#d6f7ff",
          opacity: clamp(1 - frame / 18),
          transform: `rotate(${i * 40 + frame * 5}deg)`,
        }}
      />
    );
  });
export const References: React.FC<{ f: number }> = ({ f }) => {
  const t = f / 30;
  const per = t >= references.periIn && t < references.periOut;
  const enc = t >= references.encoderIn && t < references.encoderOut;
  const last = lyrics.cues.find(
    (c) => t >= c.start && t < c.end && c.line === 14,
  );
  if (per) {
    const local = (t - references.periIn) * 30;
    const duration = (references.periOut - references.periIn) * 30;
    const enter = ease(local / 6),
      out = clamp((duration - local) / 5);
    const scale =
      0.7 + enter * 0.3 + Math.sin(local * 0.65) * Math.exp(-local / 12) * 0.05;
    return (
      <AbsoluteFill style={{ pointerEvents: "none", opacity: out }}>
        <div
          style={{
            position: "absolute",
            left: 105,
            top: 190,
            width: 870,
            height: 850,
            background: "radial-gradient(ellipse,#6535bc55,transparent 67%)",
            transform: `scale(${enter})`,
          }}
        />
        {burst(local, 540, 550)}
        <Img
          src={staticFile("assets/illojuan-sticker.png")}
          style={{
            position: "absolute",
            left: 190 + (1 - enter) * 600,
            top: 235,
            width: 700,
            height: 730,
            objectFit: "contain",
            transform: `rotate(${-7 + enter * 4}deg) scale(${scale})`,
            filter: "drop-shadow(0 15px 22px #020717bb)",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 160,
            top: 900,
            width: 760,
            transform: `scale(${scale}) rotate(-5deg)`,
            textAlign: "center",
            fontFamily: "Marker",
            fontSize: 94,
            lineHeight: 1.14,
            color: "#eefbff",
            textShadow: "5px 7px #211744,-3px -3px #8953d7,0 0 25px #8664ff55",
          }}
        >
          ¿UN PERI QUÉ?
        </div>
        <div
          style={{
            position: "absolute",
            top: 1050,
            left: 370,
            color: "#b993ff",
            font: "22px monospace",
            letterSpacing: 9,
            transform: "rotate(-5deg)",
          }}
        >
          ILLOJUAN
        </div>
      </AbsoluteFill>
    );
  }
  if (enc) {
    const local = (t - references.encoderIn) * 30,
      duration = (references.encoderOut - references.encoderIn) * 30;
    const e = ease(local / 8),
      out = clamp((duration - local) / 7);
    const progress = Math.min(100, Math.floor(18 + local * 1.8));
    const shift = local < 6 ? (1 - e) * 75 : 0;
    return (
      <AbsoluteFill style={{ pointerEvents: "none", opacity: e * out }}>
        <div
          style={{
            position: "absolute",
            left: 85 + shift,
            top: 235,
            width: 910,
            height: 800,
            background: "radial-gradient(ellipse,#274b9c66,transparent 70%)",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 90 - shift,
            top: 230,
            width: 790,
            padding: "26px 32px",
            background: "linear-gradient(120deg,#091329e8,#1b1640df)",
            border: "2px solid #a8d8ff88",
            boxShadow: "10px 15px 0 #0005,inset 0 0 40px #4264ba33",
            transform: `perspective(1300px) rotateY(${-8 + e * 4}deg) rotateZ(-3deg)`,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              borderBottom: "1px solid #bedaff33",
              paddingBottom: 18,
              color: "#a4c8eb",
              font: "19px monospace",
              letterSpacing: 4,
            }}
          >
            <span>FREEZER.EXE</span>
            <span>● REC</span>
          </div>
          <div
            style={{
              font: "55px Marker",
              lineHeight: 1.22,
              color: "#edf8ff",
              marginTop: 27,
            }}
          >
            ESTOY CODIFICANDO
          </div>
          <div
            style={{
              font: "61px Marker",
              lineHeight: 1.25,
              color: "#bb88ff",
              textShadow: "0 0 20px #8c53e766",
            }}
          >
            A MÁXIMA CALIDAD
          </div>
          <div
            style={{
              marginTop: 26,
              width: "100%",
              height: 22,
              background: "#050c1e",
              border: "1px solid #8cb5d477",
              padding: 3,
            }}
          >
            <div
              style={{
                width: `${progress}%`,
                height: "100%",
                background: "linear-gradient(90deg,#488df2,#b77dff)",
                boxShadow: "0 0 16px #7440e7",
              }}
            />
          </div>
          <div
            style={{
              font: "16px monospace",
              letterSpacing: 2,
              color: "#9cbdd8",
              marginTop: 14,
            }}
          >
            1080 × 1920 · 30 FPS · {progress}%
          </div>
        </div>
        <Img
          src={staticFile("assets/xokas-sticker.png")}
          style={{
            position: "absolute",
            left: 535 + (1 - e) * 500,
            top: 535,
            width: 490,
            height: 570,
            objectFit: "contain",
            transform: `rotate(${5 + Math.sin(local / 9) * 2}deg) scale(${0.9 + e * 0.1})`,
            filter: "drop-shadow(0 15px 20px #020717cc)",
          }}
        />
        <div
          style={{
            position: "absolute",
            left: 665,
            top: 1080,
            font: "21px monospace",
            letterSpacing: 7,
            color: "#bd95ff",
            transform: "rotate(4deg)",
          }}
        >
          XOKAS
        </div>
      </AbsoluteFill>
    );
  }
  if (last) {
    const names = last.text.includes("Spok")
      ? ["SPOK"]
      : last.text.includes("Juanito")
        ? ["JUANITO"]
        : last.text.includes("Sceno")
          ? ["SCENO"]
          : [];
    const e = ease(((t - last.start) * 30) / 5);
    return (
      <AbsoluteFill style={{ pointerEvents: "none" }}>
        {names.map((name) => (
          <div
            key={name}
            style={{
              position: "absolute",
              top: 225,
              left: 110,
              right: 110,
              textAlign: "center",
              transform: `translateX(${(1 - e) * -650}px) rotate(-5deg)`,
              opacity: e,
            }}
          >
            <div
              style={{
                font: "16px monospace",
                letterSpacing: 6,
                color: "#9cbddd",
                marginBottom: 12,
              }}
            >
              MESÓN MASÓN
            </div>
            <div
              style={{
                font: "86px Marker",
                color: "#b68afa",
                textShadow: "4px 6px #10234f",
              }}
            >
              {name}
            </div>
            <div
              style={{
                marginTop: 15,
                font: "18px monospace",
                letterSpacing: 8,
                color: "#c7e9ff",
              }}
            >
              LOS DIOZES
            </div>
          </div>
        ))}
      </AbsoluteFill>
    );
  }
  return null;
};
