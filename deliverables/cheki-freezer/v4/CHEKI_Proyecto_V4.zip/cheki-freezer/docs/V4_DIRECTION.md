# CHEKI V4 — El directo pierde el control

## Dirección aprobada en conversación

Un directo intenta convertirse en un videoclip, pero las rimas transforman el escenario. Esta revisión sustituye el storyboard de nevera. Se permiten cortes; no se exige un one-take. La habitación, el aula, la ventanilla, el teatro, el supermercado, el control virtual y el escenario final comparten una iluminación cálida con acentos digitales fríos.

Las 16 barras del usuario se conservan en `src/lyrics.json`. Las marcas son editoriales heredadas y no han sido verificadas a oído palabra por palabra. No afirmar sincronía vocal perfecta.

## Implementación

`remotion/src/v4/show.tsx`, composición `ChekiRealityV4`, 1287 frames, 30 fps, 1080×1920, audio original. Animación determinista de recortes 2.5D, objetos, texto, geometría SVG e interfaces; fondos fotográficos con una capa adicional del mostrador/escritorio para oclusión. Los personajes son recreaciones generadas con poses intercambiables, sin articulación humana 3D ni lip-sync.

1. Chat pide 16 barras; emerge jaula y se disuelve con barro.
2. Tubo y cinta de crema blanca opaca; letra negra sobre blanco.
3. Versos de papel y mano mecánica.
4. Garra rasga el fondo, aparecen pizarras y aquelarre.
5. Pantalla de derrota retirada lateralmente.
6. Ventanilla burocrática; IlloJuan recreado aparece en un marco lateral en «¿un peri qué?».
7. Escala, fragmentación del protagonista y foco de interrogatorio.
8. Colapso del telón del teatro.
9. Noble de cartón y roble que se reduce a bonsái.
10. Supermercado chino de barrio: escáner y productos que se duplican.
11. Duelo entre productos duplicados, retícula y victoria precisa.
12. Contador de quince años y despegue de silla/personaje.
13. Selector de vestuario descartado.
14. Control virtual desbordado: «ESTOY CODIFICANDO A MÁXIMA CALIDAD».
15. Entradas rotuladas SPOK / JUANITO / SCENO al escenario. Los rótulos representan las menciones; no se generaron retratos verificados de Spok o Sceno.
16. YO SUENO y cierre CHEKI / LOS DIOZES.

Tipografía: Bebas Neue principal, Anton en reacciones/remates, IBM Plex Mono en interfaces. Dos filas como máximo en letras principales, márgenes laterales, sombra corta; la crema usa contraste negro sobre blanco.

## Procedencia

Las 14 imágenes originales nuevas se conservan en `public/assets/v4/originals/`, con SHA-256 en `manifest.json`. Son generaciones originales de image_gen durante esta conversación. Los cameos representan editorialmente a Xokas e IlloJuan; no son imágenes oficiales ni reacciones reales. `scripts/prepare_v4_assets.py` separa los recortes sin sobrescribir los originales; el manifiesto procesado registra sus hashes.

Fuentes descargadas del repositorio Google Fonts, cada una con su OFL incluida:
- https://raw.githubusercontent.com/google/fonts/main/ofl/bebasneue/BebasNeue-Regular.ttf
- https://raw.githubusercontent.com/google/fonts/main/ofl/anton/Anton-Regular.ttf
- https://raw.githubusercontent.com/google/fonts/main/ofl/ibmplexmono/IBMPlexMono-Regular.ttf

El meme de codificación fue solicitado por el usuario; su origen/autoría no está verificado. No se añadió grabación o voz sintética del meme. Las referencias y la transcripción no acreditan derechos de distribución comercial del audio.

## Exportación y límites de revisión

`npm run render` exporta V4. `npm run render:v1`, `render:v2` y `render:v3` conservan los anteriores. V4 no requiere API, descarga de fuentes ni acceso externo una vez instalado. La preparación de assets necesita Pillow y red únicamente si faltan fuentes; no es un paso del render normal.

Se revisa una prueba inicial de 6 segundos antes de exportar todo. La entrega debe incluir comprobación técnica de resolución, duración, decodificación y preservación del audio. La sincronía fonética y la semejanza de las recreaciones requieren revisión humana.
