# Criterios de aceptación

1. [ ] 1080x1920, 30 fps; duración dentro de un frame del audio, sin cola silenciosa no intencionada.
2. [ ] Audio original integrado, sin clipping ni recortes inesperados, A/V sync verificado a oído.
3. [ ] Transcripción de cada barra revisada; sin rótulos «LETRA FRASE» ni errores ortográficos generados en imágenes.
4. [ ] Cue por palabra o pequeñas agrupaciones; cada énfasis principal calza con la voz.
5. [ ] 15 beats/escenas narrativas o cobertura equivalente, no simple slideshow de fotos.
6. [ ] Tres efectos de firma: puerta/vapor; hielo que aprisiona rima; impacto/grieta y partículas.
7. [ ] Parallax o movimiento real entre capas; texturas con animación independiente, no simple Ken Burns.
8. [ ] Texto a resolución móvil legible; contrastes, zonas seguras y áreas sin obstrucción.
9. [ ] Revisión manual de stills y segmentos de 0-8s, 18-26s y 35-final.
10. [ ] `npm run render` o comando equivalente documentado y ejecutado con éxito.
11. [ ] Final en `out/CHEKI_Freezer_Final.mp4`; proyecto editable conservado.
12. [ ] Documentar assets con licencia/procedencia; no afirmar derechos comerciales por incluir el MP3.
