# Editar el montaje

## Escenas
`src/video.tsx` contiene un componente por recurso y una selección de 15 escenas. Los cortes, en frames de 30 fps, están en `src/audio-features.json` y documentados en `docs/SCENE_CUTS.json`.

1. Puerta que abre con título y luz interior.
2. Personaje completo y partículas de hielo.
3. Bloque fotográfico con letras sobre hielo.
4. Latas independientes sobre estante.
5. Macro de lata y condensación.
6. Reflejo del personaje y vidrio.
7. Detalle de zapatillas y cristales.
8. Vaso, vertido estilizado y bloque de hielo.
9. Primer plano del personaje y barrido de luz.
10. Hielo macro y grietas.
11. Vista de cámara de seguridad.
12. Pasillo en profundidad y marcos de cristal.
13. Explosión de cubos CSS 3D.
14. Personaje completo y corona.
15. Cierre de puerta, última frase y título.

La foto del personaje es un recorte independiente con movimiento de cámara; no hay animación corporal o labial generativa. El vertido y el vaso son estilizados. La escena no pretende documentar una actuación real.

## Letra
El texto exacto del usuario se conserva en `docs/LYRICS.md` y `src/lyrics.json`. Los cues agrupan palabras para lectura en móvil; cada palabra tiene `start` y `end` en segundos. Corregir esos tiempos en JSON permite alinear el resaltado.

Para regenerar todos los cues, editar `starts` en `scripts/build_lyrics.py`. Ejecutarlo sobrescribe el JSON y el SRT; conservar antes cualquier corrección manual de palabra.

Los tiempos iniciales son una propuesta editorial, no el resultado de reconocimiento de voz o alineación forzada. No se ha hecho una revisión auditiva. La extracción de energía sí utiliza el audio real y controla pulsos de luz y proximidad de cortes a transitorios.

## Exportar
Desde `remotion/`, `npm run render` exporta 1287 frames en H.264 con AAC. `npm run render:proof` exporta los primeros 180 frames. Las fuentes están empaquetadas y se sirven con `staticFile()`. Los movimientos dependen del número de frame y no de tiempo de pared ni de valores aleatorios.
