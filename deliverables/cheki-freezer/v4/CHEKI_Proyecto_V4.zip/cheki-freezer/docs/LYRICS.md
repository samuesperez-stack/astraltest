# Letra aportada por el usuario

Me piden dieciséis barras, eso significa barro

Mi lefa será tu ungüento, te lo cuento, te lo narro (¿cómo?)

Los versos los despilfarro (¿eh?), yo tengo agarre

Traigo barras que son garras, pizarras sobre aquelarres

Sí, y así fue tu clásico deceso

Sentado contemplativo, un perifrástico proceso (¿un peri qué?)

Superlativo, heterobásico, confeso

Mi vida contemplativa ha sido un trágico suceso

Cuando yo hable, seduzco al noble, reduzco al roble

Y como un chino produzco el doble (chin, chon)

Con precisión te dejo inválido en el duelo

Quince años sin rimar y mira qué rápido vuelo (uh, uh)

No visto flama, ni tampoco Karl Kani

Pero ahora tengo la fama y las amazing mechanics

Pues vine con Spok, con el Juanito y con Sceno

Y es que el disco de Los Diozes es mejor porque yo sueno

Los tiempos actuales son una propuesta editorial; no se ha verificado sincronía palabra por palabra.
