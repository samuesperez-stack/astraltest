# V2 — tipografía y referencias

Se conserva el montaje de 15 escenas aprobado visualmente por el usuario y se amplía su lenguaje de letras y guiños.

## Cambios
- Volumen de letras por extrusión de sombra, contorno de escarcha, entrada con perspectiva y golpe breve al resaltar cada palabra.
- Separación cian/violeta de dos o tres frames, astillas de hielo y trazo quebrado bajo la palabra activa.
- Las frases permanecen en bloques cortos; la letra se desplaza a una zona inferior cuando hay cameo para evitar obstrucciones.
- Cameo ilustrado de IlloJuan en el cue «proceso (¿un peri qué?)», con entrada lateral, impacto y rótulo.
- Recreación visual de «Estoy codificando a máxima calidad» mediante ventana de codificación y cameo ilustrado de Xokas cerca de «amazing mechanics».
- Tarjetas SPOK, JUANITO y SCENO en sus menciones.

## Límites
Son caricaturas editoriales generadas, no clips auténticos ni voz clonada. No se verifica o atribuye el origen del meme. La investigación externa quedó bloqueada por la política de red (véase REFERENCES_V2.md). La temporización vocal sigue siendo editorial, sin ajuste auditivo palabra por palabra.

La composición V1 se conserva en `src/video-v1.tsx` y como `ChekiFreezer`; V2 usa `ChekiFreezerV2`. `npm run render` exporta V2; `npm run render:v1` conserva la exportación V1.
