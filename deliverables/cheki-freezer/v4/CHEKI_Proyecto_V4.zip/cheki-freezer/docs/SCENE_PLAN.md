# Plan de 15 escenas — orden artístico provisional

**ATENCIÓN**: bloques de referencia para animática; todas las transiciones deben reajustarse tras alineación real del verso. No alinear escenas rígidamente a estos tiempos si no coinciden con las barras.

| ID | In | Out | Dirección |
|---|---|---|---|
| 01 | 0:00 | 0:03 | Puerta congelador / LED -18°, título y humo; cámara desde exterior |
| 02 | 0:03 | 0:06 | Entrada personaje/silueta y condensación cercana; tipografía inicial |
| 03 | 0:06 | 0:09 | Bloques de hielo con rimas incrustadas; reflejos en vidrio |
| 04 | 0:09 | 0:12 | Producto y estante; letras emergen del empañado |
| 05 | 0:12 | 0:15 | Latas heladas; cortes al beat y fisuras |
| 06 | 0:15 | 0:18 | Mano / espejo de freezer y capas de escarcha |
| 07 | 0:18 | 0:21 | Objetos bajo LEDs violetas y parallax |
| 08 | 0:21 | 0:24 | Vaso/hielo / velocidad y flashes cortos |
| 09 | 0:24 | 0:27 | Primer plano de silueta, palabras con distorsión |
| 10 | 0:27 | 0:30 | Muro de hielo, lettering agrietado y microglitch |
| 11 | 0:30 | 0:33 | Cámara de seguridad freezer: perspectiva y corte |
| 12 | 0:33 | 0:36 | Pasillo de neveras, tipografía en profundidad |
| 13 | 0:36 | 0:39 | Explosión de cubos de hielo para clímax |
| 14 | 0:39 | 0:41 | Últimas barras, luz violeta y silueta |
| 15 | 0:41 | 0:42.893 | Cierre CHEKI en puerta congelador y vapor |

## Diseño de transiciones
- Establecer motivo de entrada/salida en cada escena; ningún corte debe dejar fondo estático varios segundos.
- Preferir cortes en barras, rim shots o impactos musicales, no transiciones genéricas cada 3 s.
- Hacer primero tres tipos prototipo: puerta y vapor, cristal que se agrieta, tipografía congelada que estalla.
