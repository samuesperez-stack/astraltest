# Brief de producción aprobado

**Tema**: CHEKI — Los Diozes / Xokas. Album MESÓN MASÓN.
**Entrega**: videolyric vertical experimental 1080 x 1920, 30 fps, ~42.893 s, H.264 MP4 + audio proporcionado, proyecto editable.
**Audio**: `audio/cheki-fragment.mp3`; verificar a oído inicio/final de verso y silencios.

## Dirección visual
- Concepto: freezer/nevera nocturna de estética urbana hip-hop; azul oscuro, azul eléctrico, violeta, luz azul hielo; humos de frío, condensación, reflejos, escarcha, cristales agrietados, LEDs.
- Personaje/silueta, puertas/estantes, latas/botellas, objetos congelados y dimensiones abstractas de hielo pueden funcionar como fondos y foregrounds.
- Letras como elementos físicos del mundo: sobre vidrio empañado, atrapadas en bloques de hielo, con rotura, parpadeos luminosos y profundidad.
- Intensidad EXPERIMENTAL: muchos recursos cinéticos y energía; intercalar beats visualmente sobrios para que se lean las barras.
- Preservar una conexión estilística con videoclip oficial del enlace y época MESÓN MASÓN; no cambiar a cómic genérico ni al mesón sepia del primer boceto.
- No copiar literalmente fotogramas oficiales ni atribuir escenas generadas al clip oficial.

## Paleta base sugerida (no identidad oficial)
- Noche `#071333`; azul profundo `#132A68`; azul eléctrico `#3F86EF`; morado `#6827CE`; violeta brillante `#A54AF0`; escarcha `#D8EDFF`.

## Técnicas sugeridas
- Componer fondos y elementos por capas independientes. Cámara con `interpolate()`, `spring()`, blur y desplazamientos 2.5D/parallax.
- Utilizar `AbsoluteFill`, `Sequence`, `Audio`, SVG overlays, overlays de escarcha/condensación/partículas.
- Generar objetos visuales distintos y controlables; no ampliar posters para simular un rodaje completo.
- Priorizar overlays, cubos de hielo y roturas sincronizadas con rimas.

## Bloqueos conocidos
- Audio tiene 42.893061 s.
- `remotion/src/timeline.ts` usa marcas aproximadas, incompletas y NO alineadas con todas las palabras. Debe rehacerse.
- Storyboard póster indica tiempos ficticios de hasta 55 s; no trasladar esos tiempos.
- Render anterior no representa fidelidad requerida, solo comparador negativo.

## Actualización de esta reconstrucción
La letra completa fue facilitada por el usuario durante la producción y está en `LYRICS.md`. Esta base usa `remotion/src/lyrics.json`, no el `timeline.ts` histórico que no fue adjuntado. El montaje implementa 15 escenas y el audio completo. La temporización de palabras sigue siendo editorial y no se ha validado a oído; no se declara superado ese criterio.
