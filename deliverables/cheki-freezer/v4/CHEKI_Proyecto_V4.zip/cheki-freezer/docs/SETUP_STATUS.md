# Estado de producción y entorno

## Completado en la instancia actual
- Remotion 4.0.539, React 19.2.4, TypeScript 5.9.3; package-lock.json y npm ci verificados.
- Node 24.19.0, npm 11.9.0, Chromium 154 y FFmpeg disponibles.
- Studio en puerto 3100: arranque, compilación, HTML y bundle comprobados.
- Compilación, TypeScript y render de prueba ejecutados.
- Render completo: `npm run render` terminó con código 0.
- `out/CHEKI_Freezer_Final.mp4`: H.264/AAC, 1080×1920, 30 fps, 1287 frames, 42,9 s.
- Decodificación completa con FFmpeg sin errores; duración a menos de un frame del audio de 42.893061 s.
- Audio comparado con el original: correlación a desplazamiento cero >0,9999. No se detecta desplazamiento de la pista; esto no valida la sincronía de las palabras en pantalla.
- Pico real de audio medido con ebur128: −0,7 dBFS; pico de muestras estéreo bajo 0 dBFS y sin mesetas de clipping detectadas.
- Texto exacto del usuario conservado en 16 líneas y 35 cues. Checksum del MP3 original y su copia pública verificado.
- Revisión visual: prueba inicial, fotogramas de hielo, vaso y cierre, y hoja de contacto con una muestra de las 15 escenas. No se declara revisión manual auditiva de los segmentos.
- Prueba de seis segundos actualizada extrayendo el inicio del montaje completo sin recodificar video.

## Pendiente de revisión de producción
Los tiempos de letra son editoriales y aproximados. No hubo alineación acústica ni revisión a oído; no se afirma sincronización palabra por palabra. El acceso a modelos externos fue denegado por la política de red. Las solicitudes de dominios se guardaron en el borrador, pero no se aplicaron a esta instancia.

Es un montaje 2.5D de recursos generados con IA, fotografía por capas y gráficos procedurales. No es filmación del artista ni hay actuación/lip-sync. El vaso y el vertido son estilizados.

## Reutilización
Código, fuentes, audio y assets están incluidos en el ZIP. No hace falta conexión externa al renderizar tras instalar dependencias. Configuración reutilizable guardada en el borrador; no se ha publicado ni probado la restauración en otra tarea.

## V2 — verificación completada
- `npm run typecheck`, stills de los dos cameos y `npm run render:v2proof` completados.
- Prueba: 180 frames, tramo 13–19 segundos; decodificación completa sin errores.
- `npm run render:v2`: terminado con código 0, 1287 frames a 1080×1920/30 fps, H.264/AAC, duración 42,9 segundos.
- `scripts/verify_video.py out/CHEKI_Freezer_V2.mp4`: decodificación completa correcta, correlación a desplazamiento cero con el MP3 de 0,999978, pico real −0,7 dBFS.
- Texto exacto de las 16 líneas preservado; PNG de ambos cameos decodificados con FFmpeg. Resultado en `out/V2_source_checks.json`.
- Stills de IlloJuan y el meme de codificación inspeccionados, más hoja de contacto de las 15 escenas de la exportación completa.
- Fuentes de investigación externas aún bloqueadas; cameos ilustrados, no clips auténticos; la sincronización vocal sigue siendo editorial.
- V1 preservada y exportación actual por defecto cambiada a V2. El MP3 no fue modificado ni se añadió voz sintética.

## V3 — recorrido continuo entregable
- Nuevo escenario Three.js 0.180.0: cámara continua por geometría de congelador, estantes, puertas, cristales, personajes 2.5D y pantallas con los cameos.
- Instalación con npm ci (269 paquetes), TypeScript, compilación y prueba nativa de seis segundos verificados.
- La primera exportación completa se usó para revisar todo el recorrido. Se corrigieron superposiciones de frases, paso por el monitor y elevación de rótulos; se exportó de nuevo la versión corregida.
- Render final nativo: 1080×1920, 30 fps, 1287 frames, 42,9 s. Máster corregido conservado como `CHEKI_OneTake_V3_Master_1.mp4`.
- Copia de entrega H.264 CRF 25 preparada desde el máster para respetar el límite de archivo de GitHub; resolución/fps sin cambios y AAC copiado sin recodificar. La compresión puede reducir detalle fino respecto al máster.
- La copia final pasa decodificación completa de FFmpeg, preservación de las 16 líneas, correlación de audio a desplazamiento cero de 0,999978 y pico real de −0,7 dBFS.
- Verificación numérica de 1287 poses: trayectoria continua, sin retrocesos o saltos. Cámara sobre el suelo y dentro del pasillo.
- Inspección visual de prueba, stills de monitores/cierre y hoja de 15 muestras de la versión final corregida. Comprobación de los 1287 frames: ningún tramo negro inesperado ni secuencia congelada de cuatro frames.
- Máximo de un cue de letra simultáneo por programación; frases ajustadas a dos filas. Esto no valida alineación vocal: los tiempos siguen siendo editoriales y no se revisaron a oído.
- Consulta externa de V3: artículo de IlloJuan en Wikipedia accesible y citado en V3_RESEARCH.md. YouTube continuó bloqueado; los cameos/meme son recreaciones visuales.
- La reconexión del entorno ocurrió al terminar la exportación; los archivos resultantes se conservaron y se volvieron a comprobar. No se afirma validación de una nueva tarea independiente.
