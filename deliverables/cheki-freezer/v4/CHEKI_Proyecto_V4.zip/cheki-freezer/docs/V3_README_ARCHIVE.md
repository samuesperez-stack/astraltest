# CHEKI V3 — Freezer Vice / recorrido continuo

Videolyric de 42,9 s, vertical 1080×1920/30 fps, planteado como una cámara continua que atraviesa un escenario 3D. Se conservan las versiones anteriores.

## Versión actual
- `out/CHEKI_OneTake_V3.mp4`: recorrido completo V3.
- `out/CHEKI_V3_Proof.mp4`: prueba inicial de seis segundos de la trayectoria; el render completo incorpora ajustes posteriores de espaciado y cristales.
- `out/CHEKI_OneTake_V3_verification.json`: verificación técnica del archivo completo.
- `out/V3_camera_checks.json`: continuidad numérica y separación de la cámara respecto a suelo/estantes.

Es un **one-take simulado por animación**: escenario, estantes, puertas, luces, cámara y texto tienen coordenadas 3D. Los personajes y algunos objetos son elementos fotográficos 2.5D, no modelos humanos articulados o actuación con lip-sync. No hay cortes internos de cámara.

Los cameos de IlloJuan y Xokas son ilustraciones generadas en monitores del decorado; se mantiene el meme de codificación solicitado. La letra reproduce las 16 líneas del usuario. **Los cues vocales siguen siendo editoriales, sin verificación auditiva palabra por palabra.**

## Iniciar
Requisitos: Node 24, npm y Chromium con WebGL/SwiftShader. FFmpeg/ffprobe para preparar la copia de entrega y para las comprobaciones auxiliares.
```bash
cd /workspace/cheki-freezer/remotion
npm_config_cache=/workspace/.npm npm ci --no-audit --no-fund
npm run studio
```
Studio usa el puerto 3100. En otra máquina, ajustar `/usr/bin/chromium` en los scripts al navegador local.

## Compilar y exportar
```bash
npm run typecheck
npm run build
npm run render:v3proof
npm run render
```
V3 utiliza `--gl=swangle`, dos workers y CRF 22 para el máster. Si supera 95 MiB, `finish:v3` conserva ese máster y prepara una copia H.264 más ligera (CRF 25, o 27 si aún excede el límite), sin cambiar resolución, fps o audio. El comando `npm run render` incluye ese paso de entrega. La resolución del canvas y de la salida es 1080×1920. El render por software es más costoso que el de V1/V2; conviene comprobar una prueba antes del completo. No requiere claves o APIs externas: recursos, fuentes y audio están incluidos.

Para volver a exportar anteriores: `npm run render:v2` o `npm run render:v1`. Las composiciones son `ChekiOneTakeV3`, `ChekiFreezerV2` y `ChekiFreezer` respectivamente.

## Editar
- `src/v3/path.ts`: tiempos, posición, punto de mirada y giro lateral de la cámara.
- `src/v3/world.tsx`: geometría, materiales, luces, instancias, pantallas, puertas y palabras 3D.
- `src/lyrics.json`: palabras y tiempos editables en segundos.
- `src/audio-features.json`: pulsos medidos en el audio.
- `public/assets/v3/`: nueva textura de acero helado y nuevo personaje ficticio; las demás capas se reutilizan de V1/V2.
- `docs/V3_DIRECTION.md` y `docs/V3_RESEARCH.md`: decisiones y fuentes.

Las frases acompañan la cámara para conservar legibilidad y se retiran en el espacio al terminar. La animación depende del frame, sin reloj de pared o aleatoriedad no reproducible.

## Verificar
Desde `remotion/`:
```bash
node ../scripts/verify_v3_path.cjs
```
Desde la raíz, las herramientas de audio necesitan Python con numpy (`scripts/requirements-tools.txt`):
```bash
python -m venv .venv
.venv/bin/pip install -r scripts/requirements-tools.txt
.venv/bin/python scripts/verify_video.py out/CHEKI_OneTake_V3.mp4
```
`analyze_audio.py` y `build_lyrics.py` regeneran datos; el segundo sobrescribe cues corregidos a mano. Los JSON ya están incluidos, por lo que Python no es necesario para iniciar o renderizar.

La investigación de V3 pudo consultar una fuente secundaria sobre IlloJuan/Los Diozes, descrita en `V3_RESEARCH.md`. YouTube continúa bloqueado; no se ha verificado el origen del meme ni se han descargado clips oficiales. El audio es el proporcionado por el usuario; incluirlo no acredita derechos comerciales. Véase `ASSET_PROVENANCE.md`.

`MANIFEST.json` conserva el inventario histórico recibido; `MANIFEST.current.json` registra esta reconstrucción.
