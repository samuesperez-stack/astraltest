# CHEKI V4 — El directo pierde el control

Videolyric vertical de 42,9 segundos, 1080×1920, 30 fps. Esta versión reemplaza el storyboard del freezer por una habitación de streamer que se transforma con las rimas. V1, V2 y V3 siguen disponibles.

La composición utiliza recortes 2.5D, objetos y gráficos animados por capas. Los personajes son recreaciones generadas con varias poses; no son clips reales ni animaciones con lip-sync. Las letras conservan las 16 barras facilitadas por el usuario. Sus tiempos son editoriales, pendientes de revisión auditiva palabra por palabra.

## Entrega

- `out/CHEKI_Reality_V4.mp4`: montaje completo.
- `out/CHEKI_V4_Proof.mp4`: primeros seis segundos.
- `out/CHEKI_V4_Supermercado.mp4`: fragmento de supermercado/duelo/vuelo.
- `out/V4_contact.jpg`: muestra de encuadres.
- `out/CHEKI_Reality_V4_verification.json`: comprobaciones técnicas.

Las rutas anteriores son archivos del proyecto local. Para descargar desde el chat se usa la carpeta de GitHub `deliverables/cheki-freezer/v4` en la rama `cheki-freezer-deliverables` del repositorio `samuesperez-stack/astraltest`.

## Instalar, iniciar y renderizar

Requisitos: Node 24, npm, Chromium y FFmpeg. El render usa `/usr/bin/chromium`; ajustar esa ruta para otra máquina.

```bash
cd remotion
npm ci --no-audit --no-fund
npm run typecheck
npm run build
npm run studio
```

Studio usa el puerto 3100. Para exportar:

```bash
npm run render:v4proof
npm run render
```

`npm run render` exporta la composición `ChekiRealityV4`. Los scripts `render:v1`, `render:v2` y `render:v3` permiten exportar las versiones históricas.

## Editar

- `remotion/src/v4/show.tsx`: decorados, acciones, cámara, letras e interfaces.
- `remotion/src/lyrics.json`: transcripción y cues editoriales.
- `remotion/public/assets/v4/`: fondos y recortes procesados.
- `remotion/public/assets/v4/originals/`: 14 generaciones originales y hashes.
- `remotion/public/fonts/`: Bebas Neue, Anton e IBM Plex Mono con OFL.
- `docs/V4_DIRECTION.md`: guion, decisiones, procedencia y límites.

Los assets y las fuentes están incluidos: no se necesita API o conexión externa para renderizar después de instalar dependencias. La regeneración opcional de recortes usa `python scripts/prepare_v4_assets.py` y requiere Pillow. No es necesaria para abrir o renderizar el proyecto.

Desde la raíz, la verificación técnica opcional necesita numpy y FFmpeg:

```bash
.venv/bin/python scripts/verify_video.py out/CHEKI_Reality_V4.mp4
python scripts/package_source.py --v4
```

El meme «Estoy codificando a máxima calidad» es una recreación tipográfica solicitada por el usuario; no se verificó su autoría ni se añadió su grabación original. Spok, Juanito y Sceno aparecen mediante entradas rotuladas. No se afirma que la generación represente retratos auténticos de todos los integrantes. El audio proviene del archivo del usuario; su inclusión no acredita derechos comerciales.
