from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1]
j=json.loads((root/'remotion/src/lyrics.json').read_text())
assert len(j['lines'])==16
for i,line in enumerate(j['lines']):
 assert ' '.join(c['text'] for c in j['cues'] if c['line']==i)==line
assert any('peri qué' in c['text'] for c in j['cues'])
assert any('amazing mechanics' in c['text'] for c in j['cues'])
for name in ['illojuan-sticker.png','xokas-sticker.png']:
 p=root/'remotion/public/assets'/name
 assert p.is_file() and p.stat().st_size>0
 # Decode the complete PNG with the installed production media tool.
 subprocess.run(['ffmpeg','-v','error','-i',str(p),'-frames:v','1','-f','null','-'],check=True)
report={'transcript_lines':16,'transcript_preservation':'passed','cameo_assets_decode':'passed','word_timing':'editorial; not manually verified','references':'user-supplied; external research blocked','original_clips_used':False}
(root/'out/V2_source_checks.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
