from pathlib import Path
import subprocess,json
import numpy as np
from PIL import Image,ImageDraw

root=Path(__file__).resolve().parents[1]
out=root/'out';video=out/'CHEKI_Reality_V4.mp4'
def run(args):
    subprocess.run(['ffmpeg','-v','error','-y']+args,check=True)

times=[1.5,2.65,4.3,7.85,9.9,12.7,15.7,17.2,20.7,23.55,25.5,27.85,31.15,33.5,36,42.4]
canvas=Image.new('RGB',(1080,2040),'#10151e')
for i,t in enumerate(times):
    p=out/f'V4_review_{i:02d}.jpg'
    run(['-ss',str(t),'-i',str(video),'-frames:v','1','-q:v','2',str(p)])
    im=Image.open(p);im.thumbnail((270,480));x=i%4*270;y=i//4*510
    canvas.paste(im,(x,y+25));ImageDraw.Draw(canvas).text((x+10,y+7),str(t)+' s',fill='white')
canvas.save(out/'V4_contact.jpg',quality=93)

for name,start,duration in [('CHEKI_V4_Proof',0,6),('CHEKI_V4_Supermercado',23.78,8)]:
    run(['-ss',str(start),'-i',str(video),'-t',str(duration),'-c:v','libx264','-preset','fast','-crf','23','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out/(name+'.mp4'))])

raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(video),'-an','-vf','scale=108:192','-pix_fmt','gray','-f','rawvideo','-'])
frames=np.frombuffer(raw,dtype=np.uint8).reshape((-1,192,108)).astype(np.float32)
brightness=frames.mean(axis=(1,2));differences=np.abs(np.diff(frames,axis=0)).mean(axis=(1,2))
longest=streak=0
for d in differences:
    streak=streak+1 if d<.01 else 0
    longest=max(longest,streak)
result={'frames_analyzed':len(frames),'analysis_resolution':[108,192],'dark_frames_under_mean_4':int((brightness<4).sum()),'minimum_mean_luma':float(brightness.min()),'minimum_adjacent_frame_difference':float(differences.min()),'longest_near_identical_run_frames':longest,'contact_sheet_seconds':times,'review':'Selected frames visually reviewed; this does not verify word-level vocal synchronization.'}
assert len(frames)==1287
assert result['dark_frames_under_mean_4']==0
assert longest<30
(out/'V4_frame_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
