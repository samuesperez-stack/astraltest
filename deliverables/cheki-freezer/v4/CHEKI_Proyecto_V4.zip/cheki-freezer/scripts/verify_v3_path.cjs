const fs=require('fs');const path=require('path');
const root=path.resolve(__dirname,'..');const req=require('module').createRequire(path.join(root,'remotion/package.json'));
const ts=req('typescript'),T=req('three');const source=fs.readFileSync(path.join(root,'remotion/src/v3/path.ts'),'utf8');const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const out={};new Function('require','exports',compiled)(req,out);
let previous=null,previousQuat=null,maxStep=0,maxTurn=0,minY=99,maxX=0,maxForwardStep=-99;
for(let f=0;f<1287;f++){
 const v=out.pose(f/30);if(![...v.p.toArray(),...v.q.toArray(),v.roll].every(Number.isFinite))throw Error('Non-finite camera pose');
 const cam=new T.PerspectiveCamera();cam.position.copy(v.p);cam.lookAt(v.q);cam.rotateZ(v.roll);
 if(previous){maxStep=Math.max(maxStep,v.p.distanceTo(previous));maxForwardStep=Math.max(maxForwardStep,v.p.z-previous.z);maxTurn=Math.max(maxTurn,previousQuat.angleTo(cam.quaternion));}
 minY=Math.min(minY,v.p.y);maxX=Math.max(maxX,Math.abs(v.p.x));previous=v.p;previousQuat=cam.quaternion.clone();
}
if(maxStep>.25||maxTurn>.075||minY<1||maxX>3.8||maxForwardStep>.001)throw Error('Camera path continuity or clearance failed');
const result={frames:1287,max_world_units_per_frame:maxStep,max_rotation_radians_per_frame:maxTurn,minimum_camera_height:minY,max_absolute_x:maxX,monotonic_forward_path:maxForwardStep<=.001,continuous_camera:'passed',note:'Numerical camera continuity/clearance check, not an audio or aesthetic approval.'};
fs.writeFileSync(path.join(root,'out/V3_camera_checks.json'),JSON.stringify(result,null,2));console.log(result);
