from pathlib import Path
import subprocess,json
import numpy as np
root=Path(__file__).resolve().parents[1]
p=root/'out/CHEKI_OneTake_V3.mp4'
b=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-an','-vf','scale=64:114','-pix_fmt','rgb24','-f','rawvideo','-'])
a=np.frombuffer(b,dtype=np.uint8).reshape(-1,114,64,3)
assert len(a)==1287
means=a.mean(axis=(1,2,3));assert float(means[6:1280].min())>1,'Unexpected black frame in the continuous shot'
d=np.abs(a[1:].astype(np.float32)-a[:-1].astype(np.float32)).mean(axis=(1,2,3))
run=best=0
for v in d[6:1280]:
 run=run+1 if v<.01 else 0;best=max(best,run)
assert best<4,'Unexpected frozen frame run'
report={'frames_checked':len(a),'minimum_mean_RGB_excluding_fades':float(means[6:1280].min()),'maximum_near_identical_frame_run':best,'mean_adjacent_frame_difference':float(d.mean()),'decoded_frame_motion':'passed','note':'Low-resolution frame coverage/motion check; does not certify visual taste or vocal timing.'}
(root/'out/V3_frame_checks.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
