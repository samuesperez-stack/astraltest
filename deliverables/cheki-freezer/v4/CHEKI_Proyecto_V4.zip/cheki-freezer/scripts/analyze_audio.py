from pathlib import Path
import json, subprocess
import numpy as np
root=Path(__file__).resolve().parents[1]
b=subprocess.check_output(['ffmpeg','-v','error','-i',str(root/'audio/cheki-fragment.mp3'),'-ac','1','-ar','22050','-f','f32le','-'])
x=np.frombuffer(b,dtype='<f4'); sr=22050
energies=[]; bass=[]
for f in range(1287):
 a=x[int(f*sr/30):int((f+1)*sr/30)]
 energies.append(float(np.sqrt(np.mean(a*a))) if len(a) else 0)
 spec=np.abs(np.fft.rfft(a*np.hanning(len(a)),n=2048))
 bass.append(float(np.mean(spec[3:18])))
e=np.array(energies); e/=max(np.percentile(e,95),1e-8)
b=np.array(bass); onset=np.maximum(b-np.roll(b,2),0); onset[0:2]=0
onset/=max(np.percentile(onset,93),1e-8)
pulse=[]; last=0
for v in onset:
 last=max(min(v,1),last*.66); pulse.append(round(last,4))
# Select strong actual musical transients near art-directed scene boundaries.
nominal=[0,2.7,5.8,8.6,11.4,14.6,17.3,20.4,23.2,26.2,29,32,35,38,40.8]
cuts=[0]
for sec in nominal[1:]:
 center=round(sec*30); lo=max(cuts[-1]+45,center-10); hi=min(1250,center+11)
 cuts.append(int(lo+np.argmax(onset[lo:hi])))
data={'fps':30,'durationInFrames':1287,'cuts':cuts,'energy':[round(float(min(v,1.4)),4) for v in e],'pulse':pulse,'note':'Energy/onset features from original audio, not lyric alignment.'}
(root/'remotion/src/audio-features.json').write_text(json.dumps(data))
(root/'docs/SCENE_CUTS.json').write_text(json.dumps([{'scene':i+1,'in':round(c/30,3),'out':round((cuts[i+1] if i+1<len(cuts) else 1287)/30,3)} for i,c in enumerate(cuts)],indent=2))
print('cuts',cuts)
