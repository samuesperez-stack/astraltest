from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
lines=[
'Me piden dieciséis barras, eso significa barro',
'Mi lefa será tu ungüento, te lo cuento, te lo narro (¿cómo?)',
'Los versos los despilfarro (¿eh?), yo tengo agarre',
'Traigo barras que son garras, pizarras sobre aquelarres',
'Sí, y así fue tu clásico deceso',
'Sentado contemplativo, un perifrástico proceso (¿un peri qué?)',
'Superlativo, heterobásico, confeso',
'Mi vida contemplativa ha sido un trágico suceso',
'Cuando yo hable, seduzco al noble, reduzco al roble',
'Y como un chino produzco el doble (chin, chon)',
'Con precisión te dejo inválido en el duelo',
'Quince años sin rimar y mira qué rápido vuelo (uh, uh)',
'No visto flama, ni tampoco Karl Kani',
'Pero ahora tengo la fama y las amazing mechanics',
'Pues vine con Spok, con el Juanito y con Sceno',
'Y es que el disco de Los Diozes es mejor porque yo sueno'
]
# Editorial timings, not verified forced alignment. Keep explicit provenance.
starts=[.38,2.93,5.64,8.18,10.95,13.28,16.12,18.25,21.14,23.78,26.40,29.00,31.78,34.23,36.92,39.61,42.72]
cues=[]; words=[]
for i,line in enumerate(lines):
 tokens=line.split(); weights=[max(1,len(re.sub(r'[^\wáéíóúñ]','',w)))**.65 for w in tokens]; total=sum(weights); t=starts[i]
 # Small inter-bar gap; grouping never changes supplied wording.
 end=starts[i+1]-.07; duration=end-t
 for j,(w,weight) in enumerate(zip(tokens,weights)):
  stop=t+duration*weight/total
  words.append({'word':w,'start':round(t,3),'end':round(stop,3),'line':i})
  t=stop
 linewords=[w for w in words if w['line']==i]
 groups=[linewords[j:j+4] for j in range(0,len(linewords),4)]
 # Avoid a lone final word when possible.
 if len(groups)>1 and len(groups[-1])==1:
  last=groups.pop(); groups[-1].extend(last)
 for g in groups:cues.append({'text':' '.join(w['word'] for w in g),'start':g[0]['start'],'end':g[-1]['end'],'line':i,'words':g})
data={'source':'Exact transcript supplied by user. Editorial timing estimated; listening/forced alignment NOT verified.','lines':lines,'cues':cues}
(root/'remotion/src/lyrics.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
(root/'docs/LYRICS.md').write_text('# Letra aportada por el usuario\n\n'+'\n\n'.join(lines)+'\n\nLos tiempos actuales son una propuesta editorial; no se ha verificado sincronía palabra por palabra.\n')
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(root/'out/CHEKI_lyrics_provisional.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"]}' for i,c in enumerate(cues)))
