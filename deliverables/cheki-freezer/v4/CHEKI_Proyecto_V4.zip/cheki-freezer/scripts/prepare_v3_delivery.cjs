const fs=require('fs'),path=require('path'),cp=require('child_process');
const out=path.resolve(__dirname,'../out'),video=path.join(out,'CHEKI_OneTake_V3.mp4'),limit=95*1024*1024;
if(!fs.existsSync(video))throw Error('Render V3 before preparing delivery');
if(fs.statSync(video).size<=limit){const r={master:null,delivery:path.basename(video),delivery_bytes:fs.statSync(video).size,delivery_crf:22,resolution:'1080x1920',fps:30,audio:'original Remotion AAC',note:'Native render already fits the delivery limit; no additional encoding.'};fs.writeFileSync(path.join(out,'V3_delivery_encoding.json'),JSON.stringify(r,null,2));console.log(r);process.exit(0);}
let master=path.join(out,'CHEKI_OneTake_V3_Master.mp4'),i=1;
while(fs.existsSync(master))master=path.join(out,`CHEKI_OneTake_V3_Master_${i++}.mp4`);
let temporary=path.join(out,'CHEKI_OneTake_V3_delivery.tmp.mp4');
if(fs.existsSync(temporary))throw Error('A previous delivery temp file exists; preserve/check it before retrying');
fs.renameSync(video,master);
let crf=25;
try{
 for(const candidate of [25,27]){
  crf=candidate;const result=cp.spawnSync('ffmpeg',['-hide_banner','-nostats','-i',master,'-c:v','libx264','-preset','medium','-crf',String(crf),'-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',temporary],{stdio:'inherit'});
  if(result.status!==0)throw Error('Delivery encoding failed');
  if(fs.statSync(temporary).size<=limit)break;
  if(candidate===27)throw Error('Delivery still exceeds the limit; master preserved');
  fs.unlinkSync(temporary);
 }
 fs.renameSync(temporary,video);
 const report={master:path.basename(master),master_bytes:fs.statSync(master).size,delivery:path.basename(video),delivery_bytes:fs.statSync(video).size,delivery_crf:crf,resolution:'1080x1920',fps:30,audio:'stream copied without re-encoding',note:'Master preserved; delivery uses additional H264 compression to fit GitHub.'};
 fs.writeFileSync(path.join(out,'V3_delivery_encoding.json'),JSON.stringify(report,null,2));console.log(report);
}catch(e){if(!fs.existsSync(video))fs.copyFileSync(master,video);throw e;}
