from pathlib import Path
import json, hashlib, urllib.request
from PIL import Image

root=Path(__file__).resolve().parents[1]
dest=root/'remotion/public/assets/v4'
originals=dest/'originals'
def cut(src,name,box=None):
    im=Image.open(originals/(src+'.png')).convert('RGBA')
    if box: im=im.crop(box)
    a=im.getchannel('A').point(lambda x: 0 if x<12 else x)
    im.putalpha(a)
    bounds=a.point(lambda x:255 if x>90 else 0).getbbox()
    if bounds: im=im.crop(bounds)
    im.save(dest/(name+'.png'),optimize=True)

for name in ['room','classroom','bureau','supermarket','theatre','control','finalstage']:
    Image.open(originals/(name+'.png')).convert('RGB').save(dest/(name+'.jpg'),quality=94)
for i,name in enumerate(['xokas-talk','xokas-react','xokas-win']):
    cut('actor',name,(i*724,0,(i+1)*724,724))
for name,box in [('xokas-compress',(0,0,744,765)),('xokas-tube',(744,0,1380,765)),('xokas-fly',(1380,0,2056,765))]:
    cut('actorActions',name,box)
cut('reaction','illojuan')
for i,name in enumerate(['tube','bonsai','hand','claw','paper','mud']):
    x=(i%2)*512;y=(i//2)*512
    cut('props',name,(x,y,x+512,y+512))
for i,name in enumerate(['noodles','oil','rice','cereal','can','milk']):
    x=(i%2)*512;y=(i//2)*512
    cut('groceries',name,(x,y,x+512,y+512))
for name,box in [('bars',(0,0,650,455)),('metal-claw',(650,0,1312,475)),('noble',(0,455,490,1199)),('oak',(490,475,1312,1199))]:
    cut('transitionProps',name,box)
cut('ointment','cream-ribbon')

fonts=root/'remotion/public/fonts'
for name,folder,file in [('BebasNeue','ofl/bebasneue','BebasNeue-Regular.ttf'),('Anton','ofl/anton','Anton-Regular.ttf'),('IBMPlexMono','ofl/ibmplexmono','IBMPlexMono-Regular.ttf')]:
    for target,remote in [(name+'.ttf',file),(name+'_OFL.txt','OFL.txt')]:
        out=fonts/target
        if not out.exists():
            url='https://raw.githubusercontent.com/google/fonts/main/'+folder+'/'+remote
            with urllib.request.urlopen(url,timeout=45) as response: out.write_bytes(response.read())
        if target.endswith('.ttf'): assert out.read_bytes()[:4] in [b'\x00\x01\x00\x00',b'OTTO']

manifest=[{'file':str(p.relative_to(dest)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(dest.glob('*')) if p.is_file() and p.suffix in ['.png','.jpg']]
(dest/'processed-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('V4 assets ready:',len(manifest))
