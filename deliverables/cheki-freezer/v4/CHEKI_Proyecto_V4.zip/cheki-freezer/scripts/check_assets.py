from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]
required=['audio/cheki-fragment.mp3','remotion/public/cheki-fragment.mp3','remotion/public/assets/freezer-tunnel.png','remotion/public/assets/performer.png','remotion/public/assets/hero-ice.png','remotion/public/assets/can.png','remotion/public/fonts/Marker.ttf','remotion/src/lyrics.json','remotion/src/audio-features.json']
for rel in required:
 p=root/rel
 assert p.is_file() and p.stat().st_size>0,rel
 print(rel,p.stat().st_size)
a=root/required[0];b=root/required[1]
assert hashlib.sha256(a.read_bytes()).digest()==hashlib.sha256(b.read_bytes()).digest()
assert hashlib.sha256(a.read_bytes()).hexdigest()=='4c60727cbd16fc1946902781c5446f848e73335cad8b2c5e9c2cb67d47fc1d6d'
subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1',str(a)],check=True)
j=json.loads((root/'remotion/src/lyrics.json').read_text())
for i,line in enumerate(j['lines']):assert ' '.join(c['text'] for c in j['cues'] if c['line']==i)==line
assert all(0<=c['start']<c['end']<=42.893061 for c in j['cues'])
print('Audio checksum and 16 exact lyric lines: passed. Cue times remain editorial.')
