# CHEKI — Freezer V2

Videolyric vertical de 42,9 segundos, 1080×1920 a 30 fps, construido en Remotion a partir del MP3, el storyboard y la letra aportados por el usuario.

## Entregas actuales
- `out/CHEKI_Freezer_V2.mp4`: montaje V2 completo con efectos tipográficos y cameos ilustrados.
- `out/CHEKI_V2_Perique_Proof.mp4`: prueba de seis segundos del tramo 13–19 s.
- `out/CHEKI_Freezer_V2_verification.json`: comprobaciones técnicas de V2.
- `out/CHEKI_lyrics_provisional.srt`: subtítulos con tiempos editoriales.

V1 se conserva como `out/CHEKI_Freezer_Final.mp4` y en la composición `ChekiFreezer`; V2 usa `ChekiFreezerV2`.

**Los tiempos de la letra siguen siendo provisionales.** El texto reproduce las 16 líneas aportadas por el usuario; la alineación palabra por palabra no se ha verificado a oído. Los cameos de IlloJuan y Xokas son ilustraciones generadas, no clips reales. El meme se recrea visualmente con el texto solicitado; no se ha verificado su autoría. Véanse `docs/V2_CHANGES.md` y `docs/REFERENCES_V2.md`.

## Iniciar y renderizar
Requisitos: Node 24, npm, FFmpeg, Chromium. En este entorno:
```bash
cd /workspace/cheki-freezer/remotion
npm_config_cache=/workspace/.npm npm ci --no-audit --no-fund
npm run studio
```
Studio utiliza el puerto 3100. Para compilar o exportar:
```bash
npm run typecheck
npm run build
npm run render:v2proof
npm run render
# Para reproducir V1: npm run render:v1
```
Los scripts apuntan a `/usr/bin/chromium`; ajustarlo si se usa otra máquina. No se necesitan claves ni servicios externos durante el render: las imágenes, fuentes, letra y audio están incluidos.

## Diseño y edición
- `remotion/src/video.tsx`: escenas, capas, cámara, grietas, vapor y partículas.
- `remotion/src/v2/kinetic.tsx`: volumen, impactos y fragmentos de letra.
- `remotion/src/v2/references.tsx`: cameos, meme de codificación y tarjetas referenciales.
- `remotion/src/video-v1.tsx`: montaje anterior conservado.
- `remotion/src/lyrics.json`: texto y cues editables, con tiempos en segundos.
- `remotion/src/audio-features.json`: energía e impactos extraídos del audio.
- `docs/SCENE_CUTS.json`: cortes de las 15 escenas.
- `remotion/public/assets`: recursos fotográficos generados con IA y transparencias.
- `remotion/public/fonts`: fuentes locales con sus licencias.

El ambiente, personaje y objetos se componen por separado; no se usan crops del storyboard como secuencias terminadas. La animación es 2.5D, con geometría CSS 3D y efectos procedurales; no es filmación real ni actuación con sincronía labial.

## Herramientas auxiliares
Los JSON ya están incluidos: Python no es necesario para iniciar o renderizar. Para regenerar análisis/cues o verificar el MP4:
```bash
cd /workspace/cheki-freezer
python -m venv .venv
.venv/bin/pip install numpy
.venv/bin/python scripts/analyze_audio.py
.venv/bin/python scripts/build_lyrics.py
.venv/bin/python scripts/verify_video.py
```
El script de letra contiene tiempos editoriales explícitos; no es un alineador acústico. Los dominios de modelos de reconocimiento están bloqueados en la instancia actual; cualquier requisito guardado en los ajustes sigue pendiente de aplicación. No se descargaron ni utilizaron modelos sin verificar.

`MANIFEST.json` es el inventario histórico suministrado, no el de esta reconstrucción. El prototipo original y sus renders/crops no estaban adjuntos. Véase `docs/ASSET_PROVENANCE.md`.
