# CHEKI — Freezer

Videolyric vertical de 42,9 segundos, 1080×1920 a 30 fps, construido en Remotion a partir del MP3, el storyboard y la letra aportados por el usuario.

## Entregas
- `out/CHEKI_Freezer_Final.mp4`: montaje completo con audio, 15 escenas y letra.
- `out/CHEKI_Freezer_Proof.mp4`: primeros seis segundos para revisión.
- `out/CHEKI_lyrics_provisional.srt`: subtítulos con tiempos editoriales.
- `out/verification.json`: comprobaciones técnicas del render.

**Los tiempos de la letra son provisionales.** El texto reproduce las 16 líneas aportadas por el usuario; la alineación palabra por palabra no se ha verificado a oído. El nombre del archivo final identifica el montaje exportado, no una aprobación de esa sincronización.

## Iniciar y renderizar
Requisitos: Node 24, npm, FFmpeg, Chromium. En este entorno:
```bash
cd /workspace/cheki-freezer/remotion
npm_config_cache=/workspace/.npm npm ci --no-audit --no-fund
npm run studio
```
Studio utiliza el puerto 3100. Para compilar o exportar:
```bash
npm run typecheck
npm run build
npm run render:proof
npm run render
```
Los scripts apuntan a `/usr/bin/chromium`; ajustarlo si se usa otra máquina. No se necesitan claves ni servicios externos durante el render: las imágenes, fuentes, letra y audio están incluidos.

## Diseño y edición
- `remotion/src/video.tsx`: escenas, capas, cámara, grietas, vapor, partículas y tipografía.
- `remotion/src/lyrics.json`: texto y cues editables, con tiempos en segundos.
- `remotion/src/audio-features.json`: energía e impactos extraídos del audio.
- `docs/SCENE_CUTS.json`: cortes de las 15 escenas.
- `remotion/public/assets`: recursos fotográficos generados con IA y transparencias.
- `remotion/public/fonts`: fuentes locales con sus licencias.

El ambiente, personaje y objetos se componen por separado; no se usan crops del storyboard como secuencias terminadas. La animación es 2.5D, con geometría CSS 3D y efectos procedurales; no es filmación real ni actuación con sincronía labial.

## Herramientas auxiliares
Los JSON ya están incluidos: Python no es necesario para iniciar o renderizar. Para regenerar análisis/cues o verificar el MP4:
```bash
cd /workspace/cheki-freezer
python -m venv .venv
.venv/bin/pip install numpy
.venv/bin/python scripts/analyze_audio.py
.venv/bin/python scripts/build_lyrics.py
.venv/bin/python scripts/verify_video.py
```
El script de letra contiene tiempos editoriales explícitos; no es un alineador acústico. Los dominios de modelos de reconocimiento están bloqueados en la instancia actual; cualquier requisito guardado en los ajustes sigue pendiente de aplicación. No se descargaron ni utilizaron modelos sin verificar.

`MANIFEST.json` es el inventario histórico suministrado, no el de esta reconstrucción. El prototipo original y sus renders/crops no estaban adjuntos. Véase `docs/ASSET_PROVENANCE.md`.
