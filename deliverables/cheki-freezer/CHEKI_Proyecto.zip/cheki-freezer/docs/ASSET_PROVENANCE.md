# Procedencia de recursos

- `audio/cheki-fragment.mp3`: adjuntado por usuario en esta conversación; licencia/publicación no verificada. Usarlo en el proyecto privado de revisión; distribución comercial sujeta a derechos.
- `remotion/`: código prototipo generado previamente para el usuario, sin prueba de render satisfactoria en el entorno anterior.
- `references/storyboards/`: imágenes generadas por IA durante desarrollo conversacional de la estética. No son portadas oficiales ni fotogramas originales del videoclip. Contienen texto horneado e inconsistencias.
- `references/scene-crops/`: recortes de storyboard para referencia únicamente. NO assets listos para composición por capas.
- `references/previous-renders/`: MP4 de revisión producido anteriormente con FFmpeg; usuario indicó que se alejaba del storyboard. Se incluye como comparación histórica, no como resultado aprobado.
- Referencia externa oficial indicada por usuario: https://www.youtube.com/watch?v=-FysjrauFxY (no descargada).

## Base reconstruida en este entorno
- `remotion/src/`: código nuevo generado para preparar y verificar la herramienta de desarrollo. Geometría SVG y efectos CSS procedurales; sin fotogramas oficiales, fotografías de terceros ni crops del storyboard.
- El prototipo original, los crops y los renders históricos enumerados en el manifiesto no fueron entregados entre los archivos adjuntos.
- La prueba técnica usa los primeros seis segundos del MP3 original, sin transcribir ni inferir letras.

## Producción del montaje completo
- `assets/freezer-tunnel.png`: imagen nueva generada con image_gen; pasillo de congeladores sin texto ni personas.
- `assets/performer.png`: personaje adulto ficticio generado con image_gen, recorte RGBA independiente. No representa al artista real ni reproduce fotogramas del videoclip.
- `assets/hero-ice.png`: bloque de hielo generado con image_gen, recorte RGBA independiente.
- `assets/can.png`: lata ficticia generada con image_gen, recorte RGBA independiente; sin marcas comerciales.
- Geometría, cámara, partículas, niebla, gotas y grietas: animación procedural determinista en el código Remotion.
- Letra: transcripción proporcionada directamente por el usuario en esta conversación. Cue timing editorial no validado a oído.
- `Marker.ttf`: Permanent Marker, Google Fonts, licencia Apache 2.0 incluida como `MARKER_LICENSE.txt`. Fuente obtenida de https://raw.githubusercontent.com/google/fonts/main/apache/permanentmarker/PermanentMarker-Regular.ttf.
- `Title.ttf`: DejaVu Sans Condensed Bold Oblique; licencia incluida como `LICENSE.txt`. El montaje usa principalmente Permanent Marker y monospace del sistema.
