import React from "react";
import { Composition } from "remotion";
import { Freezer } from "./video";
export const Root: React.FC = () => (
  <>
    <Composition
      id="FreezerProof"
      component={Freezer}
      durationInFrames={180}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="ChekiFreezer"
      component={Freezer}
      durationInFrames={1287}
      fps={30}
      width={1080}
      height={1920}
    />
  </>
);
