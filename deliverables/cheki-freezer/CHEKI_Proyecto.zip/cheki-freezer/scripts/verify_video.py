from pathlib import Path
import json,subprocess,re
import numpy as np
root=Path(__file__).resolve().parents[1]
p=root/'out/CHEKI_Freezer_Final.mp4'
r=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
v=next(s for s in r['streams'] if s['codec_type']=='video'); a=next(s for s in r['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1080,1920)
assert v['r_frame_rate']=='30/1'
assert int(v['nb_frames'])==1287
assert abs(float(r['format']['duration'])-42.893061)<1/30
assert v['codec_name']=='h264' and a['codec_name']=='aac'
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
def pcm(path,channels=1):
 return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac',str(channels),'-ar','8000','-f','f32le','-']),dtype='<f4')
x=pcm(root/'audio/cheki-fragment.mp3'); y=pcm(p); n=min(len(x),len(y)); x=x[:n];y=y[:n]
correlation=float(np.corrcoef(x,y)[0,1]);assert correlation>.95,correlation
stereo_peak=float(np.max(np.abs(pcm(p,channels=2))));assert stereo_peak<1,stereo_peak
measurement=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(p),'-vn','-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True,check=True)
true_peak=float(re.search(r'True peak:\s+Peak:\s+(-?[0-9.]+) dBFS',measurement.stderr).group(1));assert true_peak<0,true_peak
# High correlation at zero lag verifies preservation of source audio timing,
# not alignment of typography with vocal phonemes.
result={'video':{'codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':int(v['nb_frames'])},'audio':{'codec':a['codec_name'],'source_output_zero_lag_correlation':correlation,'decoded_stereo_peak':stereo_peak,'true_peak_dbfs':true_peak},'duration':float(r['format']['duration']),'decode':'passed','lyrics':'Exact user text preserved; editorial cue times not manually verified against voice.'}
(root/'out/verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
j=json.load(open(root/'remotion/src/lyrics.json'))
for i,line in enumerate(j['lines']):assert ' '.join(c['text'] for c in j['cues'] if c['line']==i)==line
print('All 16 lyric lines preserved exactly.')
