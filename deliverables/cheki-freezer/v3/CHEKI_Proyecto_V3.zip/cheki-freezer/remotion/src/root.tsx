import React from "react";
import { OneTakeV3 } from "./v3/world";
import { Composition } from "remotion";
import { Freezer } from "./video";
import { Freezer as FreezerV1 } from "./video-v1";
export const Root: React.FC = () => (
  <>
    <Composition
      id="FreezerProof"
      component={Freezer}
      durationInFrames={180}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="ChekiFreezer"
      component={FreezerV1}
      durationInFrames={1287}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="ChekiFreezerV2"
      component={Freezer}
      durationInFrames={1287}
      fps={30}
      width={1080}
      height={1920}
    />
    <Composition
      id="ChekiOneTakeV3"
      component={OneTakeV3}
      durationInFrames={1287}
      fps={30}
      width={1080}
      height={1920}
    />
  </>
);
