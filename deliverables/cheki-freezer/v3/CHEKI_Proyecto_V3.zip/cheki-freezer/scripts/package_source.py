from pathlib import Path
import hashlib,json,zipfile,shutil,sys
root=Path(__file__).resolve().parents[1]
edition='v3' if '--v3' in sys.argv else 'v2' if '--v2' in sys.argv else 'v1'
files=[]
for p in sorted(root.rglob('*')):
 rel=p.relative_to(root)
 if not p.is_file() or any(x in rel.parts for x in ['node_modules','build','out','.venv','tools','__pycache__']):continue
 if p.name=='MANIFEST.current.json':continue
 files.append(p)
manifest=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
m=root/'MANIFEST.current.json';m.write_text(json.dumps(manifest,indent=2,ensure_ascii=False));files.append(m)
suffix='' if edition=='v1' else '-'+edition
archive=root.parent/('cheki-freezer-production'+suffix+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,Path('cheki-freezer')/p.relative_to(root))
 for name in ['verification.json','CHEKI_Freezer_V2_verification.json','CHEKI_OneTake_V3_verification.json','V2_source_checks.json','V3_camera_checks.json','V3_frame_checks.json','V3_text_cues_check.json','V3_delivery_encoding.json','CHEKI_lyrics_provisional.srt']:
  p=root/'out'/name
  if p.exists():z.write(p,Path('cheki-freezer')/p.relative_to(root))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
shutil.copy2(archive,root.parent/('cheki-freezer-source'+suffix+'.zip'))
print(str(archive),archive.stat().st_size)
