const {openBrowser}=require('@remotion/renderer');
const fs=require('fs');
(async()=>{
 const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
 try{
 const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
 await page.goto({url:'http://127.0.0.1:3135',timeout:20000,options:{waitUntil:'load'}});
 const svg=await page.evaluate(async()=>{
  for(let i=0;i<60;i++){
   const s=document.querySelector('svg[viewBox="0 0 5000 5000"]');
   if(s)return s.outerHTML;
   await new Promise(r=>setTimeout(r,100));
  }
  return null;
 });
 if(!svg)throw Error('SVG not found');
 fs.writeFileSync('public/toyp-site.svg',svg.replace(/ class="[^"]*"/g,''));
 console.log('SVG saved');
 }finally{await browser.close({silent:true});}
})().catch(e=>{console.error(e.message);process.exit(1)});
