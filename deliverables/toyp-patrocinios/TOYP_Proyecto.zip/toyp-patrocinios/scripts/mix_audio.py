from pathlib import Path
import subprocess,json,wave
import numpy as np
root=Path(__file__).resolve().parents[1];sr=48000
duration=36;n=sr*duration;mix=np.zeros(n,dtype=np.float64)
manifest=json.loads((root/'public/audio/voice-manifest.json').read_text())
for item in manifest:
 p=root/'public/audio'/item['file']
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-af',f"atempo={item['tempo']}",'-ac','1','-ar',str(sr),'-f','f32le','-'])
 a=np.frombuffer(raw,dtype='<f4').astype(float)
 a*=.52/max(abs(a).max(),.001)
 start=round(item['start']*sr);end=min(n,start+len(a));mix[start:end]+=a[:end-start]

rng=np.random.default_rng(2026)
def add(start,a):
 i=round(start*sr);end=min(n,i+len(a));mix[i:end]+=a[:end-i]
def click(start):
 t=np.arange(int(.075*sr))/sr
 a=(rng.normal(0,.6,len(t))+np.sin(2*np.pi*1850*t)*.4)*np.exp(-t*105)*.033
 add(start,a)
for start in [.35,5.12,5.5,5.9,12.08,15.83,19.58,23.33,27.15,31.08]:click(start)
for start in [0,12,27,31]:
 t=np.arange(int(1.6*sr))/sr
 add(start,.035*np.sin(2*np.pi*45*t)*np.sin(np.pi*t/1.6)**2)
for start in [12,15.75,19.5,23.25,27]:
 t=np.arange(int(.22*sr))/sr
 noise=rng.normal(0,1,len(t));noise=np.convolve(noise,np.ones(13)/13,mode='same')
 add(start,noise*np.sin(np.pi*t/.22)**2*.018)
for start,length in [(27,3.8),(31,5)]:
 t=np.arange(int(length*sr))/sr
 chord=sum(np.sin(2*np.pi*f*t) for f in [110,220,329.63,440])*.006
 env=np.minimum(t/.45,1)*np.minimum((length-t)/1.0,1)
 add(start,chord*env)
stereo=np.stack([mix,mix],axis=1)
tmp=root/'out/audio-premix.wav'
with wave.open(str(tmp),'wb') as f:
 f.setparams((2,2,sr,0,'NONE','not compressed'));f.writeframes((np.clip(stereo,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(tmp),'-af','loudnorm=I=-16:TP=-1.2:LRA=7','-ar',str(sr),'-c:a','pcm_s16le',str(root/'public/audio/final-mix.wav')],check=True)
print('36-second voice + original tactile sound design mixed')
