import asyncio,os,ssl,json,subprocess
from pathlib import Path
import edge_tts
import edge_tts.communicate as transport

# Use the environment's trusted system CA store and configured proxy.
# TLS verification remains enabled.
transport._SSL_CTX=ssl.create_default_context()
root=Path(__file__).resolve().parents[1]
segments=[
 (0.35,4.35,'¿Tu marca junto a quienes transforman Venezuela?'),
 (5.2,6.5,'Este veintiocho de noviembre, en Valencia. Transmisión en alta definición y alcance global.'),
 (12.2,3.25,'Aliado Estratégico. Cincuenta dólares.'),
 (15.95,3.25,'Impulsor Comercial. Treinta y cinco dólares.'),
 (19.7,3.25,'Colaborador Digital. Veinticinco dólares.'),
 (23.45,3.25,'Apoyo Institucional. Quince dólares.'),
 (27.2,3.5,'También puedes aportar productos y servicios.'),
 (31.2,4.45,'Asegura tu participación. Escríbenos hoy.'),
]
async def main():
 report=[]
 for i,(start,slot,text) in enumerate(segments):
  p=root/'public/audio'/f'voice-{i}.mp3'
  if not p.exists() or p.stat().st_size<100:
   await edge_tts.Communicate(text,voice='es-VE-SebastianNeural',rate='-12%',proxy=os.environ.get('HTTPS_PROXY'),connect_timeout=20,receive_timeout=40).save(str(p))
  trim=p.with_suffix('.wav')
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(p),'-af','silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.06,areverse,silenceremove=start_periods=1:start_threshold=-50dB:start_silence=0.10,areverse',str(trim)],check=True)
  duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(trim)]))
  # Each recording receives a bounded, pitch-preserving timing adjustment.
  target=min(slot,max(duration,len(text.split())/(132/60)))
  speed=duration/target
  if speed>1.18: raise ValueError(f'Phrase {i} too long: {duration}s')
  report.append({'index':i,'start':start,'slot':slot,'text':text,'file':trim.name,'trimmed_duration':duration,'tempo':speed})
  print(i,round(duration,2),round(speed,3),flush=True)
 (root/'public/audio/voice-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
asyncio.run(main())
