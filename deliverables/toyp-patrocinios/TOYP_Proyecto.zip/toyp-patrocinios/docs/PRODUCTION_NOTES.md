# Decisiones y procedencia

## Cambios aprobados

El usuario confirmó 36 segundos con locución resumida. El guion original y su velocidad de 130–135 palabras/minuto no eran compatibles con la duración. Se conservaron en pantalla todos los precios y los beneficios esenciales de cada nivel; se redujo la narración a frases por escena. El manifiesto de voz contiene la versión efectivamente utilizada.

Timeline a 60 fps: apertura 0–300; alcance 300–720; planes 720–1620 (225 frames por nivel); intercambio 1620–1860; cierre 1860–2160. Las entradas son amortiguadas sin oscilación; no se utiliza aleatoriedad en la animación. El único spotlight es azul JCI, de opacidad reducida; no se incorporan degradados neón o ilustraciones genéricas.

El título de cierre, correo, portal, coordinación, fecha y precios proceden del MD. Los beneficios se abreviaron para lectura móvil, preservando cantidades: 1 categoría, 3×30 s, 2 VIP; 2×15 s y 1 entrada; cortinilla/prensa/menciones y 1 entrada; ceremonia/agradecimientos y 1 entrada. La flexibilidad se muestra para el conjunto de planes como indica el documento.

## Marca

La referencia fue la imagen del usuario. El archivo `Comercial_TOYP.png` no se montó en el entorno: el vector de JCI/TOYP se extrajo del SVG público del sitio indicado en el propio brief. Se mantuvieron sus paths, con un viewBox recortado para eliminar espacio vacío. Bajada y año se componen como texto; el serif elegido es Bodoni Moda. Esto permite revelar marca y año por separado, pero no acredita igualdad píxel por píxel con la imagen adjunta.

Fuentes de identidad:
- https://toyp.jcicarabobo.cc
- Bundle público consultado: https://toyp.jcicarabobo.cc/assets/index-CbODV_7c.js
- `public/toyp-site.svg`: SVG extraído antes del ajuste de viewBox.
- `public/toyp-mark.svg`: paths originales con viewBox ajustado.

`scripts/extract-logo.cjs` es una herramienta de extracción utilizada durante la producción con una copia local temporal del portal. No se necesita para instalar o renderizar el proyecto entregado.

Fuentes tipográficas y licencias SIL OFL incluidas:
- https://raw.githubusercontent.com/google/fonts/main/ofl/plusjakartasans/PlusJakartaSans%5Bwght%5D.ttf
- https://raw.githubusercontent.com/google/fonts/main/ofl/bodonimoda/BodoniModa%5Bopsz,wght%5D.ttf

## Audio

Voz genérica de síntesis en español de Venezuela, Sebastian Neural. No se utilizaron voces o grabaciones de Apple. Archivo de mezcla de 48 kHz estéreo, con normalización loudnorm a -16 LUFS y límite objetivo -1,2 dBTP. Los efectos fueron sintetizados con numpy y una semilla fija, sin samples externos. Los valores efectivos del MP4 se registran en el informe de verificación.

Los textos se sincronizan por bloques con las frases sintetizadas; no se utilizan subtítulos palabra por palabra. La pronunciación del nombre TOYP no es necesaria porque el guion resumido no lo pronuncia. Los datos B2B/B2G se muestran en pantalla y la voz dice «alcance global».

## Validación

Consultar `out/verification.json` para dimensiones, fps, duración, frames, decodificación y medición de audio. Se revisan imágenes de apertura, alcance, los cuatro planes, flexibilidad y cierre. La mezcla y el paquete fuente se entregan junto al proyecto; los registros técnicos no sustituyen la aprobación editorial final del evento.
