# Especificación Técnica de Producción: TOYP Venezuela 2026
**Documento Técnico de Motion Design y Guion Ejecutivo**  
**Dirección Estética:** Apple Special Event / Keynote Spec Sheet + Gabriel Viza Clean Tech  
**Formato:** Vertical 9:16 (1080 x 1920) | 60 FPS | 36 Segundos (2.160 frames)  
**Control de Calidad:** Anti-AI Slop Audit aplicado (cero emojis, tipografía calibrada, diseño sonoro táctil, sin degradados genéricos).

---

## Identidad Visual y Arte Oficial

El video utiliza como pieza angular de apertura y cierre el arte oficial original del evento:

![Lockup Oficial TOYP Venezuela 2026](/C:/Users/GAMEMAX/.gemini/antigravity/brain/547f2629-05d1-4a31-b0c3-92ecd38ae10c/Comercial_TOYP.png)

* **Ruta local del activo para el motor de render:** `Comercial_TOYP.png`
* **Arquitectura del Lockup:**
  * Escudo e isotipo superior: `JCI` con isotipo de protección.
  * Marca central: `TOYP` en trazo geométrico y cortes angulares futuristas.
  * Bajada de categoría: `10 JOVENES SOBRESALIENTES VENEZUELA 2026` en sans-serif extendida.
  * Ancla visual inferior: `2026` en tipografía serif editorial de alto contraste (estilo Didot / Bodoni).
* **Tratamiento de Animación en el Video:**
  * En el segundo 00:00, la marca `TOYP` entra mediante una máscara de revelación vertical suave combinada con un destello especular de 1px que recorre el bisel de las letras.
  * El numeral `2026` en serif se asienta con un micro-resorte de escala (0.97 a 1.00, `damping: 1.0`).

---

## 1. Dirección de Arte: Principios Apple Keynote

El video rechaza plantillas prediseñadas y emula las transiciones de producto de Apple (*Hardware Spec Sheets*):

```
+-------------------------------------------------------------+
| REGLAS DE DISEÑO: APPLE KEYNOTE & BENTO                     |
|                                                             |
| 1. Fondo JCI Deep Navy (#00112C) con foco cenital (#0097D7) |
| 2. Contenedores Bento en cristal azul marino ahumado         |
| 3. Bordes de luz milimétricos (1px solid rgba(0,151,215,0.25))|
| 4. Números tabulares monumentales para las cifras           |
| 5. Cero emojis, cero gradientes violeta/neón                |
+-------------------------------------------------------------+
```

### Paleta Cromática Oficial JCI (Sistema de Azules Institucionales)
El sistema visual abandona cualquier tono genérico y adopta estrictamente la gama de azules oficial de la Junior Chamber International (JCI):

* **Azul JCI Principal (JCI Core Blue):** `#0097D7` (RGB: `0, 151, 215`). Es el azul insignia de la marca. Se aplica en bordes de tarjetas activas, acentos de texto clave, luces de contorno (*rim lights*) y destellos de foco.
* **Azul Noche JCI (Deep Corporate Navy):** `#00112C` a `#0A1946`. Color base del canvas y de los paneles de cristal Bento, generando una atmósfera ejecutiva y de máxima profundidad.
* **Acento JCI Aqua / Cyan:** `#57BCBC` (RGB: `87, 188, 188`). Presente en el arte vectorial original del TOYP. Se utiliza en micro-detalles, barras de progreso y destellos de innovación.
* **Azul Cobalto Profundo:** `#0C2B64`. Aplicado en gradientes sutiles y estados de hover/transición de tarjetas.
* **Blanco Hielo / Luz Estelar:** `#F0F8FF` (con tinte azul frío al 2%). Evita el blanco crudo para fundirse armónicamente con la iluminación azul.
* **Oro Champagne Mate (Acento de Premiación):** `#D4AF37` (reservado únicamente para el badge de "Aliado Estratégico" y detalles del galardón).

### Aplicación en Contenedores Bento y Superficies
* **Superficie de Tarjetas:** Cristal ahumado azul (`rgba(0, 17, 44, 0.65)`), con filtro `backdrop-blur(24px)`.
* **Borde Perimetral:** Trazo milimétrico de luz azul JCI (`1px solid rgba(0, 151, 215, 0.25)`), que se intensifica al 60% (`rgba(0, 151, 215, 0.60)`) cuando entra o se enfoca una tarjeta.
* **Iluminación de Fondo:** Spotlight central radial en `#0097D7` con opacidad difusa al 12% sobre el fondo oscuro `#00112C`.
* **Tipografía Primaria Obligatoria:** **Plus Jakarta Sans** (Variable / Google Fonts).
  * Titulares de impacto: `Plus Jakarta Sans ExtraBold` (800) / `Bold` (700) con tracking ligeramente comprimido (`-0.025em`).
  * Cifras y Precios: `Plus Jakarta Sans Bold` con números tabulares activados (`font-feature-settings: "tnum" on`).
  * Insignias, badges y etiquetas: `Plus Jakarta Sans SemiBold` (600), mayúsculas con `letter-spacing: 0.14em`.
  * Textos secundarios y especificaciones: `Plus Jakarta Sans Medium` (500) / `Regular` (400).
  * Ancla visual de cierre: Se preserva la tipografía serif editorial (Didot / Bodoni) exclusivamente para el año `2026` tal como figura en el lockup oficial.

---

## 2. Perfil y Personalidad de la Voz de IA (Voice Engine Spec)

Configuración recomendada para motores TTS (ElevenLabs, OpenAI Audio o locutor humano):

* **Arquetipo de Voz:** Ejecutivo contemporáneo, reflexivo, sereno y confiable. Emula la cadencia de los videos de producto de Apple.
* **Tono y Registro:** Barítono / Tenor medio, timbre cálido, dicción impecable en español neutro latinoamericano con acento natural corporativo venezolano (sin modismos ni exageraciones).
* **Ritmo y Cadencia:** 
  * Velocidad: 130 a 135 palabras por minuto.
  * Cadencia medida: Pausas deliberadas de 400ms a 600ms en comas y transiciones de pantalla para permitir asimilar los datos.
  * Entonación descendente y asertiva al final de cada frase.
* **Guía Fonética Obligatoria:**
  * **TOYP:** Pronunciar como acrónimo fluido: "Toip" (o con pausas rítmicas: "T - O - Y - P").
  * **JCI:** Pronunciar con separación nítida: "Jota - Ce - I".
  * **B2B / B2G:** Pronunciar: "B dos B y B dos G" (o "negocios a negocios y gobierno").
  * **Streaming HD:** Pronunciación limpia: "Streaming H - D".

---

## 3. Storyboard Técnico (36 Segundos | 2.160 Frames a 60 FPS)

```
00s             05s                 12s                            27s            31s          36s
 [--------------]-------------------[------------------------------]--------------[------------]
    ESCENA 1           ESCENA 2                   ESCENA 3                ESCENA 4      ESCENA 5
  Hook & Lockup    Métricas & Alcance         Los 4 Planes (Bento)      Flexibilidad   Cierre & CTA
```

### Escena 1: Apertura de Autoridad con Lockup Oficial (00:00 - 00:05 | Frames 0 - 300)
* **Visual:** Fondo negro absoluto. El lockup completo `Comercial_TOYP.png` se revela centrado, con un barrido de luz suave sobre el isotipo y el "2026" en serif. Avance de cámara milimétrico (*push-in* de escala 0.98 a 1.02).
* **Texto Complementario:**
  * `JCI VENEZUELA PRESENTA`
  * `Valencia, Venezuela | 28 de Noviembre de 2026`
* **Locución:** "¿Tu marca junto a los líderes que están transformando a Venezuela?"
* **SFX:** Sub-bass swell de baja frecuencia (45Hz) + click táctil metálico.

---

### Escena 2: La Vitrina de Impacto (00:05 - 00:12 | Frames 300 - 720)
* **Visual:** Despliegue de cuadrícula Bento compuesta por tres módulos horizontales con física de resorte (*damping: 1.0*):
  * **Módulo A:** `TRANSMISION OFICIAL HD` | Alcance masivo multicanal (YouTube e Instagram Live).
  * **Módulo B:** `RED GLOBAL JCI` | Presencia y difusión en más de 100 países.
  * **Módulo C:** `NETWORKING EJECUTIVO` | Conexión directa B2B y B2G con líderes empresariales y gremiales.
* **Titular Superior:** **Exposición multicanal de alto rendimiento.**
* **Locución:** "Este 28 de noviembre en Valencia, llega el programa de liderazgo juvenil de mayor prestigio global. Transmisión en vivo en alta definición y alcance directo a más de 100 países."
* **SFX:** Tres clicks mecánicos secos al encajar cada módulo de la cuadrícula.

---

### Escena 3: Exhibición de Planes de Patrocinio (00:12 - 00:27 | Frames 720 - 1620)
*Secuencia de tarjetas en cascada. Cada paquete se presenta como una especificación de producto:*

#### 3.1 Aliado Estratégico (Frames 720 - 945 | 3.75s)
* **Insignia:** `NIVEL EXCLUSIVO`
* **Nombre:** **Aliado Estratégico**
* **Inversión:** **$50** *(Disponible a intercambio comercial)*
* **Especificaciones:**
  * [+] Apadrinamiento oficial de 1 de las 10 categorías de premiación
  * [+] 3 Spots comerciales de 30 segundos en streaming HD
  * [+] Espacio exclusivo para activación de marca en el recinto
  * [+] Entrega de galardón en tarima principal + 2 Pases VIP

#### 3.2 Impulsor Comercial (Frames 945 - 1170 | 3.75s)
* **Insignia:** `ALTO RETORNO`
* **Nombre:** **Impulsor Comercial**
* **Inversión:** **$35**
* **Especificaciones:**
  * [+] 2 Spots comerciales de 15 segundos en streaming
  * [+] Espacio asignado para presencia publicitaria
  * [+] Proyección de logotipo e historia de impacto + 1 Entrada

#### 3.3 Colaborador Digital (Frames 1170 - 1395 | 3.75s)
* **Insignia:** `COBERTURA DIGITAL`
* **Nombre:** **Colaborador Digital**
* **Inversión:** **$25**
* **Especificaciones:**
  * [+] Logotipo en la cortinilla oficial de transmisión
  * [+] Menciones de marca en vivo y cobertura en notas de prensa
  * [+] 1 Entrada al evento

#### 3.4 Apoyo Institucional (Frames 1395 - 1620 | 3.75s)
* **Insignia:** `RESPALDO GREMIAL`
* **Nombre:** **Apoyo Institucional**
* **Inversión:** **$15**
* **Especificaciones:**
  * [+] Mención oficial y proyección de logo en la ceremonia
  * [+] Inclusión formal en la lista final de agradecimientos
  * [+] 1 Entrada al evento

* **Locución:** "Posiciona a tu empresa con cuatro niveles diseñados a medida: Aliado Estratégico, Impulsor Comercial, Colaborador Digital y Apoyo Institucional. Opciones desde 15 dólares con presencia en streaming y activación presencial."
* **SFX:** Ticks mecánicos y sutil barrido de frecuencia al alternar tarjetas.

---

### Escena 4: Flexibilidad de Negociación (00:27 - 00:31 | Frames 1620 - 1860)
* **Visual:** Las tarjetas se minimizan hacia una barra central de cristal oscuro con iluminación perimetral azul:
* **Etiqueta:** `MODALIDAD DE ALIANZA`
* **Texto Central:** **Planes negociables a intercambio comercial y de servicios.**
* **Texto Secundario:** Impulso real al desarrollo, ciencia y empresa venezolana.
* **Locución:** "Y con absoluta flexibilidad: planes negociables a intercambio de productos y servicios."
* **SFX:** Acorde acústico limpio de sintetizador analógico.

---

### Escena 5: Cierre & Llamado a la Acción (00:31 - 00:36 | Frames 1860 - 2160)
* **Visual:** Cuadro de cierre sobrio estilo tarjeta de contacto del sistema, reincorporando el lockup oficial de TOYP:
* **Titular:** **Asegura la participación de tu marca.**
* **Información de Evento:** `28 de Noviembre de 2026 | Valencia, Venezuela`
* **Módulo de Contacto:**
  * Correo: `toypvzla@gmail.com`
  * Portal: `toyp.jcicarabobo.cc`
  * Coordinación: `Jahined Morocoima | Dirección TOYP Venezuela 2026`
* **Aviso de Disponibilidad:** `Cupos y apadrinamiento de categorías limitados.`
* **Locución:** "Asegura la presencia de tu marca antes de que se agoten las categorías. Escríbenos hoy."
* **SFX:** Tono armónico final sostenido con reverb natural.

---

## 4. Guion de Voz Completo para Sincronización (35 Segundos)

```text
¿Tu marca junto a los líderes que están transformando a Venezuela?

Este 28 de noviembre en Valencia, llega el programa de liderazgo juvenil de mayor prestigio global. Transmisión en vivo en alta definición y alcance directo a más de 100 países.

Posiciona a tu empresa con cuatro niveles diseñados a medida: Aliado Estratégico, Impulsor Comercial, Colaborador Digital y Apoyo Institucional. Opciones desde 15 dólares con presencia en streaming y activación presencial.

Y con absoluta flexibilidad: planes negociables a intercambio de productos y servicios.

Asegura la presencia de tu marca antes de que se agoten las categorías. Escríbenos hoy.
```

---

## 5. Master Prompt para Motores de Código / Video

```text
Generate an elite 9:16 vertical motion graphics video (1080x1920, 60fps, 36s total duration).
Aesthetic: Official Apple Keynote / Pro product video styling meets Gabriel Viza clean-tech motion. Zero emojis. Zero generic gradient clutter. Pure mathematical hierarchy.
Background: Official JCI Deep Navy (#00112C) with an ultra-subtle radial spotlight in iconic JCI Cyan/Blue (#0097D7 at 14% opacity).
Components: Translucent dark navy glass bento tiles (backdrop-blur 24px, 1px solid rgba(0,151,215,0.28) border glow), strictly styled with Plus Jakarta Sans typography across all UI modules (tabular figures for pricing), subtle JCI Aqua (#57BCBC) accents, and strictly damped spring physics (damping: 1.0, zero wobbly overshoot).

Assets & Lockup:
- Hero Asset: Incorporate the official lockup 'Comercial_TOYP.png' (featuring the JCI shield, geometric TOYP title, and serif '2026' footer). Animate with a subtle 1px specular light sweep and micro push-in zoom.

Timeline:
- 00-05s: Hook with official TOYP mark, JCI Venezuela, date "28 de Noviembre de 2026 • Valencia".
- 05-12s: 3 Bento modules for "Transmisión Oficial HD", "Red Global JCI (100+ países)", and "Networking Ejecutivo B2B/B2G".
- 12-27s: The 4 Sponsorship Tiers presented as hardware-style spec cards:
  * Aliado Estratégico: $50 (Barter available) | Category Sponsoring, 3x 30s Live Spots, Stand, 2 VIP Tickets.
  * Impulsor Comercial: $35 | 2x 15s Live Spots, Brand Space, 1 Ticket.
  * Colaborador Digital: $25 | Stream Logo Splash, Press Notes, 1 Ticket.
  * Apoyo Institucional: $15 | Stage mention, Closing Credits, 1 Ticket.
- 27-31s: Barter badge: "Planes negociables a intercambio comercial y de servicios".
- 31-36s: Outro spec card with toypvzla@gmail.com, toyp.jcicarabobo.cc, Jahined Morocoima (Directora).

Sound Design: Crisp mechanical tactile clicks, subtle 45Hz sub-bass swells, swift air whooshes, zero cartoon sound effects.
Voiceover Persona: Executive, warm, confident Latin American Spanish with measured pauses, 130 WPM.
```
