import {MotionV2} from './motion-v2';
import React,{useState,useEffect} from 'react';
import {AbsoluteFill,Audio,Composition,Img,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';

const C={navy:'#00112C',blue:'#0097D7',aqua:'#57BCBC',ice:'#F0F8FF',gold:'#D4AF37'};
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(t:number)=>{const x=Math.max(0,t)*12;return 1-(1+x)*Math.exp(-x);};
const enter=(t:number,start=0)=>ease((t-start)/.75);
const exit=(t:number,end:number)=>1-ease((t-end+.32)/.32);
const label:React.CSSProperties={fontSize:23,fontWeight:600,letterSpacing:3.2,textTransform:'uppercase',color:C.aqua};
const surface:React.CSSProperties={background:'rgba(4,24,55,.78)',border:'1px solid rgba(0,151,215,.4)',borderRadius:38,backdropFilter:'blur(24px)',boxShadow:'0 28px 70px #0004,inset 0 1px 0 #b9edff14'};

const Lockup:React.FC<{t:number;width:number;year?:boolean}>=({t,width,year=true})=>{
 const h=width*2800/4800,p=enter(t);
 return <div style={{width,textAlign:'center',color:C.ice}}>
 <div style={{position:'relative',height:h,overflow:'hidden',clipPath:`inset(${(1-p)*100}% 0 0 0)`}}>
 <Img src={staticFile('toyp-mark.svg')} style={{width,height:h,display:'block'}}/>
 <div style={{position:'absolute',inset:0,maskImage:`url('${staticFile('toyp-mark.svg')}')`,maskSize:'contain',maskRepeat:'no-repeat',maskPosition:'center'}}><div style={{position:'absolute',left:-50+clamp((t-.45)/1.7)*(width+100),top:0,width:1,height:h,background:'#fff',boxShadow:'0 0 10px 4px #e3f8ff88'}}/></div>
 </div>
 <div style={{fontSize:width*.047,fontWeight:400,letterSpacing:-.8,lineHeight:1.5,opacity:enter(t,.18)}}>10 JÓVENES SOBRESALIENTES<br/>VENEZUELA 2026</div>
 {year&&<div style={{fontFamily:'Bodoni',fontSize:width*.235,lineHeight:1.25,fontWeight:400,marginTop:width*.025,transform:`scale(${.97+.03*enter(t,.35)})`,opacity:enter(t,.35)}}>2026</div>}
 </div>;
};

const Opening:React.FC<{t:number}>=({t})=><AbsoluteFill style={{background:'#000',opacity:exit(t,5)}}>
 <div style={{position:'absolute',top:220,left:0,right:0,textAlign:'center',...label,color:'#a8c0d3',opacity:enter(t,.1)}}>JCI VENEZUELA PRESENTA</div>
 <div style={{position:'absolute',left:155,top:510,transform:`scale(${.98+.04*clamp(t/5)})`}}><Lockup t={t} width={770}/></div>
 <div style={{position:'absolute',top:1510,left:0,right:0,textAlign:'center',opacity:enter(t,.55)}}><div style={{fontSize:32,fontWeight:500}}>28 de noviembre de 2026</div><div style={{fontSize:27,color:'#9bb0c6',marginTop:16}}>Valencia, Venezuela</div></div>
 </AbsoluteFill>;

const Reach:React.FC<{t:number}>=({t})=>{
 const modules=[{n:'HD',title:'TRANSMISIÓN OFICIAL',text:'YouTube e Instagram Live',detail:'Alcance masivo multicanal'},{n:'100+',title:'RED GLOBAL JCI',text:'Presencia en más de 100 países',detail:'Una comunidad sin fronteras'},{n:'B2B',title:'NETWORKING EJECUTIVO',text:'Conexión B2B y B2G',detail:'Empresas, líderes y gremios'}];
 return <AbsoluteFill style={{opacity:exit(t,7)}}>
 <div style={{position:'absolute',left:80,top:175,...label,opacity:enter(t)}}>LA VITRINA DE TU MARCA</div>
 <div style={{position:'absolute',left:80,top:270,fontSize:82,fontWeight:800,letterSpacing:-2.5,lineHeight:1.08,transform:`translateY(${(1-enter(t))*60}px)`,opacity:enter(t)}}>Exposición multicanal<br/>de alto rendimiento.</div>
 {modules.map((m,i)=>{const p=enter(t,.15+i*.25);return <div key={m.n} style={{...surface,position:'absolute',left:80,top:650+i*325,width:920,height:280,opacity:p,transform:`translateY(${(1-p)*90}px) scale(${.97+.03*p})`,borderColor:`rgba(0,151,215,${.25+.35*(1-p)})`}}>
 <div style={{position:'absolute',left:38,top:75,width:255,fontSize:m.n==='100+'?91:105,fontWeight:700,letterSpacing:-4,color:i===1?C.ice:C.blue,fontVariantNumeric:'tabular-nums'}}>{m.n}</div>
 <div style={{position:'absolute',left:300,top:52,right:25}}><div style={{...label,fontSize:21,letterSpacing:1.9}}>{m.title}</div><div style={{fontSize:32,lineHeight:1.3,fontWeight:600,marginTop:23}}>{m.text}</div><div style={{fontSize:25,color:'#9eb5cf',marginTop:16}}>{m.detail}</div></div>
 </div>;})}
 </AbsoluteFill>;
};

const plans=[
 {name:['Aliado','Estratégico'],badge:'NIVEL EXCLUSIVO',price:50,barter:true,features:['Apadrina 1 de las 10 categorías','3 spots de 30 s en streaming HD','Activación de marca en el recinto','Galardón en tarima + 2 pases VIP']},
 {name:['Impulsor','Comercial'],badge:'ALTO RETORNO',price:35,features:['2 spots de 15 s en streaming','Espacio para presencia publicitaria','Logo + historia de impacto','1 entrada al evento']},
 {name:['Colaborador','Digital'],badge:'COBERTURA DIGITAL',price:25,features:['Logo en la cortinilla oficial','Menciones de marca en vivo','Cobertura en notas de prensa','1 entrada al evento']},
 {name:['Apoyo','Institucional'],badge:'RESPALDO GREMIAL',price:15,features:['Mención oficial en ceremonia','Logo proyectado en ceremonia','Lista final de agradecimientos','1 entrada al evento']},
];
const Plans:React.FC<{t:number}>=({t})=>{
 const current=Math.min(3,Math.floor(t/3.75));
 return <AbsoluteFill>
 <div style={{position:'absolute',left:80,top:155,...label}}>PLANES DE PATROCINIO</div>
 <div style={{position:'absolute',left:80,top:235,fontSize:65,fontWeight:700,letterSpacing:-1.6,lineHeight:1.15}}>Una alianza.<br/>Cuatro posibilidades.</div>
 {plans.map((p,i)=>{
  const age=t-i*3.75;if(age<-.2||age>3.95)return null;
  const move=(1-enter(age))*1040-ease((age-3.47)/.52)*1040;
  return <div key={p.price} style={{...surface,position:'absolute',left:80,top:490,width:920,height:1110,overflow:'hidden',transform:`translateX(${move}px) scale(${.98+.02*enter(age)})`,background:'#061b39',borderColor:i===0?'#d4af3755':'#0097d760'}}>
   <div style={{position:'absolute',left:45,top:45,border:`1px solid ${i===0?'#d4af3777':'#57bcbc66'}`,borderRadius:40,padding:'14px 21px',...label,fontSize:19,color:i===0?C.gold:C.aqua}}>{p.badge}</div>
   <div style={{position:'absolute',left:45,top:135,fontSize:76,fontWeight:800,letterSpacing:-2,lineHeight:1.07}}>{p.name[0]}<br/>{p.name[1]}</div>
   <div style={{position:'absolute',left:42,top:340,fontSize:172,fontWeight:700,letterSpacing:-8,fontVariantNumeric:'tabular-nums',lineHeight:1}}><span style={{fontSize:82,verticalAlign:'top',display:'inline-block',marginTop:15,marginRight:10,color:'#a4b7cd'}}>$</span>{p.price}</div>
   <div style={{position:'absolute',left:50,top:535,fontSize:25,color:p.barter?C.gold:'#9eb5cf'}}>{p.barter?'Disponible a intercambio comercial':'Inversión de patrocinio'}</div>
   <div style={{position:'absolute',top:610,left:45,right:45,height:1,background:'#0097d740'}}/>
   <div style={{position:'absolute',left:45,right:45,top:660}}>{p.features.map((text,j)=><div key={text} style={{display:'flex',alignItems:'center',gap:22,marginBottom:34,opacity:enter(age,.1+j*.045),transform:`translateY(${(1-enter(age,.1+j*.045))*20}px)`}}><svg width="24" height="24" viewBox="0 0 24 24" style={{flexShrink:0}}><path d="M5 12h14M12 5v14" stroke={C.aqua} strokeWidth="1.6"/></svg><div style={{fontSize:32,fontWeight:500,lineHeight:1.3}}>{text}</div></div>)}</div>
  </div>;
 })}
 <div style={{position:'absolute',left:80,right:80,top:1660,display:'flex',alignItems:'center',gap:16}}>{plans.map((p,i)=><div key={p.price} style={{height:3,flex:1,background:i<=current?C.blue:'#1c3150'}}/>)}<span style={{fontSize:23,fontWeight:600,color:'#a9bed1',marginLeft:20,fontVariantNumeric:'tabular-nums'}}>0{current+1} / 04</span></div>
 </AbsoluteFill>;
};

const Flexibility:React.FC<{t:number}>=({t})=>{
 const p=enter(t);
 return <AbsoluteFill style={{opacity:exit(t,4)}}>
 <div style={{position:'absolute',left:80,top:225,...label,opacity:p}}>MODALIDAD DE ALIANZA</div>
 <div style={{position:'absolute',left:80,top:335,fontSize:85,fontWeight:800,letterSpacing:-2.1,lineHeight:1.1,opacity:p,transform:`translateY(${(1-p)*45}px)`}}>Una alianza,<br/>muchas formas<br/>de aportar.</div>
 <div style={{...surface,position:'absolute',left:80,top:850,width:920,height:470,padding:50,boxSizing:'border-box',transform:`scale(${.92+.08*p})`,opacity:p}}><div style={{fontSize:51,fontWeight:600,lineHeight:1.22,letterSpacing:-1}}>Planes negociables<br/>a intercambio comercial<br/>y de servicios.</div><div style={{display:'flex',gap:18,marginTop:40}}>{['PRODUCTOS','SERVICIOS'].map(s=><div key={s} style={{...label,fontSize:18,letterSpacing:2,border:'1px solid #57bcbc55',borderRadius:40,padding:'13px 23px'}}>{s}</div>)}</div></div>
 <div style={{position:'absolute',left:85,top:1430,fontSize:31,lineHeight:1.5,color:'#a7bdd2',opacity:enter(t,.3)}}>Impulso real al desarrollo,<br/>la ciencia y la empresa venezolana.</div>
 </AbsoluteFill>;
};

const Closing:React.FC<{t:number}>=({t})=>{
 const p=enter(t);
 return <AbsoluteFill style={{opacity:p}}>
 <div style={{position:'absolute',left:330,top:150,transform:`scale(${.985+.015*p})`}}><Lockup t={t} width={420}/></div>
 <div style={{position:'absolute',left:75,right:75,top:720,textAlign:'center',fontSize:65,fontWeight:800,letterSpacing:-1.6,lineHeight:1.12}}>Asegura la participación<br/>de tu marca.</div>
 <div style={{position:'absolute',left:0,right:0,top:925,textAlign:'center',fontSize:28,color:'#abc0d5'}}>28 de noviembre de 2026 · Valencia, Venezuela</div>
 <div style={{...surface,position:'absolute',left:80,top:1060,width:920,height:335,padding:'43px 42px',boxSizing:'border-box',transform:`translateY(${(1-enter(t,.15))*35}px)`}}>
 <div style={{...label,fontSize:19,marginBottom:28}}>CONVERSEMOS SOBRE TU MARCA</div>
 <div style={{fontSize:49,fontWeight:600,letterSpacing:-1.2}}>toypvzla@gmail.com</div>
 <div style={{fontSize:42,fontWeight:500,letterSpacing:-.8,color:C.aqua,marginTop:28}}>toyp.jcicarabobo.cc</div>
 </div>
 <div style={{position:'absolute',left:0,right:0,top:1480,textAlign:'center'}}><div style={{fontSize:32,fontWeight:600}}>Jahined Morocoima</div><div style={{fontSize:25,color:'#a6bbcf',marginTop:13}}>Dirección TOYP Venezuela 2026</div></div>
 <div style={{position:'absolute',left:0,right:0,top:1665,textAlign:'center',fontSize:24,color:'#8ea8c3'}}>Cupos y apadrinamiento de categorías limitados.</div>
 </AbsoluteFill>;
};

export const Toyp:React.FC=()=>{
 const f=useCurrentFrame(),t=f/60;
 const [handle]=useState(()=>delayRender('Typography'));
 useEffect(()=>{Promise.all([document.fonts.load('800 80px Jakarta'),document.fonts.load('400 40px Jakarta'),document.fonts.load('400 160px Bodoni')]).then(()=>continueRender(handle)).catch(cancelRender);},[handle]);
 return <AbsoluteFill style={{background:C.navy,color:C.ice,fontFamily:'Jakarta',fontFeatureSettings:'"tnum" on',overflow:'hidden'}}>
 <style>{`@font-face{font-family:Jakarta;src:url('${staticFile('fonts/PlusJakartaSans.ttf')}');font-weight:200 800}@font-face{font-family:Bodoni;src:url('${staticFile('fonts/BodoniModa.ttf')}');font-weight:400 900}*{box-sizing:border-box}`}</style>
 <Audio src={staticFile('audio/final-mix.wav')}/>
 <AbsoluteFill style={{background:'radial-gradient(ellipse 850px 1150px at 50% 25%,rgba(0,151,215,.12),transparent 80%)'}}/>
 {t<5?<Opening t={t}/>:t<12?<Reach t={t-5}/>:t<27?<Plans t={t-12}/>:t<31?<Flexibility t={t-27}/>:<Closing t={t-31}/>}
 </AbsoluteFill>;
};
export const Root:React.FC=()=> <><Composition id="ToypMotionV2" component={MotionV2} durationInFrames={2160} fps={60} width={1080} height={1920}/><Composition id="ToypPatrocinios" component={Toyp} durationInFrames={2160} fps={60} width={1080} height={1920}/></>;
