import React,{useEffect,useState} from 'react';
import {AbsoluteFill,Audio,Img,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
const blue='#0097D7',aqua='#57BCBC',ice='#F0F8FF';
const c=(v:number)=>Math.max(0,Math.min(1,v));
const e=(v:number)=>1-Math.pow(1-c(v),4);
const p=(t:number,a:number,b:number)=>e((t-a)/(b-a));
const label:React.CSSProperties={fontSize:21,fontWeight:600,letterSpacing:3,color:'#83a4bc'};
const glass:React.CSSProperties={border:'1px solid #17618a66',background:'#061725',borderRadius:30,boxShadow:'0 35px 90px #0008,inset 0 1px 0 #c4efff10'};
const tiers=[
 {name:'Aliado Estratégico',price:50,badge:'NIVEL EXCLUSIVO',benefits:['Apadrina 1 de las 10 categorías','3 spots de 30 s en streaming HD','Activación de marca en el recinto','Galardón en tarima + 2 pases VIP']},
 {name:'Impulsor Comercial',price:35,badge:'ALTO RETORNO',benefits:['2 spots de 15 s en streaming','Espacio para presencia publicitaria','Logo + historia de impacto','1 entrada al evento']},
 {name:'Colaborador Digital',price:25,badge:'COBERTURA DIGITAL',benefits:['Logo en la cortinilla oficial','Menciones de marca en vivo','Cobertura en notas de prensa','1 entrada al evento']},
 {name:'Apoyo Institucional',price:15,badge:'RESPALDO GREMIAL',benefits:['Mención oficial en ceremonia','Logo proyectado en ceremonia','Lista final de agradecimientos','1 entrada al evento']},
];
const Arrow=()=> <svg width="32" height="32" viewBox="0 0 24 24"><path d="M4 12h15m-6-6 6 6-6 6" fill="none" stroke="currentColor" strokeWidth="1.8"/></svg>;
const Cursor:React.FC<{x:number;y:number;click:number}>=({x,y,click})=><div style={{position:'absolute',left:x,top:y,transform:`scale(${1-click*.18})`,filter:'drop-shadow(0 4px 4px #0008)'}}><svg width="55" height="62" viewBox="0 0 38 44"><path d="M3 2v32l9-8 7 14 7-4-7-13 12-1Z" fill="#f0f8ff" stroke="#03101d" strokeWidth="2"/></svg>{click>0&&<div style={{position:'absolute',left:-24,top:-24,width:54,height:54,border:`2px solid ${aqua}`,borderRadius:80,opacity:click,transform:`scale(${2-click})`}}/>}</div>;
const Mark:React.FC<{w:number;full?:boolean}>=({w,full=false})=><div style={{width:w,textAlign:'center'}}><Img src={staticFile('toyp-mark.svg')} style={{width:w,display:'block'}}/>{full&&<><div style={{fontSize:w*.047,lineHeight:1.5,marginTop:12}}>10 JÓVENES SOBRESALIENTES<br/>VENEZUELA 2026</div><div style={{fontFamily:'Bodoni',fontSize:w*.23,lineHeight:1.3,marginTop:16}}>2026</div></>}</div>;
const Shell:React.FC<{children:React.ReactNode;title?:string}>=({children,title='Patrocinios 2026'})=><div style={{...glass,width:940,height:1430,position:'relative',overflow:'hidden'}}><div style={{height:90,borderBottom:'1px solid #163952',display:'flex',alignItems:'center',padding:'0 35px',gap:10}}>{[0,1,2].map(i=><span key={i} style={{width:9,height:9,borderRadius:9,background:i===0?blue:'#254054'}}/>)}<span style={{marginLeft:25,fontSize:23,color:'#90abc0'}}>{title}</span><span style={{marginLeft:'auto',fontSize:17,color:'#57bcbc'}}>JCI VENEZUELA</span></div>{children}</div>;

const Hero:React.FC<{t:number}>=({t})=>{
 const zoom=p(t,.1,2.7),out=p(t,2.5,3.05);
 return <AbsoluteFill style={{perspective:1800,opacity:1-out}}>
 <div style={{position:'absolute',left:70,top:160,...label,opacity:p(t,.1,.5)}}>EL TALENTO TRANSFORMA UN PAÍS.</div>
 <div style={{position:'absolute',left:70,top:470,transformOrigin:'50% 40%',transform:`translateY(${(1-p(t,0,.7))*300-zoom*60}px) rotateY(${-22+zoom*18}deg) rotateX(${9-zoom*7}deg) rotateZ(${-8+zoom*6}deg) scale(${.77+zoom*.24})`}}>
 <Shell><div style={{position:'absolute',left:45,top:150}}><Mark w={300}/></div><div style={{position:'absolute',right:45,top:185,...label}}>28 NOV<br/><span style={{fontFamily:'Bodoni',fontSize:70,color:ice}}>2026</span></div>
 <div style={{position:'absolute',left:45,top:410,fontSize:61,fontWeight:700,letterSpacing:-2}}>Tu marca.<br/>Una alianza que importa.</div>
 <div style={{position:'absolute',left:45,right:45,top:650,...glass,padding:35}}><div style={label}>FORMAS DE IMPULSAR EL TALENTO</div><div style={{fontSize:143,fontWeight:800,letterSpacing:-8,marginTop:10}}>04<span style={{fontSize:35,letterSpacing:-1,fontWeight:500,marginLeft:22,color:'#96b2c7'}}>niveles de patrocinio</span></div><div style={{height:4,background:blue,marginTop:20}}/></div>
 {tiers.map((v,i)=><div key={v.price} style={{position:'absolute',left:45,right:45,top:960+i*82,display:'flex',justifyContent:'space-between',padding:'18px 12px',borderBottom:'1px solid #19364a',fontSize:27}}><span>{v.name}</span><span style={{fontWeight:700}}>${v.price}</span></div>)}
 </Shell></div>
 </AbsoluteFill>;
};
const Hook:React.FC<{t:number}>=({t})=><AbsoluteFill style={{opacity:1-p(t,4.7,5.1)}}><div style={{position:'absolute',left:80,right:80,top:720,textAlign:'center',fontSize:112,fontWeight:700,letterSpacing:-5,lineHeight:1.08}}>{['Tu marca.','Donde importa.'].map((s,i)=><div key={s} style={{overflow:'hidden'}}><div style={{color:i?aqua:ice,transform:`translateY(${(1-p(t,3+i*.28,3.5+i*.28))*150}px)`}}>{s}</div></div>)}</div><div style={{position:'absolute',left:0,right:0,top:1080,textAlign:'center',...label,opacity:p(t,3.6,4.1)}}>TOYP VENEZUELA 2026</div></AbsoluteFill>;
const Reach:React.FC<{t:number}>=({t})=>{
 const a=t-5,zoom=p(a,0,1),phase=Math.min(2,Math.floor(Math.max(0,a-1)/.85));
 const metrics=[['HD','Transmisión oficial','YouTube + Instagram Live'],['100+','Red global JCI','Más de 100 países'],['B2B','Networking ejecutivo','Conexión directa B2B y B2G']];
 return <AbsoluteFill style={{perspective:1600,opacity:1-p(t,8.8,9.15)}}><div style={{position:'absolute',left:80,top:180,...label}}>UNA VITRINA DE IMPACTO</div><div style={{position:'absolute',left:80,top:275,fontSize:84,fontWeight:700,letterSpacing:-3,lineHeight:1.1}}>Más alcance.<br/>Mejores conexiones.</div>
 <div style={{position:'absolute',left:70,top:650,transformOrigin:'50% 30%',transform:`scale(${.84+zoom*.16}) rotateX(${(1-zoom)*12}deg) translateY(${(1-zoom)*180}px)`}}><div style={{...glass,width:940,padding:35}}><div style={{...label,margin:'0 0 25px 10px'}}>TU MARCA EN MOVIMIENTO</div>{metrics.map(([n,title,sub],i)=>{const q=p(a,.3+i*.6,.8+i*.6);return <div key={n} style={{padding:'35px 25px',display:'flex',alignItems:'center',gap:35,borderBottom:i<2?'1px solid #19394d':'none',opacity:.3+.7*q,transform:`translateX(${(1-q)*120}px)`,background:phase===i?'#0c2b41':'transparent',borderRadius:20}}><div style={{fontSize:n==='100+'?105:115,fontWeight:700,letterSpacing:-6,width:270,color:phase===i?aqua:ice}}>{n==='100+'?Math.round(p(a,.8,1.65)*100)+'+':n}</div><div><div style={{fontSize:32,fontWeight:600}}>{title}</div><div style={{fontSize:24,color:'#8faec4',marginTop:14}}>{sub}</div></div></div>;})}</div></div>
 <div style={{position:'absolute',left:80,top:1530,fontSize:28,color:'#8ba9bf'}}>28 de noviembre · Valencia, Venezuela</div>
 </AbsoluteFill>;
};
const Four:React.FC<{t:number}>=({t})=>{const a=t-9;return <AbsoluteFill style={{opacity:1-p(a,1.75,2)}}><div style={{position:'absolute',left:80,top:520,fontSize:410,lineHeight:1,fontWeight:800,letterSpacing:-25,color:aqua,transform:`translateY(${(1-p(a,0,.5))*150}px) scale(${.9+.1*p(a,0,.6)})`}}>04<span style={{fontSize:78,letterSpacing:-3,color:ice,display:'block',marginTop:30,lineHeight:1.15}}>formas de impulsar<br/>lo extraordinario.</span></div></AbsoluteFill>;};

const Sponsor:React.FC<{t:number}>=({t})=>{
 const a=t-11,index=Math.min(3,Math.floor(a/3.5)),age=a-index*3.5,v=tiers[index];
 const arrival=p(age,0,.5),exit=p(age,3.2,3.5),lift=Math.sin(c(age/.55)*Math.PI)*30;
 const previous=tiers[Math.max(0,index-1)].price;
 const price=Math.round(previous+(v.price-previous)*p(age,.15,.65));
 const cam=1+.035*p(age,1,3.15);
 return <AbsoluteFill style={{perspective:2000}}>
 <div style={{position:'absolute',left:70,top:185,display:'flex',gap:30,alignItems:'center'}}><div style={{...label,color:aqua}}>ELIGE TU ALIANZA</div><div style={{width:200,height:1,background:'#204459'}}/><div style={{fontSize:22,color:'#91a9bb'}}>0{index+1} / 04</div></div>
 <div style={{position:'absolute',left:70,top:345,transformOrigin:'50% 50%',transform:`scale(${cam}) translateY(${-lift}px) rotateY(${(1-arrival)*5-exit*3}deg)`}}>
 <Shell>
 <div style={{position:'absolute',top:125,left:35,right:35,display:'flex',gap:12}}>{tiers.map((plan,i)=><div key={plan.price} style={{flex:1,padding:'19px 0',textAlign:'center',borderRadius:15,background:i===index?'#0a3b52':'#0b2232',color:i===index?aqua:'#758e9f',fontSize:28,fontWeight:700,border:i===index?'1px solid #57bcbc66':'1px solid transparent'}}>${plan.price}</div>)}</div>
 <div style={{position:'absolute',top:235,left:35,right:35,height:970,...glass,background:'#0a2030',borderColor:'#25607a',transform:`translateX(${(1-arrival)*650-exit*90}px)`,opacity:arrival*(1-exit*.5),padding:40}}>
 <div style={{...label,color:index===0?'#d4af37':aqua,fontSize:19}}>{v.badge}</div>
 <div style={{fontSize:66,lineHeight:1.12,fontWeight:700,letterSpacing:-2,marginTop:25,width:650}}>{v.name}</div>
 <div style={{fontSize:177,lineHeight:1.1,fontWeight:800,letterSpacing:-9,marginTop:28}}><span style={{fontSize:80,letterSpacing:0,color:'#8daabf',verticalAlign:'top',display:'inline-block',paddingTop:16,marginRight:9}}>$</span>{price}</div>
 <div style={{fontSize:23,color:index===0?'#c7af63':'#90acbf',marginTop:10}}>{index===0?'Disponible a intercambio comercial':'Inversión de patrocinio'}</div>
 <div style={{height:1,background:'#25506a',margin:'35px 0'}}/>
 {v.benefits.map((s,i)=><div key={s} style={{fontSize:31,lineHeight:1.4,display:'flex',gap:18,marginBottom:22,opacity:p(age,.15+i*.08,.45+i*.08),transform:`translateY(${(1-p(age,.15+i*.08,.45+i*.08))*20}px)`}}><span style={{color:aqua}}>+</span><span>{s}</span></div>)}
 </div>
 <div style={{position:'absolute',left:35,right:35,top:1255,borderRadius:20,background:blue,padding:'25px 32px',fontSize:29,fontWeight:600,display:'flex',justifyContent:'space-between'}}>Impulsa el talento venezolano<Arrow/></div>
 </Shell></div>
 <Cursor x={185+index*215+(1-p(age,0,.6))*160} y={530+(1-p(age,0,.6))*250} click={Math.sin(c((age-.52)/.3)*Math.PI)}/>
 </AbsoluteFill>;
};
const Barter:React.FC<{t:number}>=({t})=>{
 const a=t-25,click=p(a,1.2,1.5);
 return <AbsoluteFill style={{opacity:1-p(a,3.7,4)}}><div style={{position:'absolute',left:80,top:280,fontSize:83,fontWeight:700,letterSpacing:-3,lineHeight:1.12}}>Una alianza.<br/><span style={{color:aqua}}>Más posibilidades.</span></div>
 <div style={{...glass,position:'absolute',left:80,top:760,width:920,padding:45,transform:`translateY(${(1-p(a,0,.5))*100}px) scale(${.94+.06*p(a,0,.5)})`}}><div style={label}>MODALIDAD DE APORTE</div><div style={{display:'flex',gap:16,marginTop:35}}>{['Productos','Servicios'].map((s,i)=><div key={s} style={{borderRadius:20,padding:'30px 40px',fontSize:38,fontWeight:600,background:i===1&&click<.5?'#122c3d':'#124354',border:'1px solid #57bcbc66',color:i===1&&click<.5?'#6b8a9c':ice}}>{s}<span style={{marginLeft:20,color:aqua,opacity:i===0?1:click}}>✓</span></div>)}</div><div style={{height:1,background:'#20465d',margin:'35px 0'}}/><div style={{fontSize:43,lineHeight:1.25,fontWeight:600}}>Planes negociables<br/>a intercambio comercial<br/>y de servicios.</div></div>
 <Cursor x={680-100*(1-p(a,.6,1.25))} y={985+120*(1-p(a,.6,1.25))} click={Math.sin(c((a-1.25)/.3)*Math.PI)}/>
 <div style={{position:'absolute',left:80,top:1430,fontSize:28,color:'#8eaabb',lineHeight:1.5}}>Desarrollo, ciencia y empresa.<br/>Impulso real para Venezuela.</div>
 </AbsoluteFill>;
};
const Impact:React.FC<{t:number}>=({t})=>{const a=t-29;return <AbsoluteFill style={{opacity:1-p(a,2.75,3)}}><div style={{position:'absolute',left:80,top:690,fontSize:110,fontWeight:700,letterSpacing:-5,lineHeight:1.1}}>{['Tu marca.','Impacto real.'].map((s,i)=><div key={s} style={{overflow:'hidden'}}><div style={{color:i?aqua:ice,transform:`translateY(${(1-p(a,i*.25,.6+i*.25))*160}px)`}}>{s}</div></div>)}</div><div style={{position:'absolute',left:85,top:1080,background:blue,borderRadius:70,padding:'25px 38px',display:'flex',alignItems:'center',gap:40,fontSize:32,fontWeight:600,opacity:p(a,.7,1.1)}}>Asegura tu participación<Arrow/></div></AbsoluteFill>;};
const End:React.FC<{t:number}>=({t})=>{
 const a=t-32;return <AbsoluteFill style={{opacity:p(a,0,.4)}}><div style={{position:'absolute',left:300,top:280}}><Mark w={480} full/></div><div style={{position:'absolute',left:80,right:80,top:990,textAlign:'center'}}><div style={{fontSize:54,fontWeight:700,letterSpacing:-2}}>Conversemos sobre tu marca.</div><div style={{marginTop:40,background:blue,borderRadius:65,padding:'24px 35px',fontSize:41,fontWeight:600}}>toypvzla@gmail.com</div><div style={{fontSize:33,color:aqua,marginTop:28}}>toyp.jcicarabobo.cc</div></div><div style={{position:'absolute',left:0,right:0,top:1390,textAlign:'center',fontSize:28,color:'#b4c8d7'}}>28 de noviembre de 2026 · Valencia</div><div style={{position:'absolute',left:0,right:0,top:1515,textAlign:'center',fontSize:25,color:'#8da9bd',lineHeight:1.7}}>Jahined Morocoima<br/>Dirección TOYP Venezuela 2026</div><div style={{position:'absolute',left:0,right:0,top:1720,textAlign:'center',fontSize:22,color:'#7b98ab'}}>Cupos y apadrinamiento de categorías limitados.</div></AbsoluteFill>;
};
export const MotionV2:React.FC=()=>{
 const t=useCurrentFrame()/60;
 const [h]=useState(()=>delayRender('V2 typography'));useEffect(()=>{Promise.all(['700 80px Jakarta','400 30px Jakarta','400 120px Bodoni'].map(s=>document.fonts.load(s))).then(()=>continueRender(h)).catch(cancelRender);},[h]);
 return <AbsoluteFill style={{background:'#030d15',color:ice,fontFamily:'Jakarta',fontFeatureSettings:'"tnum" on',overflow:'hidden'}}><style>{`@font-face{font-family:Jakarta;src:url('${staticFile('fonts/PlusJakartaSans.ttf')}');font-weight:200 800}@font-face{font-family:Bodoni;src:url('${staticFile('fonts/BodoniModa.ttf')}');font-weight:400 900}*{box-sizing:border-box}`}</style><Audio src={staticFile('audio/motion-v2.wav')}/><AbsoluteFill style={{background:`radial-gradient(ellipse 950px 1300px at ${30+Math.sin(t*.15)*20}% 20%,#0097d71c,transparent 75%)`}}/>{t<3.05?<Hero t={t}/>:t<5?<Hook t={t}/>:t<9?<Reach t={t}/>:t<11?<Four t={t}/>:t<25?<Sponsor t={t}/>:t<29?<Barter t={t}/>:t<32?<Impact t={t}/>:<End t={t}/>}</AbsoluteFill>;
};
