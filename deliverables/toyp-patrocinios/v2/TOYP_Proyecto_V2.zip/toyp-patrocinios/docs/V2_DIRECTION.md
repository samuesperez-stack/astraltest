# TOYP Motion V2 — referencia de producto e interfaz

El usuario pidió una versión más dinámica y profesional y autorizó omitir la voz. Se conservan 36 segundos, vertical 1080×1920, 60 fps, información comercial y colores JCI.

Referencia consultada y revisada por fotogramas: https://www.tiktok.com/@ssupernova.studio/video/7693660982446492948 . Pieza horizontal de unos 22 segundos, con dispositivo/interfaz en perspectiva, cambios tipográficos, filas de datos que entran en secuencia, resultados extraídos como paneles flotantes y cursor de interacción. Se adapta ese lenguaje a la pieza TOYP vertical; no se reutilizan sus gráficos, música o metraje. El archivo de referencia no se distribuye.

## Nuevo montaje

- 0–3 s: consola de patrocinio en perspectiva que se aproxima a cámara; marca, fecha y visión general de niveles.
- 3–5 s: revelación tipográfica «Tu marca. Donde importa.».
- 5–9 s: tablero de alcance con entrada de filas, contador 100+ y foco secuencial en HD/red global/networking.
- 9–11 s: gran cifra 04 y transición al selector.
- 11–25 s: selección de cuatro niveles en una interfaz compartida. El cursor, pestaña, cifras, acercamiento y detalle acompañan cada cambio; se mantienen precios y beneficios.
- 25–29 s: selección visual de productos/servicios y condiciones de intercambio.
- 29–32 s: remate «Tu marca. Impacto real.» y llamada a participar.
- 32–36 s: marca/2026, correo, portal, fecha, dirección del programa y aviso de cupos.

La interfaz es una composición de motion design, no una demostración de una aplicación de patrocinio funcional. No se añaden funcionalidades o datos comerciales no presentes en el brief.

## Audio y fuentes

V2 no usa voz en off. `scripts/music_v2.py` sintetiza una base instrumental original a 120 BPM y efectos de transición con semilla fija; no se copia el audio de TikTok. Se conserva la mezcla y los recursos de V1 para poder volver a exportarla. Plus Jakarta Sans, Bodoni Moda y vector de marca conservan la procedencia documentada en PRODUCTION_NOTES.md.

## Reproducir

`npm run render` exporta `ToypMotionV2` a `out/TOYP_Motion_V2.mp4`. `npm run render:v1` conserva V1. `npm run render:v2proof` exporta los primeros siete segundos. `scripts/verify_v2.py` verifica y extrae los encuadres de V2. Los recursos necesarios están incluidos; no se requiere acceso al TikTok ni servicios TTS para exportar.
