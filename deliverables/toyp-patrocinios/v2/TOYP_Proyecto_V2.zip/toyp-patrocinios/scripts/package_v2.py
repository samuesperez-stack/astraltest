from pathlib import Path
import zipfile,json,hashlib
root=Path(__file__).resolve().parents[1];archive=root.parent/'TOYP_Proyecto_V2.zip'
files=[]
for f in sorted(root.rglob('*')):
 rel=f.relative_to(root)
 if not f.is_file() or any(x in rel.parts for x in ['node_modules','build','out','.venv','__pycache__']):continue
 if f.name=='SOURCE_MANIFEST.json':continue
 files.append(f)
manifest=[{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
p=root/'SOURCE_MANIFEST.json';p.write_text(json.dumps(manifest,indent=2)+'\n');files.append(p)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in files:z.write(f,Path('toyp-patrocinios')/f.relative_to(root))
 for name in ['verification-v2.json','TOYP_V2_Encuadres.jpg']:z.write(root/'out'/name,Path('toyp-patrocinios/out')/name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('toyp-patrocinios/src/motion-v2.tsx')==(root/'src/motion-v2.tsx').read_bytes()
print(archive,archive.stat().st_size)
