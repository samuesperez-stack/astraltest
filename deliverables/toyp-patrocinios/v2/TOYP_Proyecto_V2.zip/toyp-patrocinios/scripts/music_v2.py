from pathlib import Path
import numpy as np,wave,subprocess
root=Path(__file__).resolve().parents[1];sr=48000;n=sr*36
mix=np.zeros(n);rng=np.random.default_rng(20261027)
def put(time,a):
 i=int(time*sr);end=min(n,i+len(a))
 if i<n:mix[i:end]+=a[:end-i]
def tone(freq,duration,amp=.1):
 t=np.arange(int(duration*sr))/sr
 return (np.sin(2*np.pi*freq*t)+.22*np.sin(4*np.pi*freq*t))*amp*np.minimum(t/.008,1)*np.exp(-t*5)
roots=[73.416,58.27,87.307,65.406]
for beat in range(72):
 time=beat*.5;rootnote=roots[(beat//8)%4];intro=.5 if time<3 else 1;ending=min(1,(36-time)/1.6)
 t=np.arange(int(.23*sr))/sr
 if beat%2==0:
  kick=np.sin(2*np.pi*(48*t+50*(1-np.exp(-t*28))/28))*np.exp(-t*23)*.25
  put(time,kick*intro*ending)
 if beat%4 in [1,3]:
  noise=rng.normal(0,1,len(t));noise=noise-np.convolve(noise,np.ones(35)/35,mode='same')
  put(time,noise*np.exp(-t*48)*.045*intro*ending)
 put(time,tone(rootnote,.42,.10)*intro*ending)
 for k in range(2):
  tt=np.arange(int(.055*sr))/sr;noise=rng.normal(0,1,len(tt));noise=noise-np.convolve(noise,np.ones(9)/9,mode='same')
  put(time+k*.25,noise*np.exp(-tt*95)*.018*intro*ending)
  note=rootnote*([4,6,8,7][(beat*2+k)%4])
  put(time+k*.25,tone(note,.34,.025)*intro*ending)
for start in [3,5,9,11,14.5,18,21.5,25,29,32]:
 t=np.arange(int(.19*sr))/sr
 put(start,rng.normal(0,1,len(t))*np.exp(-t*38)*.028)
for start in [0,11,25,32]:
 t=np.arange(int(1.4*sr))/sr
 put(start,np.sin(2*np.pi*45*t)*np.sin(np.pi*t/1.4)**2*.035)
fade=np.minimum(np.arange(n)/sr/.08,1)*np.minimum((n-np.arange(n))/sr/.8,1);mix=np.tanh(mix*1.5)*fade
stereo=np.stack([mix,mix*.98],axis=1)
tmp=root/'out/music-v2-premix.wav'
with wave.open(str(tmp),'wb') as f:f.setparams((2,2,sr,0,'NONE','not compressed'));f.writeframes((np.clip(stereo,-1,1)*32767).astype('<i2').tobytes())
subprocess.run(['ffmpeg','-v','error','-y','-i',str(tmp),'-af','loudnorm=I=-16:TP=-1.3:LRA=8','-ar',str(sr),str(root/'public/audio/motion-v2.wav')],check=True)
print('Original instrumental 120 BPM, 36 seconds. No voice or reference audio.')
