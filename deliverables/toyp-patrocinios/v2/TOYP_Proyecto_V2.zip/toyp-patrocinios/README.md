# TOYP Motion V2 — versión actual

Nueva dirección basada en la referencia de TikTok del usuario: interfaz en perspectiva, acercamientos, contadores, cursor y transiciones tipográficas. **Sin voz en off**, con instrumental y SFX originales a 120 BPM. Se mantienen los datos, los cuatro planes y el formato de 36 s a 1080×1920/60 fps.

- Fuente actual: `src/motion-v2.tsx`.
- Exportar V2: `npm run render` → `out/TOYP_Motion_V2.mp4`.
- Exportar V1 con voz: `npm run render:v1`.
- Prueba V2: `npm run render:v2proof`.
- Verificar V2: `python scripts/verify_v2.py`.
- Dirección, referencia y cambios: `docs/V2_DIRECTION.md`.

Las instrucciones de instalación siguientes siguen vigentes. Las menciones a voz/guion y `ToypPatrocinios` describen V1, que se conserva; el render por defecto es ahora `ToypMotionV2`. No se necesita API para renderizar.

---

# TOYP Venezuela 2026 — Patrocinios

Video vertical de 36 segundos, 1080×1920, 60 fps, composición `ToypPatrocinios`. Proyecto independiente de CHEKI.

El usuario aprobó mantener 36 segundos y condensar la locución del MD. Se presentan los cuatro planes con sus precios y beneficios, la modalidad de intercambio, la fecha y los contactos del documento. Los datos comerciales proceden del brief; no se han sustituido por datos inferidos del sitio.

## Instalar y exportar

Node 24 y npm. Chromium instalado en `/usr/bin/chromium`; adaptar los scripts de package.json si se utiliza otra ubicación.

```bash
npm ci --no-audit --no-fund
npm run typecheck
npm run build
npm run studio
npm run render
```

Studio utiliza el puerto 3101. La salida es `out/TOYP_Patrocinios.mp4`. El audio, fuentes y marca están incluidos; no requiere APIs o descarga de recursos para renderizar tras instalar dependencias.

## Editar

- `src/root.tsx`: diseño y temporización de las cinco escenas; datos de los cuatro planes.
- `public/audio/final-mix.wav`: voz y efectos, 36 segundos.
- `public/audio/voice-manifest.json`: guion resumido, entradas y ajustes temporales por frase.
- `public/fonts/`: Plus Jakarta Sans y Bodoni Moda con sus OFL.
- `public/toyp-mark.svg`: vector de la marca obtenido del portal TOYP.
- `docs/PRODUCTION_BRIEF.md`: documento recibido, conservado sin cambios.
- `docs/PRODUCTION_NOTES.md`: procedencia, adaptación y comprobaciones.

## Voz y diseño sonoro

Voz sintética genérica `es-VE-SebastianNeural` mediante edge-tts 7.3.1. No es una grabación de un locutor humano ni una clonación de una persona. La locución se condensó con autorización del usuario. Las frases se sintetizaron por separado; se retiró silencio inicial/final y se ajustó su tempo conservando el tono para respetar los bloques.

Los clicks, barridos, subgraves y acordes fueron sintetizados mediante código determinista; no se empleó música comercial o efectos de stock. `scripts/voice.py` permite regenerar las frases con conexión al servicio; `scripts/mix_audio.py` rehace la mezcla desde los WAV incluidos. Estos pasos son opcionales para renderizar.

Herramientas opcionales: Python, FFmpeg, numpy, Pillow y edge-tts. Las dependencias de Python están en `requirements-tools.txt`. La regeneración TTS utiliza el proxy y el almacén de certificados confiables del entorno; no desactiva TLS ni incluye claves.

## Identidad visual

La imagen enviada al chat sirvió de referencia visual. Al no estar disponible como archivo local descargable, se recuperó el vector JCI/TOYP del portal `https://toyp.jcicarabobo.cc` y se compusieron la bajada y el año conforme a la referencia. El año usa Bodoni Moda. No es una copia píxel por píxel de `Comercial_TOYP.png` ni una marca generada con IA.

Las direcciones Apple/Gabriel Viza del brief se interpretan como referencia de lenguaje visual, sin afirmar afiliación o autoría de esas marcas/personas.
